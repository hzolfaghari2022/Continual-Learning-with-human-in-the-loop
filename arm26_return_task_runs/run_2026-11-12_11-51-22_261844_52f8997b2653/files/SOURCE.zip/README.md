## GitHub backup correction (v2)

This release protects exact bytes with Git attributes, repairs legacy newline-only
conversions ONLY when the original SHA256 is recovered, verifies Git-staged object
bytes, publishes original filenames under files/, and registers every successful
run under arm26_backups/ on main. No force push, main checkout or full-history clone.
The console prints FILES ON MAIN after verification. Older local results can be
re-backed-up with the standalone repair helper, without retraining or recollection.

# Arm26 larger-data study: collection and neural-network comparison

Two separate packages, one Python entry point each:

1. Arm26_600_Data_Collection: collect_data.py
2. Arm26_600_NN_Comparison: train_nn.py

## Run in VS Code

Extract BOTH ZIPs directly into %USERPROFILE% (for you,C:\Users\hzlfghri). Each ZIP
contains a new package folder ending in _v2; do not overwrite a running older folder. This keeps OpenSim/Git paths short while saving
outputs beside the code. The launcher checks for an overly long source path before
work begins. Open the folder containing the appropriate
Python entry point with VS Code File > Open Folder. Press F5. The included launch
configuration directly uses %USERPROFILE%\miniconda3\envs\lstm-py312\python.exe;
conda activate, clipboard commands and an assumed terminal directory are unnecessary.

Run collection first. Wait for SAVED, REPORT and GITHUB VERIFIED. Then open the NN
package folder and press F5. The NN launcher automatically reads the new completed
collection recorded by this release. START_COLLECTION.bat and START_NN.bat are
alternative launchers. Python helpers are not entry points.

Your previously working environment must include OpenSim, PyTorch CUDA, NumPy,
matplotlib and Git. No environment installation or administrator action is attempted.

## Storage: INSIDE each code folder

Each package writes:

    runs/run_YYYY-MM-DD_HH-MM-SS_microseconds/

Collection: full compact data, labels, metadata, source, quality report, logs.
NN: every model checkpoint/optimizer resume state, evaluations, source, reports.

Example: Arm26_600_NN_Comparison/runs/run_DATE_TIME/models/...
All newly generated scientific output stays inside that package's dated run folder.
The incremental Git cache stays in that package's github_cache/ folder by default.
A small path-only registry under %USERPROFILE%\Arm26_600_Data or Arm26_600_Results
connects the two packages; it does not duplicate the dataset. A user-configured
ARM26_VERIFIED_BACKUP_CACHE still takes precedence. No files are deleted automatically.
Do not move/delete active data or code folders. Older packages/results are untouched.

## Larger data, same scientific question

Default: 600 TOTAL full OpenSim teacher episodes, 2.4 times the earlier250 budget.
Per task:105 training,15 validation,30 held-out test episodes. Total420/60/120.
Task order:A_90 -> B_60 -> C_30 -> D_45 -> frozen return to A_90.
All four starting reference angles50/60/70/80deg and both reference variants occur
in every split. Entire episodes and their teacher-query rows remain in one split.
Startup-state combinations can recur across splits; reference episodes stay separate.

Model/physics/trajectory generator are identical to the previous successful-recovery
release:5kg dumbbell,0.005s control step,muscle excitation0.1,strength90/60/30/45%.
A:vertical reaches; B:variable-speed reversals; C:cross-body shoulder yaw;
D:reach/hold with known load pulses. Four instantaneous copied-state teacher queries
every0.2s add recovery labels; they are NOT additional integrated full episodes.
Full28-feature arrays, labels, time stamps, settings, audits and compact signals stay
inside the collection run. The dataset is read-only during NN training.

More data can change the learned weights and outcome. This release preserves the
architecture, losses, task order, epoch settings and acceptance/selection rules; it
DOES NOT guarantee the previous numbers, baseline failure or a stronger CL advantage.
The fixed1024-example memory is allocated round-robin across a larger set of
parent-episode/query groups, with startup priority AND reserved time-span diversity;
late-sorted episodes cannot consume zero memory merely because the dataset grew.

## Hardware and progress

No live simulator/viewer is needed. OpenSim dynamics uses CPU workers (default4);
it is not a CUDA physics solver. BOTH ordinary-NN and replay-CL optimization use
CUDA only; no silent CPU training fallback. The physical tracking evaluator uses
the same tiny NumPy inference export as the earlier verified simulator.

The terminal refreshes every2s with CURRENT phase iteration/total/percentage.
Percentages count epochs or episodes IN THAT PHASE, not overall wall time.
Backups show elapsed waiting time until the remote commit is verified; transfer
percentages are not invented. Detailed output:RUN.log; live state:PROGRESS.json.
The larger dataset means longer computation even though the epoch counts stay fixed.

## Neural network and training

6081 parameters:28 encoded inputs ->64tanh ->64tanh ->1 linear normalized-force
output. Multiply by650N and clip to0..650N. This is a learned feedback NN, using
state/error/integral, previous force, muscle state and known task parameters.
No separate PID is added at deployment; the PID/affine-dynamics teacher labels data.

Shared A learning from scratch:
-600 ordinary-MSE CUDA epochs, Adam0.001, cosine decay to5%, batch2048.
-Up to200 recovery epochs from those new weights, Adam0.0001.
-Physical validation at50/100/200 recovery epochs, capped to the requested budget.
-First milestone passing EVERY A validation reference becomes the identical shared
 initial checkpoint for both comparison branches. Motion RMSE<=0.5deg AND motion
 peak<=2deg, complete physical run, elbow envelope3..123deg. If none passes, save
 the failure report; do not claim forgetting from an initially inaccurate controller.

Sequential comparison:
-Ordinary NN trains B,C,D for120epochs/task, Adam0.001, optimizer reset per task,
 current-task examples only, final fixed-budget weights.
-CL candidates start from EXACTLY the same accepted A model and train B,C,D with
 identical current-task data, batches, permutations, updates and current-task loss.
 CL additionally replays up to512 examples/update from a fixed1024-example A
 TRAINING-only buffer. No previous full parameter vector is CL memory.
-Replay beta1,4,16 is selected on validation only. Current-task force validation
 RMSE must stay within1.5x ordinary NN, using a1N floor. Eligible candidates prefer
 all-reference A accuracy, then lower mean A validation angle RMSE, then smaller beta.
-All candidates are retained; no hidden fallback is selected if all are ineligible.
-Freeze models/memory/selection before decoding held-out test data. No learning on
 the return visit. Default held-out tracking rollouts:90 A +60 D =150.
-The final D test is a separate diagnostic of learning the new task. Preserving A
 while failing D is not proof of successful overall adaptation.

## Exact implemented cost function

For a minibatch D, predicted normalized force f_theta(x), teacher force F in N:

    ell_w(D) = sum_i w_i [f_theta(x_i)-F_i/650]^2 / sum_i w_i
    L_ordinary = ell_w(D_t) + 0.1 R(D_t)
    L_CL = L_ordinary + beta [ell_w(M_A) + 0.1 R(M_A)]

D_t=current-task minibatch; M_A=sampled old-task replay minibatch.
Weights:25 during first0.25s of trajectory;8 for remaining first1s;1 otherwise;
6 for teacher-query rows. The initial600epochs use unweighted MSE only.

R(D) is the mean squared hinge penalty on a locally reversed/weak corrective force
response: average over up to128examples and two finite-difference directions of
max(0,0.02-d_hat)^2. d_hat=[f(x+epsilon*v)-f(x-epsilon*v)]/(2epsilon),epsilon0.05.
The directions slightly decrease actual angle/velocity at fixed reference (encoded
angle/error direction(-0.02,+1), velocity/error direction(-0.1,+1)). This encourages
corrective response; it is not a mathematical stability guarantee. The SAME rule
is used in both branches; only CL accesses old A examples during later training.
Replay adds computation and old-data access, so total sample visits/wall time differ.

## Advisor report: four combined figures, complete records

Both packages generate REPORT.html and OVERLEAF_REPORT.zip. The collector has one
combined overview of split coverage and teacher tracking quality.

The NN report has FOUR logical figures, each saved as PNG and vector PDF:
1. NN architecture, parameter counts, and implemented cost functions.
2. Retention summary and force-learning histories.
3. Angle/velocity/error overlays for the FIRST predeclared reference, not a chosen
   best/worst case.
4. All-reference distributions, paired comparisons/forgetting, physical-failure
   counts and final D diagnostic.

No figure-per-episode gallery is generated. Every attempted episode remains in
EPISODE_METRICS.csv and an expandable HTML table. All failure/partial trace counts
remain visible; no failed run is assigned a fake finite final RMSE. Means over
completed trials are labeled as such. The advisor briefing explains the question,
sequence, actual data counts, architecture/inputs/units, objectives, memory budget,
selection, metrics, measured outcome and limits. One seed is exploratory; more
samples alone do not establish statistical significance or universal need for CL.

## Reusable models

Every training stage saves policy.pt (Torch architecture/state_dict),
policy_inference.npz/.json (portable NumPy deployment),HISTORY.json,RESUME.pt
(model,optimizer,RNG state),and COMPLETE.json with checksums.

MODEL_INDEX.json lists every checkpoint and names the shared-initial,ordinary-final,
and selected-CL-final models if they exist. SAVED_MODELS.zip contains those named
models plus the NumPy inference modules/readme. All other candidate/task checkpoints
remain in models/. Existence of a model file is not a scientific accuracy claim.
These simulation inputs include muscle states; physical-sensor deployment is not
established. SOURCE.zip preserves the exact code/model/geometry/launchers.

## GitHub and resume

Default verified backup repository:
https://github.com/hzolfaghari2022/Continual-Learning-with-human-in-the-loop.git

Backup at initialization,every10completed episodes,every50epochs,each training/
validation stage,and after final reports/model archive. New backup branches use
git init; repository default history is never cloned. Remote tip/manifest verification
is required. Source,full collector data,checkpoints,reports and logs are backed up;
NN-result backup does not duplicate its external input data. Failed verification
stops work with local data intact. No force push or embedded credentials.

Resume with the SAME package/source/options:

    python -X utf8 collect_data.py --resume-latest --episodes 600 --workers 4
    python -X utf8 train_nn.py --resume-latest --workers 4

Use the environment's full Python path if needed. Retry upload without computation:
add --backup-only --resume-latest. --out selects an explicit run directory.
Completed episodes/checkpoints are verified/reused; optimizer and RNG states are
restored. Changing source/settings cannot silently overwrite sealed work.

## Verification scope

Compile/CLI checks;600episode mocked end-to-end workflow;420/60/120 split;
identical model initialization for branches;train-only memory;test locks/seal;
resumption;scientific gate failures;four-figure report/Overleaf compile;model archive;
source archive isolation from runs/cache;packaged no-clone Git helper tests against
local bare remote. Actual uploaded A data are used for buffer-regression tests.
Mocked physics/GPU results are not scientific measurements. CUDA/OpenSim cannot run
in the build environment; final native execution must be verified on your PC.
