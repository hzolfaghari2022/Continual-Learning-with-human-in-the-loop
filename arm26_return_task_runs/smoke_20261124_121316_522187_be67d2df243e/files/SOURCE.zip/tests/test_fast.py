from pathlib import Path
import sys,unittest,tempfile,hashlib,json
import numpy as np
root=Path(__file__).resolve().parents[1];sys.path.insert(0,str(root))
from adapter.gpu_updates import replay_batches,log_block
import backup
from types import SimpleNamespace
class Tests(unittest.TestCase):
 def test_same_replay_draws(self):
  buffer=SimpleNamespace(size=17)
  for name in ['obs_buf','next_obs_buf','actions_buf','rewards_buf','done_buf']:setattr(buffer,name,np.arange(51).reshape(17,3))
  np.random.seed(12);idx=np.array([np.random.randint(0,17,size=7) for _ in range(5)])
  np.random.seed(12);batch=replay_batches(buffer,5,7)
  np.testing.assert_array_equal(batch['obs'],buffer.obs_buf[idx]);self.assertEqual(len(batch),5)
 def test_log_keeps_all_updates(self):
  rows=[];a=SimpleNamespace(auto_alpha=False,use_popart=False,logger=SimpleNamespace(store=rows.append))
  result={k:np.arange(6).reshape(2,3) for k in ['q1','q2','logp_pi','pi_loss','q1_loss','q2_loss','reg_loss','agem_violation']}
  log_block(a,result);self.assertEqual(len(rows[0]['train/loss_pi']),6)
 def test_deep_backup_alias(self):
  with tempfile.TemporaryDirectory() as d:
   dest=Path(d);name='/'.join(['parallel_training']+['long_directory_name']*16+['muscle_strength_audit.json'])
   payload=b'{"strength":0.9}';sha=hashlib.sha256(payload).hexdigest();obj=dest/'objects'/(sha+'.bin');obj.parent.mkdir();obj.write_bytes(payload)
   info=dict(sha256=sha,chunks=[dict(object='objects/'+sha+'.bin')])
   backup.publish_readable_files(dest,{name:info})
   self.assertEqual((dest/'files'/name).read_bytes(),payload)
 def test_budget_unchanged(self):
  from adapter.common import verify_upstream
  self.assertTrue(verify_upstream());s=(root/'adapter/experiment.py').read_text();self.assertIn('1_000_000',s);self.assertIn('retrain_steps=20 if smoke else 100000',s)
if __name__=='__main__':unittest.main()
