# Arm26 CW Fast: long No CL versus PackNet experiment

## Running
Use a NEW extracted folder. Do not overwrite the currently running package.
Open this folder in VS Code and run in PowerShell:

    & "$env:USERPROFILE\miniconda3\envs\lstm-py312\python.exe" -u -X utf8 .\RUN_PARALLEL.py

The launcher uses your existing arm26-cw environment, checks real CUDA/OpenSim integration, exercises compiled SAC and PackNet updates including protected masks, runs smoke integration, then starts full training. It does not reinstall CUDA or OpenSim.

Do not run concurrently with the older training job. Interrupting an old job preserves its files, but exact mid-method resume is not supported. The fast package starts fresh and reuses your scenario dataset, not trained weights. Default dataset path is the same as the prior package; use settings.json to override dataset if you moved it.

## Changes motivated by your measured times
Your 40000-step measurement was dominated by learner updates (1042 s), evaluation/logging (408 s), versus physics stepping (172 s). Two CPU simulation workers remain. The external training loop now prepares uniformly sampled FIFO minibatches and invokes the authors' ORIGINAL learning update inside a compiled sequential TensorFlow while-loop. Same 50 updates at each scheduled update point, same losses, optimizers, gradients, masks, target updates, learning rates, replay capacity and batch size. No upstream file is edited. This preserves the algorithmic update schedule, not identical random trajectories or bitwise weights.

Learning metrics retain all block loss/Q samples. Alpha telemetry is recorded at block end rather than after every individual update. PackNet's 100000 retraining updates at case boundaries still run through its original implementation, so these periods can remain slow. No CPU learning fallback exists.

Intermediate evaluation/checkpoint log interval: 100000 simulator transitions (previously 20000). Each evaluation still uses the same stochastic/deterministic episode counts. This changes monitoring frequency, not the final reserved test. Automatic GitHub training checkpoint interval: 100000 steps (previously 10000), plus evaluation logs, method completion and final reports. Failed backup is explicitly deferred with local files preserved; no remote success is claimed on failure.

## Budget and comparison
Cases A90 -> B60 -> C30 -> D45, with parallel workers only in the active case. One million total new physics transitions per case shared by the workers. Four million per method, eight million across No CL and PackNet. Authors' additional PackNet pruning/retraining remains. Full final frozen evaluation, HTML/Overleaf, figures and deployment checkpoints are retained. Training may still take days; speedup must be measured on your PC.

## Backup correction
Python extended Windows paths are used for deeply nested readable backup aliases and staged-byte verification, and new caches live in the shorter USERPROFILE/A26Git folder. Git longpaths remains enabled. Byte hashes and remote tip verification are retained. This targets your missing deeply nested muscle_strength_audit.json error, but the Windows fix must be verified on your computer; no remote push was attempted here.

## Monitoring
PARALLEL_TIMING.json is written every 5000 transitions and after evaluation. Compare physics_wall_s, updates_wall_s, evaluation_wall_s and transitions_per_elapsed time over comparable intervals. First compiled calls include tracing overhead. Do not compare a smoke run to steady full training. settings.json permits compiled_updates=false as a diagnostic compatibility path; changing it requires a fresh run and rerunning checks.

## Validation and boundaries
Nine local checks passed: four-case loop counts and cleanup at 1/2/4 workers, scheduling, upstream hashes, syntax, replay sampling equivalence, metric retention, deep backup alias reconstruction and unchanged budgets. Windows TensorFlow/OpenSim/CUDA is unavailable on the preparation host. The real preflight deliberately fails before full training if compiled updates, optimizer counts, physics or protected PackNet weights fail. No actual speedup or tracking improvement is claimed yet.

Physical failure guards remain unchanged. Failed No CL trajectories are not extrapolated to completion. This is not the separate diagnostic pilot's stage-by-stage retention audit. Keep all prior results for comparison.
