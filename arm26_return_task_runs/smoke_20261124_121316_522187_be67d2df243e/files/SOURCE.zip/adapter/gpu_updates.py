"""Run original SAC updates inside a compiled outer loop, without editing upstream."""
import numpy as np


def replay_batches(buffer, count, batch_size):
    # Same independent uniform FIFO draws as sample_batch, no insertions between updates
    idx = np.random.randint(0, buffer.size, size=(count,batch_size))
    return {name: getattr(buffer, attr)[idx] for name, attr in {
        'obs':'obs_buf','next_obs':'next_obs_buf','actions':'actions_buf',
        'rewards':'rewards_buf','done':'done_buf'}.items()}


def compile_updates(learn):
    import tensorflow as tf
    @tf.function
    def block(case_index, batches):
        first = learn(case_index, {k:v[0] for k,v in batches.items()}, None)
        arrays = {k:tf.TensorArray(v.dtype,size=tf.shape(batches['obs'])[0],
                    clear_after_read=False).write(0,v) for k,v in first.items()}
        # Explicit sequential dependency; never parallelize optimizer updates
        def body(i, arrays):
            result = learn(case_index,{k:v[i] for k,v in batches.items()},None)
            return i+1, {k:arrays[k].write(i,result[k]) for k in arrays}
        _, arrays = tf.while_loop(lambda i,a:i<tf.shape(batches['obs'])[0],
            body,(tf.constant(1),arrays),parallel_iterations=1)
        return {k:v.stack() for k,v in arrays.items()}
    return block


def log_block(agent, result):
    # Retain all loss/Q samples, rather than reporting just the final update
    fields = {'train/q1_vals':'q1','train/q2_vals':'q2','train/log_pi':'logp_pi',
              'train/loss_pi':'pi_loss','train/loss_q1':'q1_loss',
              'train/loss_q2':'q2_loss','train/loss_reg':'reg_loss',
              'train/agem_violation':'agem_violation'}
    agent.logger.store({name:np.asarray(result[key]).reshape(-1) for name,key in fields.items()})
    # Temperature telemetry at block end; this never affects learning
    if agent.auto_alpha:
        import tensorflow as tf
        agent.logger.store({f'train/alpha/{i}':float(tf.exp(agent.all_log_alpha[i][0]))
                           for i in range(agent.num_tasks)})
    if agent.use_popart:raise RuntimeError('Compiled telemetry supports current non-PopArt configuration only')
