See README.md for the current fast-version instructions and changes
