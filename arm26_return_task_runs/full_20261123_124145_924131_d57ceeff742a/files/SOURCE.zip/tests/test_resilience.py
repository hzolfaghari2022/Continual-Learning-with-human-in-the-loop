"""Infrastructure regression tests. No real CUDA/OpenSim or scientific results."""
import contextlib,io,importlib.util,json,os,subprocess,sys,tempfile,time,unittest
from pathlib import Path
from unittest.mock import patch
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from adapter import common,resilience,launcher,run_guard
import backup

class ResilienceTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.root=Path(self.temp.name)
    def tearDown(self): self.temp.cleanup()
    def test_upstream_hashes(self):self.assertEqual(common.verify_upstream(),'73f63bb4fa0b5d00bda973e20dfb783bfcf1b8aa')
    def test_atomic_write(self):
        p=self.root/'CONFIG.json';common.write(p,{'step':1});self.assertEqual(common.read(p),{'step':1})
    def test_windows_retry(self):
        original=os.replace;calls=[]
        def replace(a,b):
            calls.append(1)
            if len(calls)<3:
                exc=PermissionError('simulated Windows sharing conflict');exc.winerror=5;raise exc
            return original(a,b)
        with patch.object(common.os,'replace',replace),patch('time.sleep'):
            common.write(self.root/'CONFIG.json',{'ok':True})
        self.assertEqual(len(calls),3)
    def test_only_telemetry_write_can_be_skipped(self):
        exc=PermissionError('simulated Windows sharing conflict');exc.winerror=32
        with patch.object(common.os,'replace',side_effect=exc),patch('time.sleep'):
            common.write(self.root/'PROGRESS.json',{})
            with self.assertRaises(PermissionError):common.write(self.root/'CONFIG.json',{})
        self.assertFalse(list(self.root.glob('*.tmp')))
    def test_monitor_read_lock(self):
        with patch.object(Path,'read_text',side_effect=PermissionError('busy')):
            self.assertEqual(resilience.telemetry(self.root/'PROGRESS.json',{}),{})
    def test_bad_monitor_json(self):
        p=self.root/'PROGRESS.json'
        for text in ('{','[]','null'):
            p.write_text(text);self.assertEqual(resilience.telemetry(p,{}),{})
    def test_backup_deferred_then_verified(self):
        with patch.object(backup,'backup_experiment',side_effect=PermissionError('lock')):
            self.assertIsNone(resilience.best_effort_backup(self.root,'fixture'))
        self.assertEqual(common.read(self.root/'BACKUP_PENDING.json')['status'],'pending')
        with patch.object(backup,'backup_experiment',return_value={'commit_url':'fixture'}):
            self.assertEqual(resilience.best_effort_backup(self.root,'retry')['commit_url'],'fixture')
        self.assertFalse((self.root/'BACKUP_PENDING.json').exists())
    def test_backup_lock_serializes_processes(self):
        script="import sys,time;sys.path.insert(0,sys.argv[1]);from pathlib import Path;from backup import cache_lock\nwith cache_lock(Path(sys.argv[2])):\n print('locked',flush=True);time.sleep(1)"
        proc=subprocess.Popen([sys.executable,'-c',script,str(ROOT),str(self.root/'cache')],stdout=subprocess.PIPE,text=True)
        try:
            self.assertEqual(proc.stdout.readline().strip(),'locked');start=time.monotonic()
            with backup.cache_lock(self.root/'cache'):pass
            self.assertGreater(time.monotonic()-start,.5);self.assertEqual(proc.wait(),0)
        finally:
            if proc.poll() is None:proc.kill();proc.wait()
            proc.stdout.close()
    def test_live_worker_guard(self):
        common.write(self.root/'ACTIVE_WORKER.json',{'pid':os.getpid()})
        with patch.object(run_guard,'ROOT',self.root):
            with self.assertRaisesRegex(RuntimeError,'still alive'):
                with run_guard.launcher_guard():pass
    def test_monitor_exception_does_not_kill_worker(self):
        (self.root/'rl_worker.py').write_text("import time;time.sleep(.15);print('fixture worker done')")
        with patch.object(launcher,'ROOT',self.root),patch.object(launcher,'telemetry',side_effect=PermissionError('monitor locked')):
            launcher.run_child(Path(sys.executable),['full',str(self.root),str(self.root)],self.root/'RUN.log',self.root,{})
        self.assertIn('fixture worker done',(self.root/'RUN.log').read_text())
        self.assertFalse((self.root/'ACTIVE_WORKER.json').exists())
    def test_child_failure_is_not_hidden(self):
        (self.root/'rl_worker.py').write_text("raise SystemExit(2)")
        with patch.object(launcher,'ROOT',self.root):
            with self.assertRaisesRegex(RuntimeError,'Worker stopped'):
                launcher.run_child(Path(sys.executable),['full',str(self.root),str(self.root)],self.root/'RUN.log',self.root,{})
        self.assertFalse((self.root/'ACTIVE_WORKER.json').exists())

    def test_source_archive_excludes_live_lock(self):
        import zipfile
        from adapter import catalog
        (self.root/'LAUNCHER.lock').write_bytes(b'locked fixture')
        (self.root/'ACTIVE_WORKER.json').write_text('{}')
        (self.root/'source.py').write_text('pass')
        config=common.defaults();config.update(rl_python=sys.executable,physics_python=sys.executable,github=False)
        original=zipfile.ZipFile.write
        def guarded(archive,filename,*args,**kwargs):
            if Path(filename).suffix=='.lock':raise PermissionError('Windows forbids reading held lock')
            return original(archive,filename,*args,**kwargs)
        def preflight(*args,**kwargs):common.write(Path(args[1][1])/'PREFLIGHT_PASS.json',{'fixture':True})
        with patch.object(launcher,'ROOT',self.root),patch.object(launcher,'settings',return_value=config),patch.object(launcher,'verify_upstream',return_value='fixture'),patch.object(launcher,'configuration_signature',return_value='fixture'),patch.object(launcher,'run_child',side_effect=preflight),patch.object(catalog,'build_catalog',return_value={'fixture':True}),patch.object(sys,'argv',['test']),patch.object(zipfile.ZipFile,'write',guarded):
            with contextlib.redirect_stdout(io.StringIO()):launcher.launch('check')
        suite=Path(common.read(self.root/'LAST_CHECK.json')['folder'])
        with zipfile.ZipFile(suite/'SOURCE.zip') as archive:
            self.assertIn('source.py',archive.namelist())
            self.assertNotIn('LAUNCHER.lock',archive.namelist())
            self.assertNotIn('ACTIVE_WORKER.json',archive.namelist())

if __name__=='__main__':unittest.main(verbosity=2)
