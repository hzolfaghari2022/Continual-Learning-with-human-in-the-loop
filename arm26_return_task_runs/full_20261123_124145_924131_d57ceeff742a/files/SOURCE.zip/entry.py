"""Stdlib-only launch layer for VS Code and long Windows extraction paths."""
from pathlib import Path
import sys,os,subprocess,hashlib,shutil
ROOT=Path(__file__).resolve().parent

def main(mode):
    if os.name=='nt' and len(str(ROOT))>75:
        short=Path.home()/('A26CW_'+hashlib.sha256(str(ROOT).encode()).hexdigest()[:8])
        if not short.exists():shutil.copytree(ROOT,short,ignore=shutil.ignore_patterns('runs','github_cache','__pycache__','.git','repair_backups','*.lock','*.tmp','ACTIVE_WORKER.json'))
        else:
            for source in ROOT.rglob('*'):
                rel=source.relative_to(ROOT)
                if source.is_file() and source.suffix.lower() not in ('.lock','.tmp') and source.name!='ACTIVE_WORKER.json' and not any(x in rel.parts for x in ['runs','github_cache','__pycache__','.git','repair_backups']):
                    if not (short/rel).is_file() or source.read_bytes()!=(short/rel).read_bytes():raise RuntimeError('Working copy differs. Open and run the scripts directly from '+str(short)+'; do not overwrite a running experiment.')
        script={'check':'CHECK_SETUP.py','smoke':'RUN_SMOKE.py','full':'RUN_FULL_RL.py'}[mode]
        print('Working code folder:',short,flush=True)
        return subprocess.call([sys.executable,'-u',str(short/script),*sys.argv[1:]],cwd=short)
    from adapter.launcher import launch
    from adapter.run_guard import launcher_guard
    with launcher_guard():
        launch(mode)
    return 0
