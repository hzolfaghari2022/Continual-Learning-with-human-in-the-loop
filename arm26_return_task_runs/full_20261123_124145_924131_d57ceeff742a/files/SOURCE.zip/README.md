# Updated complete release: Windows I/O fixes integrated

Extract this ZIP directly into C:\Users\hzlfghri. The top folder is Arm26_CW_Updated. Keep your old CW_783145 folder and all datasets/results; do not overwrite or delete them.

**In VS Code, open Arm26_CW_Updated and run RUN_ALL.py.** It reuses the existing arm26-cw environment if available; otherwise it runs the separate environment installer. It then runs CHECK_SETUP, the short smoke check and the full experiment, stopping on a genuine setup/physics/learning failure.

The full experiment is still 8 million new simulator interactions plus evaluation and PackNet retraining. This update is a reliability fix, not a speedup; runtime can be several days. The 600 original scenarios remain separate from the interaction budget.

Integrated fixes:
- Retry temporary Windows file-sharing errors during atomic JSON writes
- A temporarily locked or malformed progress display cannot kill training
- Acquire the backup lock before writing to it; wait for competing backups
- Failed uploads remain explicitly pending and are retried at later scheduled backups
- No successful upload is claimed until the existing remote verification succeeds
- Reports display pending-backup state; RETRY_GITHUB.py retries without training
- A launcher lock prevents duplicate launches in this code folder
- Surviving recorded workers are detected, and a controlled launcher exit terminates its own worker
- Includes RUN_LOCAL_TESTS.py with 12 infrastructure regression tests

**Recovery limitation:** interrupted methods restart from initial weights in a new attempt folder. The authors' unchanged run loop does not support exact mid-method resumption. This updated package starts its own run folder and does not migrate an interrupted old attempt into a resumable state. No learning budget, reward, scenario, or original learner source was changed by these fixes.

Local tests do not establish real OpenSim/CUDA correctness on Windows or tracking accuracy. Your earlier installation passed its real GPU/OpenSim checks; run the new package's included checks again before full training.

---

# Original Continual World learners connected to Arm26/OpenSim

## What this package is

A NEW online reinforcement-learning experiment. It imports the authors' original SAC baseline and PackNet implementation unchanged, with an external OpenSim environment adapter. It is not the old supervised NN/replay-beta pipeline, not an offline fit to600 force-label episodes, and not a reproduction of the paper's Meta-World scores.

Official source: https://github.com/awarelab/continual_world
Pinned commit:73f63bb4fa0b5d00bda973e20dfb783bfcf1b8aa
UPSTREAM_LOCK.json records the exact Git blob hashes of46 original source/text files. They are verified before use. No SAC loss, target update, actor/critic, optimizer or PackNet pruning/masking source is patched or reimplemented.

## VS Code: run these in order

Extract the complete ZIP, preferably directly under C:\Users\hzlfghri. Open Arm26_CW_Updated in VS Code. For each file choose Run Python File in Terminal.

1. SETUP_RL_ENV.py — creates a SEPARATE arm26-cw conda environment with Python3.10, TensorFlow2.10/Keras2.10 and compatible dependencies. Does not alter lstm-py312 or install GPU drivers. Requires internet and conda access.
2. CHECK_SETUP.py — verifies CUDA TensorFlow optimization, an original SAC update, an original PackNet update/pruning/protected-weight check, and real OpenSim reset/step in your existing lstm-py312 process
3. RUN_SMOKE.py — small complete No CL/PackNet integration run;100 training interaction steps per case, short10-step episodes, minimal evaluation. Truncated smoke episodes are NOT evidence of tracking accuracy or a CL advantage.
4. RUN_FULL_RL.py — full new online RL experiment, permitted only after the matching smoke check succeeds

The existing OpenSim physics interpreter remains:
C:\Users\hzlfghri\miniconda3\envs\lstm-py312\python.exe
The separate learning interpreter is:
C:\Users\hzlfghri\miniconda3\envs\arm26-cw\python.exe

The physical simulator runs in isolated persistent subprocesses. TensorFlow does not share a process with OpenSim. GPU NN optimization is REQUIRED; there is no silent CPU training fallback. OpenSim forward dynamics remains CPU-based.

TensorFlow2.10 is selected because the authors' code uses the older Keras optimizer/variable APIs and because2.10 is the last TensorFlow with native Windows GPU support. Installed GPU/driver compatibility is checked, not guaranteed. If CHECK_SETUP fails, stop and inspect its PREFLIGHT.log; do not replace your existing working environment or start full training. Native Windows GPU guidance: https://www.tensorflow.org/install/pip#windows-native

## Existing scenarios

Default completed source dataset:
C:\Users\hzlfghri\A26Final_7e4d7951\runs\collect_20261114_164226_441056

If moved, add "dataset": "C:/actual/completed/run" to settings.json. You can likewise override "physics_python" and "rl_python". Use JSON forward slashes or escaped backslashes.

Only scenario settings and split metadata are reused:420 training configurations,60 validation,120 reserved test. Original PID arrays are NOT read as labels. Model, protocol and per-scenario checksums are validated. Cases/order remain A90% -> B60% -> C30% -> D45%, with the same5kg dumbbell and existing movement profiles. These case changes also include the movement-profile differences already present in your600-episode source; this is not an experiment isolating muscle strength alone.

## What was adapted, outside the learning code

- Gym environment reset/step/termination and split-safe scenario sampling
- OpenSim state observation:28 encoded physical/reference/muscle features plus4 case-selector values
- Original multihead actor/critic architecture:4 hidden256-neuron layers; known case selects a head; hide_task_id=True keeps case selector out of shared features
- Action mapping: scalar a in[-1,1] becomes cable force325(a+1)N, bounded0..650N
- Control interval0.02s, maximum OpenSim integrator step0.005s
- Tracking reward and physical safety envelope; no PID or expert-force command actuates during RL
- Logging, progress, reports, model/PackNet-state export and GitHub backup

The authors' models import dimension constants from continualworld.envs. adapter/binding.py provides an environment-only module binding with MW_OBS_LEN=28 and MW_ACT_LEN=1. It leaves the original envs.py file unchanged on disk and avoids loading MuJoCo/Meta-World when running OpenSim. No learning method is monkey-patched or subclassed. Only a logging subclass observes completed intervals.

## Full experiment size and fairness

Two default methods:original SAC fine-tuning (No CL) and original PackNet-SAC (CL). SAC fine-tuning still uses its ordinary within-case replay buffer; "No CL" does not mean no SAC replay at all.

Full budget:1,000,000 new environment steps per case,4 cases per method; two methods total8,000,000 new OpenSim interactions, plus evaluation. PackNet additionally uses100,000 prune/retrain gradient updates after each nonfinal case and clipnorm2e-5, following the authors' provided paper command. Other main SAC settings follow their defaults. Extra PackNet computation is disclosed; wall time and total gradient updates are not equalized. This full run may take many hours or longer in OpenSim.600 original episodes are scenario definitions, NOT the RL interaction budget.

Methods start from checked identical seeded actor weights and use the same source scenario pools. Online actions and the number of episodes need not match. Periodic official evaluation uses validation scenarios only. After learning, every120 reserved reference is evaluated with frozen deterministic inference. No reward/hyperparameter tuning uses reserved tests. Three earlier cases provide return/retention evaluations; final D reports current-condition learning. There is no initial-accuracy gate that hides the other method, but failed learning/physics remains visible and is not called CL success.

This first release does not calculate forward transfer; independent fresh single-case training references would be needed. Seed42 is one exploratory seed, not a statistically established benchmark result. Optional ewc can be added to settings.methods after no_cl and packnet; it imports the original EWC class with coefficient10000, but is not part of the default two-method smoke validation.

## Reward and success

Reward = exp(-(angle error/5deg)^2) -0.01(F/650)^2 -0.01(deltaF/650)^2 -0.05 min((velocity error/0.5rad/s)^2,25)
Physical-failure terminal reward=-20.

These are task-specific adapter design choices, not copied paper rewards. They do not guarantee good tracking. Arm envelope3..123deg, shoulder envelope-25..65deg and positive cable moment arm are checked. Failure is distinct from time truncation. A complete reference counts as accurate when motion-only RMSE<=0.5deg and motion peak<=2deg; full peak and failed/truncated counts are also saved.

## Progress, data, models and reports

All generated work is inside the printed code folder's runs/ directory, in separate dated suites. Long code paths are copied to a stable short user-folder location automatically. Keep that actual working folder. Progress displays interaction-step percentages and separate frozen-evaluation counts. During original PackNet retraining, no new environment steps occur; the step count can stay fixed while gradients continue. A step percentage is not an overall wall-time ETA.

Episode configurations, signals and status are saved separately. Models are the authors' TensorFlow actor/critic checkpoints, with additional PackNet ownership state for correct inference on an earlier case. Each completed method triggers REPORT.html, OVERLEAF_REPORT.zip, separate PDF/PNG figures, CSV metrics, and SAVED_MODELS.zip. All failures remain in the tables. The report includes the architecture, source pin, reward, budgets, split definitions and limitations.

## GitHub

Backup is ON by default to your existing repo. It runs at initialization, every10,000 environment steps with model snapshots, official evaluation/log checkpoints, completed methods and final reports. Model snapshots precede uploads. Completed source, scenarios, traces, reports and models are preserved with the verified binary/Windows-safe backup implementation. Inspect GITHUB_STATUS.json for verified remote commit and files_url. A network/authentication or backup-lock error defers that upload and records BACKUP_PENDING.json; it does not stop learning or erase local work. Later scheduled uploads retry the current snapshot. After completion, run RETRY_GITHUB.py to retry any pending final upload without retraining. Set "github":false only if you explicitly want no backup for that new run.

## Restart and recovery

Running the same suite launcher again reuses CHECKSUM-VERIFIED COMPLETED methods. If a method was interrupted, it restarts that method in a NEW attempt folder from the same initial seed; it does not overwrite its partial attempt. The authors' unchanged SAC.run() does not support exact mid-method loop/physics/replay/RNG resume. Saved intermediate policies are deployable checkpoints, not a claim of exact training resumption. Do not assume loading actor weights alone resumes PackNet learning.

Use --new-run to intentionally start a new suite after changing settings; --resume requires a recorded suite. Do not edit upstream/ or adapter code while a suite is running. Keep your original600 dataset and prior trained models until you have verified the new results/backups.

## Validation boundary

Locally verified: upstream byte hashes, all Python syntax, scenario split checks, Gym contract/dimension/case-boundary logic and JSON worker protocol using a test stand-in, report generation from labeled synthetic test records, and checkpoint archive paths. Those test stand-ins are NOT OpenSim physics or learned-controller results. The preparation environment has neither OpenSim nor TensorFlow CUDA, so the real integration and performance must be checked by CHECK_SETUP/RUN_SMOKE on your machine. Local LaTeX compilation is unavailable; compile main.tex in Overleaf. No perfect tracking or CL improvement is promised.

## Later inference from a saved actor

Use adapter.deployment.load_policy(method_folder) in arm26-cw; it loads the original actor and restores PackNet ownership masks. The returned callable accepts28 ENCODED features in the preserved complex_trajectories.FEATURES order and a case index0..3, and returns force in N. It does not resume training or replace real sensor validation. Example:

```python
from adapter.deployment import load_policy
predict_force = load_policy(r"C:\actual\method\attempt_folder")
force_N = predict_force(encoded_features, case_index=0)
```
