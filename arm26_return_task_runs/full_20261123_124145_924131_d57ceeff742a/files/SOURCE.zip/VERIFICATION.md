# Validation record for this release

Passed locally:
- All 46 included upstream source/text Git blob checksums match commit 73f63bb4fa0b5d00bda973e20dfb783bfcf1b8aa
- All shipped Python source parses
- 12 infrastructure regression tests, including Windows sharing-error injection, transient retries, progress read errors, corrupt progress JSON, deferred upload/retry state, cross-process backup serialization, active-worker guard, monitor exception survival, and genuine worker failure propagation
- HTML, standalone PDF/PNG figure export, Overleaf archive and saved-model archive generation using explicitly synthetic fixtures
- ZIP integrity and package file checksums

Not run here: real OpenSim dynamics, real TensorFlow CUDA updates, native Windows locking, complete online RL training, tracking-performance comparison or LaTeX compilation. CHECK_SETUP.py and RUN_SMOKE.py must pass on the user's machine. Synthetic fixtures are not scientific results and are not included as experiment outputs.

Run RUN_LOCAL_TESTS.py to repeat infrastructure tests without OpenSim or TensorFlow. It never submits a GitHub upload.
