"""Run original SAC/PackNet classes; only environment/logging glue is local."""
import os,sys,math,hashlib,csv,io,json
from pathlib import Path
import numpy as np
from .common import ROOT,CASES,read,write,sha,verify_upstream
from .envs import ArmEnv,SequenceEnv
from .binding import bind


def configure_tensorflow():
    import tensorflow as tf
    if not tf.__version__.startswith('2.10.'):
        raise RuntimeError('This unchanged-source integration is pinned to TensorFlow2.10.x/Keras2.10; do not silently run with Keras3')
    gpus=tf.config.list_physical_devices('GPU')
    if not gpus:raise RuntimeError('CUDA TensorFlow GPU not available. No CPU fallback. Run SETUP_RL_ENV.py and CHECK_SETUP.py.')
    tf.config.set_visible_devices(gpus[0],'GPU')
    tf.config.experimental.set_memory_growth(gpus[0],True)
    with tf.device('/GPU:0'):
        v=tf.Variable([[1.]],dtype=tf.float32)
        with tf.GradientTape() as tape:loss=tf.reduce_sum(v*v)
        tf.keras.optimizers.Adam(.001).apply_gradients([(tape.gradient(loss,v),v)])
    if 'GPU' not in v.device:raise RuntimeError('Optimizer test was not placed on GPU')
    tf.keras.backend.clear_session()
    return tf,dict(tensorflow=tf.__version__,python=sys.version.split()[0],tensorflow_build=tf.sysconfig.get_build_info(),gpu_details=tf.config.experimental.get_device_details(gpus[0]),optimizer_device=v.device)


def fingerprint(model):
    digest=hashlib.sha256()
    for v in model.weights:digest.update(np.asarray(v.numpy()).tobytes())
    return digest.hexdigest()


def checkpoint(agent,folder,current_case,method):
    # Original saver is invoked, not replaced. It writes actor and both critics.
    agent.save_model(current_case)
    arrays={};names=[]
    if hasattr(agent,'owner'):
        for i,(ref,value) in enumerate(agent.owner.items()):
            arrays[f'owner_{i}']=value.numpy();arrays[f'saved_{i}']=agent.saved_variables[ref].numpy();names.append(ref.deref().name)
        arrays['freeze_biases_and_normalization']=agent.freeze_biases_and_normalization.numpy();arrays['current_view']=agent.current_view.numpy()
    if hasattr(agent,'old_params'):
        for i,v in enumerate(agent.old_params):arrays[f'old_param_{i}']=v.numpy()
        for i,v in enumerate(agent.reg_weights):arrays[f'reg_weight_{i}']=v.numpy()
    if arrays:
        b=io.BytesIO();np.savez_compressed(b,**arrays)
        (folder/'algorithm_state.npz').write_bytes(b.getvalue())
    write(folder/'DEPLOYMENT.json',dict(method=method,case=current_case,actor_prefix='checkpoints/actor' if current_case==3 else f'checkpoints/task{current_case}/actor',packnet_variable_order=names,upstream_commit=verify_upstream(),observation_features=28,case_selector_dims=4,action_mapping='F_N=325*(a+1), a in[-1,1]',exact_mid_run_resume_supported=False,note='Original SAC.run() does not resume loop/physics/RNG/replay state. Completed methods can be reused; interrupted methods restart in new attempt folders. PackNet inference requires on_test_start(case_index) / on_test_end(case_index) and restored ownership state.'))


def run_method(suite,folder,method,mode):
    suite=Path(suite);folder=Path(folder);os.chdir(folder)
    options=read(suite/'CONFIG.json');catalog=read(suite/'SCENARIOS.json');tf,environment=configure_tensorflow();bind()
    from continualworld.sac.models import MlpActor
    from continualworld.utils.run_utils import get_sac_class
    from continualworld.utils.enums import BufferType
    from continualworld.sac.utils.logx import EpochLogger
    # Runtime configuration differs for integration check, NEVER hidden file edits.
    smoke=mode=='smoke';budget=100 if smoke else 1_000_000;log_every=100 if smoke else 20_000;limit=10 if smoke else None
    maxlen=10 if smoke else math.ceil(max(c['duration_s'] for pool in catalog['pools'].values() for split in pool.values() for c in split)/options['control_dt_s'])+1
    envs=[ArmEnv(catalog,case,'train',options,folder/'training'/case,seed=options['seed']+i,max_steps=limit) for i,case in enumerate(CASES)]
    validation=[ArmEnv(catalog,case,'validation',options,folder/'validation'/case,seed=options['seed']+100+i,max_steps=limit) for i,case in enumerate(CASES)]
    context={};last_backup=0
    def backup(reason):
        if not options['github']: return
        from adapter.resilience import best_effort_backup
        os.environ.setdefault('ARM26_VERIFIED_BACKUP_CACHE',str(ROOT/'github_cache'))
        result=best_effort_backup(suite,method+': '+reason)
        if result is not None:
            print('GITHUB VERIFIED:',result['commit_url'],flush=True)
    def hook(step,case):
        nonlocal last_backup
        if step%1000==0:
            import shutil
            if shutil.disk_usage(folder).free<5*1024**3:raise RuntimeError('Less than5GiB free disk space; run stopped with local work preserved')
        if step-last_backup>=options['backup_every_steps']:
            checkpoint(context['agent'],folder,case,method);backup('training steps '+str(step));last_backup=step
    train=SequenceEnv(envs,budget,folder,backup_hook=hook)
    class ObservedLogger(EpochLogger):
        def dump_tabular(self):
            row=dict(self.log_current_row);super().dump_tabular()
            write(folder/'LATEST_LOG.json',row)
            agent=context.get('agent')
            if agent is not None:
                checkpoint(agent,folder,min((train.cur_step-1)//budget,3),method)
                write(suite/'STATUS.json',dict(phase='validation/checkpoint completed',method=method,steps=train.cur_step,total=4*budget))
                backup('official evaluation/log interval '+str(train.cur_step))
    logger=ObservedLogger(['tsv'],config=dict(method=method,mode=mode,options=options,upstream_commit=verify_upstream(),steps_per_case=budget,packnet_retrain_steps=20 if smoke else 100000),group_id=method,output_dir=str(folder/'logs'))
    actor=dict(hidden_sizes=[256,256,256,256],activation=tf.nn.leaky_relu,use_layer_norm=True,num_heads=4,hide_task_id=True)
    kwargs=dict(env=train,test_envs=validation,logger=logger,seed=options['seed'],steps=4*budget,log_every=log_every,replay_size=10000 if smoke else 1_000_000,batch_size=16 if smoke else 128,actor_cl=MlpActor,actor_kwargs=actor.copy(),critic_kwargs=actor.copy(),buffer_type=BufferType.FIFO,reset_buffer_on_task_change=True,reset_optimizer_on_task_change=True,lr=.001,alpha='auto',reset_critic_on_task_change=False,clipnorm=2e-5 if method=='packnet' else None,gamma=.99,target_output_std=.089,agent_policy_exploration=False,start_steps=20 if smoke else 10000,update_after=20 if smoke else 1000,update_every=10 if smoke else 50,num_test_eps_stochastic=1 if smoke else 10,num_test_eps_deterministic=1,max_episode_len=maxlen,save_freq_epochs=1)
    cl=None if method=='no_cl' else method
    cls=get_sac_class(cl)
    if method=='packnet':agent=cls(**kwargs,regularize_critic=False,retrain_steps=20 if smoke else 100000)
    elif method=='ewc':agent=cls(**kwargs,regularize_critic=False,cl_reg_coef=10000.)
    elif method=='no_cl':agent=cls(**kwargs)
    else:raise ValueError('Unsupported configured method')
    if not agent.actor.trainable_variables or 'GPU' not in agent.actor.trainable_variables[0].device:raise RuntimeError('Original actor variables were not placed on GPU')
    if 'GPU' not in agent.critic1.trainable_variables[0].device:raise RuntimeError('Original critic variables were not placed on GPU')
    context['agent']=agent
    write(folder/'ENVIRONMENT.json',environment)
    initial_hash=fingerprint(agent.actor)
    write(folder/'INITIALIZATION.json',dict(actor_sha256=initial_hash,actor_parameters=sum(int(np.prod(v.shape)) for v in agent.actor.weights),critic_parameters=sum(int(np.prod(v.shape)) for v in agent.critic1.weights),learning_class=cls.__module__+'.'+cls.__name__,source_file=sys.modules[cls.__module__].__file__))
    for i in range(4):(folder/'checkpoints'/('task'+str(i))).mkdir(parents=True,exist_ok=True)
    completed=[]
    try:
        agent.run()
        # Freeze learning: only original policy inference/test hooks are used below.
        write(suite/'STATUS.json',dict(phase='frozen evaluation starting',method=method))
        for case_index,case in enumerate(CASES):
            split='validation' if smoke else 'test'
            env=ArmEnv(catalog,case,split,options,folder/'frozen_evaluation'/case,seed=options['seed']+1000+case_index,max_steps=limit)
            configs=catalog['pools'][case][split][:1] if smoke else catalog['pools'][case][split]
            try:
                agent.on_test_start(case_index)
                for cfg in configs:
                    env.next_config=cfg;obs=env.reset();done=False
                    while not done:
                        action=agent.get_action_test(tf.convert_to_tensor(obs),tf.constant(True));obs,reward,done,info=env.step(action)
                    record=dict(env.completed_results[-1],method=method,initial_actor_sha256=initial_hash)
                    completed.append(record);write(folder/'FROZEN_EVALUATION.json',completed)
                    write(folder/'EVALUATION_PROGRESS.json',dict(case=case,completed=len(completed),total=4 if smoke else 120))
            finally:agent.on_test_end(case_index);env.close()
        checkpoint(agent,folder,3,method)
        write(folder/'METHOD_COMPLETE.json',dict(method=method,mode=mode,steps=4*budget,frozen_episodes=len(completed),initial_actor_sha256=initial_hash,hashes={p.relative_to(folder).as_posix():sha(p) for p in [*sorted((folder/'checkpoints').rglob('*')),folder/'algorithm_state.npz',folder/'DEPLOYMENT.json',folder/'FROZEN_EVALUATION.json'] if p.is_file()},initialization=read(folder/'INITIALIZATION.json'),note='Smoke means integration only, not tracking accuracy' if smoke else 'Fresh online RL; full frozen test results retained'))
        backup('method completed with saved policy and evaluation')
    finally:
        train.close()
        for env in validation:env.close()
