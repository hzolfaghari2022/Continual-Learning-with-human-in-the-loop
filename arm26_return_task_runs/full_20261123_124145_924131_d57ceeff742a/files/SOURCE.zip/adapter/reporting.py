import csv,html,io,base64,zipfile,json
from pathlib import Path
import numpy as np
from .common import CASES,ROOT,read,write,verify_upstream

def escape(s):return str(s).replace('\\',r'\textbackslash{}').replace('_',r'\_').replace('%',r'\%').replace('&',r'\&').replace('#',r'\#')
def table(headers,rows):return '<table><tr>'+''.join('<th>'+html.escape(str(x))+'</th>' for x in headers)+'</tr>'+''.join('<tr>'+''.join('<td>'+html.escape(str(v))+'</td>' for v in row)+'</tr>' for row in rows)+'</table>'
def build(suite):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    suite=Path(suite);config=read(suite/'CONFIG.json');methods=read(suite/'METHODS.json') if (suite/'METHODS.json').exists() else {};mode=read(suite/'RUN_SIGNATURE.json')['mode'];rows=[];histories={}
    figure_dir=suite/'figures';figure_dir.mkdir(exist_ok=True)
    for method,record in methods.items():
        folder=suite/record['folder'];file=folder/'FROZEN_EVALUATION.json'
        if file.exists():rows.extend(read(file))
        file=folder/'logs/progress.tsv'
        if file.exists():
            with file.open(newline='',encoding='utf-8') as f:histories[method]=list(csv.DictReader(f,delimiter='\t'))
    summary=[]
    for case in CASES:
        for method in config['methods']:
            values=[r for r in rows if r['case']==case and r['method']==method];ok=[r for r in values if r['status']=='completed' and r.get('rmse_deg') is not None]
            summary.append(dict(case=case,method=method,attempted=len(values),completed=sum(r['status']=='completed' for r in values),failed=sum(r['status']=='failed' for r in values),truncated=sum(r['status']=='truncated' for r in values),successes=sum(bool(r['success']) for r in values),completed_only_mean_rmse_deg=float(np.mean([r['rmse_deg'] for r in ok])) if ok else None))
    write(suite/'SUMMARY.json',dict(mode=mode,groups=summary,note='Smoke is an integration check. Full results are frozen reserved tests. Failed/truncated episodes never receive an invented final RMSE. One seed; no statistical significance claim.'))
    for filename,values in [('EPISODE_METRICS.csv',rows),('SUMMARY.csv',summary)]:
        if values:
            with (suite/filename).open('w',newline='',encoding='utf-8') as f:
                writer=csv.DictWriter(f,fieldnames=list(values[0]),extrasaction='ignore');writer.writeheader();writer.writerows(values)
    colors={'no_cl':'#D55E00','packnet':'#0072B2','ewc':'#009E73'};figures=[]
    def save(fig,name):
        fig.tight_layout();fig.savefig(figure_dir/(name+'.pdf'),bbox_inches='tight');fig.savefig(figure_dir/(name+'.png'),dpi=150,bbox_inches='tight');plt.close(fig);figures.append(name)
    fig,axes=plt.subplots(1,3,figsize=(14,4))
    width=.7/max(len(config['methods']),1)
    for j,method in enumerate(config['methods']):
        groups=[next(r for r in summary if r['case']==c and r['method']==method) for c in CASES];x=np.arange(4)+(j-(len(config['methods'])-1)/2)*width
        axes[0].bar(x,[g['completed_only_mean_rmse_deg'] if g['completed_only_mean_rmse_deg'] is not None else np.nan for g in groups],width,color=colors[method],label=method)
        axes[1].bar(x,[g['failed'] for g in groups],width,color=colors[method],label=method)
        axes[2].bar(x,[g['successes']/g['attempted'] if g['attempted'] else np.nan for g in groups],width,color=colors[method],label=method)
    for ax in axes:ax.set_xticks(range(4),CASES);ax.grid(axis='y',alpha=.2);ax.legend(fontsize=9)
    axes[0].set_ylim(bottom=0);axes[1].set_ylim(bottom=0)
    axes[0].set(title='Completed-trial tracking ONLY',ylabel='Elbow RMSE (deg)');axes[1].set(title='Failed simulations',ylabel='Episode count');axes[2].set(title='Accuracy success rate',ylabel='Fraction',ylim=(0,1))
    fig.suptitle('Integration check only' if mode=='smoke' else 'Frozen reserved-test comparison');save(fig,'comparison')
    fig,ax=plt.subplots(figsize=(10,4.8))
    for method,history in histories.items():
        x=[];y=[]
        for row in history:
            try:x.append(float(row['total_env_steps']));y.append(float(row['test/stochastic/average_success']))
            except (KeyError,ValueError):continue
        if x:ax.plot(x,y,color=colors[method],label=method)
    ax.set(xlabel='New environment interaction steps',ylabel='Mean validation success rate',ylim=(0,1),title='Official SAC periodic validation (not reserved tests)');ax.grid(alpha=.2)
    if ax.lines:ax.legend()
    save(fig,'learning')
    for case in CASES:
        subset=[r for r in rows if r['case']==case];ids=sorted({r['episode_id'] for r in subset})
        if not ids:continue
        eid=ids[0];fig,axes=plt.subplots(3,1,figsize=(10,7),sharex=True);ref=False;ref_end=-1.;ref_line=None
        for method in config['methods']:
            record=next((r for r in subset if r['method']==method and r['episode_id']==eid),None)
            if not record:continue
            path=Path(record['folder'])/'signals.csv'
            # Archive paths survive moving the whole results folder.
            if not path.exists():
                old=str(path).replace('\\','/');marker='/methods/'
                if marker in old:path=suite/'methods'/old.split(marker,1)[1]
            if not path.exists():continue
            with path.open(encoding='utf-8',newline='') as f:trace=list(csv.DictReader(f))
            if not trace:continue
            vector=lambda name:np.array([float(v[name]) for v in trace]);t=vector('time_s');q=vector('angle_deg');target=vector('reference_deg')
            if not ref:
                ref_line=axes[0].plot(t,target,'k--',label='Reference')[0];ref=True;ref_end=t[-1]
                config_file=path.parent/'settings.json'
                if config_file.is_file():
                    import sys,math
                    sys.path.insert(0,str(ROOT/'physics/core'))
                    from complex_trajectories import reference
                    cfg=read(config_file);planned=np.linspace(0,cfg['duration_s'],math.ceil(cfg['duration_s']/config['control_dt_s'])+1)
                    expected=np.degrees([reference(float(v),cfg)[0] for v in planned]);ref_line.set_data(planned,expected);ref_end=planned[-1];axes[0].relim();axes[0].autoscale_view()
            elif t[-1]>ref_end:ref_line.set_data(t,target);ref_end=t[-1]
            label=method+(' [partial '+record['status']+']' if record['status']!='completed' else '')
            axes[0].plot(t,q,color=colors[method],label=label);axes[1].plot(t,target-q,color=colors[method]);axes[2].plot(t,vector('tension_N'),color=colors[method])
            if record['status']!='completed':axes[0].plot(t[-1],q[-1],'x',color=colors[method])
        axes[0].set_ylabel('Elbow angle (deg)');axes[1].set_ylabel('Tracking error (deg)');axes[2].set(ylabel='Cable force (N)',xlabel='Time (s)');axes[0].legend(fontsize=9)
        for ax in axes:ax.grid(alpha=.2)
        fig.suptitle(case+' - first reference by ID, not selected for favorable error');save(fig,'tracking_'+case)
    fmt=lambda value:'--' if value is None else f'{value:.4f}'
    headers=['Case','Method','Attempted','Completed','Failed','Truncated','Passed','Mean RMSE*']
    data=[[s['case'],s['method'],s['attempted'],s['completed'],s['failed'],s['truncated'],s['successes'],fmt(s['completed_only_mean_rmse_deg'])] for s in summary]
    description=('SMOKE: software integration only. Short10-step trajectories are intentionally truncated; they do not establish tracking quality, retention or CL benefit.' if mode=='smoke' else 'FULL: new online reinforcement learning with the authors original SAC and PackNet code. Original600 configurations define reference pools; original PID force targets were not training labels. The final protocol calls for120 reserved references per method without gradient updates; unfinished methods remain explicitly pending/failed. This is an OpenSim adaptation, not reproduction of the Meta-World paper scores.')
    sections=[('What is unchanged','Original source commit '+verify_upstream()+'. SAC losses, target updates, actor/critic implementations, optimizers and PackNet pruning/gradient masks are imported directly from upstream/. All46 included upstream source/text files are Git-blob checksum verified before execution.'),('What is adapted','The external environment adapter supplies OpenSim states, a force action, tracking reward, resets, episode limits and success criteria. A32-dimensional observation contains28 encoded physical/reference/muscle features plus a4-dimensional known-case selector. With hide_task_id=True the shared core uses28 inputs; the selector chooses the appropriate output head. The action a in[-1,1] maps to F=325(a+1)N. Shoulder/yaw and5kg load follow the original scenarios; muscle strengths are A90%,B60%,C30%,D45%.'),('Learning architecture and budgets','Four256-neuron hidden layers, leaky-ReLU with first-layer normalization/tanh as in upstream, four policy heads, two critics and target critics. The full configuration uses1M environment steps per case, batch128, Adam0.001, gamma0.99, automatic entropy with target output std0.089, FIFO replay1M and reset at case boundaries. No CL means SAC fine-tuning; SAC still uses within-case replay. PackNet additionally uses100k pruning/retraining updates per nonfinal case and clipnorm2e-5, following the authors paper command. It therefore has additional compute. Equal budgets mean new simulator steps, not total gradient updates.'),('Reward definition','At each control step: exp(-(angle_error_deg/5)^2) -0.01(F/650)^2 -0.01(deltaF/650)^2 -0.05 min((velocity_error_rad_s/0.5)^2,25). Physical failure reward=-20. These are task-specific adapter choices, not equations claimed from the paper. Settings are fixed before final tests.'),('Physical and evaluation limits','Control interval0.02s, integrator maximum step0.005s, real OpenSim dynamics with the original model. Requested force is bounded0..650N; elbow3..123deg and positive cable moment arm are checked. A completed reference passes when motion-only RMSE<=0.5deg and peak<=2deg. Full peak and failures are retained. Time-limit truncation is separate from physical failure. The worker never returns a fabricated successful transition after an infrastructure exception.'),('Data split and fairness','420 configurations for interaction training,60 for periodic validation and120 reserved for final frozen evaluation. The paired final evaluations use the same reference IDs. On-policy trajectories and the number of episodes need not match between methods. Actor initial-weight fingerprints are checked for equality across methods. Seed42 only; episode diversity is not independent training replication. No candidate or checkpoint is chosen using reserved tests.'),('Interpretation limits','A complete run is not proof of good tracking or CL superiority. This first comparison does not measure forward transfer because independent single-case reference training runs have not been included. It is not an offline600-episode supervised experiment and does not reproduce the authors robotic benchmark scores.'),('Saved models and recovery','Original actor/critic TensorFlow checkpoint prefixes and additional PackNet ownership state are retained. The unchanged upstream run loop cannot resume exactly in the middle of a method. Completed methods are reused by checksum; interrupted methods restart in a new attempt folder. Intermediate policies are deployable snapshots, not exact training-resume checkpoints.'),('Source and citation','Wolczyk et al., Continual World: A Robotic Benchmark for Continual Reinforcement Learning, NeurIPS2021. https://github.com/awarelab/continual_world. No upstream learning source is patched or reimplemented. Environment binding replaces continualworld.envs at import with only the OpenSim dimension constants; the original MuJoCo environment module is retained on disk but not imported.')]
    page='<!doctype html><html><meta charset="utf-8"><title>OpenSim with original Continual World learners</title><style>body{font:17px Arial;max-width:1150px;margin:30px auto;padding:0 20px;line-height:1.5;color:#16324f}img{max-width:100%}td,th{padding:7px;border-bottom:1px solid #ddd;text-align:left}table{border-collapse:collapse;width:100%;font-size:14px}.notice{background:#fff1d8;padding:16px}</style><h1>Original Continual World learners connected to OpenSim</h1><p class="notice">'+html.escape(description)+'</p>'+table(headers,data)+'<p>*RMSE is in degrees and includes completed trajectories only; read it alongside failed and truncated counts. Missing results are not zero.</p>'
    pending=(suite/'BACKUP_PENDING.json').exists()
    backup_note=('GITHUB BACKUP PENDING: local files are preserved; the latest files have not been verified remotely. Run RETRY_GITHUB.py after training ends.' if pending else 'Check GITHUB_STATUS.json for the last remotely verified snapshot. A report alone is not proof of a final upload.')
    sections.insert(0,('Backup state',backup_note))
    for title,body in sections:page+='<h2>'+title+'</h2><p>'+html.escape(body)+'</p>'
    for name in figures:page+='<h2>'+name.replace('_',' ').title()+'</h2><img src="data:image/png;base64,'+base64.b64encode((figure_dir/(name+'.png')).read_bytes()).decode()+'">'
    page+='<h2>Method status</h2>'+table(['Method','Status'],[[m,methods.get(m,{}).get('status','not started')] for m in config['methods']])+'</html>'
    (suite/'REPORT.html').write_text(page,encoding='utf-8')
    tex=r'\documentclass[11pt]{article}\usepackage[T1]{fontenc}\usepackage[margin=.7in]{geometry}\usepackage{graphicx,booktabs,longtable,amsmath}\setlength{\parindent}{0pt}\begin{document}\section*{Original Continual World learners connected to OpenSim}'+'\n'+escape(description)+'\n'+r'\begin{center}\small\begin{tabular}{llrrrrrr}\toprule Case & Method & Trials & Done & Failed & Trunc. & Passed & RMSE$^*$\\\midrule'+'\n'
    for row in data:tex+=' & '.join(escape(v) for v in row)+r'\\'+'\n'
    tex+=r'\bottomrule\end{tabular}\end{center}'+'\nCompleted-trial mean RMSE only; failed and truncated results have no invented final error.\n'
    for title,body in sections:tex+=r'\subsection*{'+escape(title)+'}\n'+escape(body)+'\n'
    tex+=r'\[J_Q=\mathbb{E}[(Q-y)^2],\quad J_\pi=\mathbb{E}[\alpha\log\pi(a|s)-\min(Q_1,Q_2)]\]'+'\nOriginal SAC objectives are imported, not rewritten. PackNet masks gradients and prunes/fixes parameter subsets; no replay-beta penalty is added for PackNet.\n'
    for name in figures:tex+=r'\clearpage\section*{'+escape(name.replace('_',' ').title())+'}'+r'\includegraphics[width=\linewidth,height=.82\textheight,keepaspectratio]{figures/'+name+'.pdf}'+'\n'
    tex+=r'\end{document}'
    (suite/'main.tex').write_text(tex,encoding='utf-8')
    with zipfile.ZipFile(suite/'OVERLEAF_REPORT.zip','w',zipfile.ZIP_DEFLATED) as z:
        z.writestr('main.tex',tex)
        for name in figures:z.write(figure_dir/(name+'.pdf'),'figures/'+name+'.pdf')
        for name in ['SUMMARY.csv','EPISODE_METRICS.csv','SUMMARY.json']:
            if (suite/name).is_file():z.write(suite/name,name)
    # Deployment archive includes every completed method and its PackNet state.
    with zipfile.ZipFile(suite/'SAVED_MODELS.zip','w',zipfile.ZIP_DEFLATED) as z:
        for method,record in methods.items():
            folder=suite/record['folder']
            for f in (folder/'checkpoints').rglob('*'):
                if f.is_file():z.write(f,method+'/'+f.relative_to(folder).as_posix())
            for name in ['algorithm_state.npz','DEPLOYMENT.json','INITIALIZATION.json']:
                if (folder/name).is_file():z.write(folder/name,method+'/'+name)
        z.writestr('README.txt','Load actor/critics using original classes and matching dimensions/settings. PackNet needs ownership masks restored from algorithm_state.npz plus on_test_start(case)/on_test_end(case) during inference. See adapter/experiment.py and DEPLOYMENT.json. This archive is not an exact mid-run SAC resume state.\n')
    print('REPORT:',suite/'REPORT.html',flush=True)
