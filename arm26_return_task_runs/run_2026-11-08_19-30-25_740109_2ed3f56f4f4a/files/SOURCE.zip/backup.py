"""Incremental verified Git backup; standalone recovery tool, no OpenSim/Torch needed."""
import argparse,contextlib,hashlib,json,os,subprocess,tempfile,time,zipfile,io
from pathlib import Path
REPO='https://github.com/hzolfaghari2022/Continual-Learning-with-human-in-the-loop.git'
CHUNK=40*1024*1024

def read(path):return json.loads(Path(path).read_text(encoding='utf-8-sig'))
def write(path,value):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    fd,name=tempfile.mkstemp(prefix=path.name+'.',suffix='.tmp',dir=path.parent)
    try:
        with os.fdopen(fd,'w',encoding='utf-8') as f:json.dump(value,f,indent=2,allow_nan=False)
        for i in range(8):
            try:os.replace(name,path);break
            except PermissionError:
                if i==7:raise
                time.sleep(min(.025*2**i,.4))
    finally:Path(name).unlink(missing_ok=True)
def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    return h.hexdigest()
def git(args,cwd=None):
    env=os.environ.copy();env['GIT_TERMINAL_PROMPT']='0'
    p=subprocess.run(['git','-c','core.longpaths=true','-c','core.quotepath=false',*map(str,args)],cwd=cwd,env=env,capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=180 if args and args[0]=='clone' else 120)
    if p.returncode:raise RuntimeError('git '+str(args[0])+': '+p.stderr[-3000:])
    return p.stdout if '--porcelain' in args else p.stdout.strip()

@contextlib.contextmanager
def cache_lock(cache):
    cache.mkdir(parents=True,exist_ok=True)
    with (cache/'backup.lock').open('a+b') as f:
        f.seek(0);f.write(b'0');f.flush();f.seek(0)
        try:
            if os.name=='nt':
                import msvcrt
                msvcrt.locking(f.fileno(),msvcrt.LK_NBLCK,1)
            else:
                import fcntl
                fcntl.flock(f.fileno(),fcntl.LOCK_EX|fcntl.LOCK_NB)
        except OSError as exc:raise RuntimeError('Another backup is active for this run. Retry after it finishes.') from exc
        try:yield
        finally:
            f.seek(0)
            if os.name=='nt':msvcrt.locking(f.fileno(),msvcrt.LK_UNLCK,1)
            else:fcntl.flock(f.fileno(),fcntl.LOCK_UN)

def snapshot_files(out):
    """Completed episodes only; incomplete native workers are not read mid-export."""
    complete={p.parent for p in out.rglob('CASE_COMPLETE.json')}
    for status in out.rglob('status.json'):
        try:
            s=read(status)
            if s.get('status') in ['completed','failed'] and (status.parent/'settings.json').exists():complete.add(status.parent)
        except (OSError,ValueError):pass
    for p in sorted(out.rglob('*')):
        if not p.is_file() or p.name=='GITHUB_STATUS.json' or p.suffix=='.tmp' or '__pycache__' in p.parts:continue
        rel=p.relative_to(out)
        if 'data' in rel.parts or rel.parts[0] in ['validation','test']:
            if not any(parent in complete for parent in p.parents):continue
        if p.name.endswith('.partial.csv'):continue
        yield p

def backup_experiment(out,source=None,reason='manual',final=False):
    out=Path(out).expanduser().resolve()
    if not out.is_dir():raise FileNotFoundError('Run folder not found: '+str(out))
    key=hashlib.sha256(str(out).encode()).hexdigest()[:12]
    cache=Path(os.environ.get('ARM26_VERIFIED_BACKUP_CACHE',str(Path.home()/'Arm26_Verified_Git_Backup')))/key
    previous=read(out/'GITHUB_STATUS.json') if (out/'GITHUB_STATUS.json').exists() else {}
    try:
        if source is not None and not (out/'SOURCE.zip').exists():
            source=Path(source).resolve();buffer=io.BytesIO()
            with zipfile.ZipFile(buffer,'w',zipfile.ZIP_DEFLATED) as z:
                for p in sorted(source.rglob('*')):
                    if p.is_file() and '__pycache__' not in p.parts and '.git' not in p.parts and p.suffix.lower() in ['.py','.md','.txt','.bat','.osim','.vtp']:z.write(p,p.relative_to(source))
            # This is only for a NEW run's known source, including environment failures.
            fd,tmp=tempfile.mkstemp(dir=out,prefix='source_',suffix='.tmp')
            try:
                with os.fdopen(fd,'wb') as f:f.write(buffer.getvalue())
                os.replace(tmp,out/'SOURCE.zip')
            finally:Path(tmp).unlink(missing_ok=True)
        with cache_lock(cache):
            clone=cache/'repo'
            if not (clone/'.git').exists():
                if clone.exists():
                    # Preserve incomplete caches rather than deleting anything.
                    clone.rename(cache/('interrupted_clone_'+str(time.time_ns())))
                # Do not download the repository's default branch/history/data.
                # Each run has its own branch, initialized locally first.
                clone.mkdir(parents=True,exist_ok=True)
                git(['init',clone]);git(['remote','add','origin',REPO],clone)
            if git(['remote','get-url','origin'],clone).rstrip('/')!=str(REPO).rstrip('/'):
                raise RuntimeError('Backup cache origin differs from the required repository; refusing to push to another destination.')
            branch='arm26-return-'+key
            if git(['branch','--list',branch],clone):git(['checkout',branch],clone)
            elif git(['ls-remote','--heads','origin','refs/heads/'+branch],clone):
                git(['fetch','--depth','1','--no-tags','origin',branch],clone);git(['checkout','-b',branch,'FETCH_HEAD'],clone)
            else:git(['checkout','-b',branch],clone)
            relative='arm26_return_task_runs/'+out.name+'_'+key;dest=clone/relative;dest.mkdir(parents=True,exist_ok=True)
            # Only this tool's namespace may contain pending generated files after a failed push.
            dirty=git(['status','--porcelain','-z'],clone)
            for entry in dirty.split('\0'):
                if entry and not entry[3:].startswith(relative+'/'):raise RuntimeError('Backup cache has unrelated pending changes; preserve it and inspect '+str(clone))
                if entry and '/objects/' in entry[3:] and entry[3:].endswith('.bin'):
                    obj=clone/entry[3:]
                    if sha(obj)!=obj.stem:raise RuntimeError('Changed/corrupt backup object detected; original local results remain safe: '+str(obj))
            index=dest/'LATEST_MANIFEST.json';old=read(index) if index.exists() else {};files={}
            for p in snapshot_files(out):
                rel=p.relative_to(out).as_posix();stat=p.stat();fingerprint=[stat.st_size,stat.st_mtime_ns]
                prior=old.get('files',{}).get(rel)
                if prior and prior.get('fingerprint')==fingerprint and all((dest/c['object']).exists() for c in prior['chunks']):
                    files[rel]=prior;continue
                # Read each chunk once and hash exactly the bytes being preserved.
                total=hashlib.sha256();chunks=[];size=0
                with p.open('rb') as f:
                    for payload in iter(lambda:f.read(CHUNK),b''):
                        h=hashlib.sha256(payload).hexdigest();name='objects/'+h+'.bin';obj=dest/name
                        if obj.exists():
                            if sha(obj)!=h:raise RuntimeError('Backup object is corrupt: '+str(obj))
                        else:
                            obj.parent.mkdir(parents=True,exist_ok=True);obj.write_bytes(payload)
                        total.update(payload);size+=len(payload);chunks.append(dict(object=name,sha256=h,size=len(payload)))
                # Atomic outputs can change between opening and stat; do not cache mutable files.
                stable=p.name not in ['RUN.log','HISTORY.json','RESUME.pt','COLLECTION_PROGRESS.json','TEST_RESULTS.json']
                files[rel]=dict(sha256=total.hexdigest(),size=size,chunks=chunks,fingerprint=fingerprint if stable else None)
            manifest=dict(format='arm26-content-addressed-v1',source_folder=str(out),files=files,note='Restore each file by concatenating its ordered chunks; verify the file SHA256. Git history preserves older manifests and objects. Partial native episodes are excluded until CASE_COMPLETE.json exists.')
            write(index,manifest)
            git(['add','-f','--',relative],clone)
            if git(['diff','--cached','--name-only'],clone):git(['commit','-m','Arm26 '+reason+' '+out.name],clone)
            # Rejection/divergence is a visible error; never force push or discard commits.
            git(['push','origin','HEAD:refs/heads/'+branch],clone)
            head=git(['rev-parse','HEAD'],clone);remote=git(['ls-remote','--heads','origin','refs/heads/'+branch],clone).split()[0]
            if head!=remote:raise RuntimeError('Remote tip verification failed; no success claimed.')
            committed=json.loads(git(['show',head+':'+relative+'/LATEST_MANIFEST.json'],clone))
            if committed!=manifest:raise RuntimeError('Committed manifest differs from uploaded snapshot.')
            status=dict(status='verified',repository=REPO,branch=branch,commit=head,commit_url=REPO.removesuffix('.git')+'/commit/'+head,folder=relative,reason=reason,final=final,files=len(files),verified_local_time=time.strftime('%Y-%m-%d %H:%M:%S'),note='Current snapshot verified at remote commit. External input dataset is backed up separately by its collector.')
            write(out/'GITHUB_STATUS.json',status)
            return status
    except Exception as exc:
        write(out/'GITHUB_STATUS.json',dict(status='failed',repository=REPO,error=str(exc),reason=reason,last_verified_commit=previous.get('commit',previous.get('last_verified_commit')),local_results_preserved=True))
        raise

def restore(backup_folder,destination):
    backup_folder=Path(backup_folder).resolve();destination=Path(destination).resolve();m=read(backup_folder/'LATEST_MANIFEST.json')
    for name,info in m['files'].items():
        out=(destination/name).resolve()
        if not out.is_relative_to(destination):raise ValueError('Unsafe restore path')
        if out.exists():
            if sha(out)!=info['sha256']:raise FileExistsError('Refusing to overwrite different local file: '+str(out))
            continue
        out.parent.mkdir(parents=True,exist_ok=True);fd,tmp=tempfile.mkstemp(dir=out.parent,prefix=out.name+'.')
        try:
            with os.fdopen(fd,'wb') as f:
                for chunk in info['chunks']:
                    path=(backup_folder/chunk['object']).resolve()
                    if not path.is_relative_to(backup_folder) or sha(path)!=chunk['sha256']:raise ValueError('Restore chunk missing/corrupt')
                    with path.open('rb') as src:
                        for data in iter(lambda:src.read(1024*1024),b''):f.write(data)
            if sha(tmp)!=info['sha256']:raise ValueError('Restored file checksum failed')
            os.replace(tmp,out)
        finally:Path(tmp).unlink(missing_ok=True)

if __name__=='__main__':
    p=argparse.ArgumentParser(description='Back up a saved/active run without OpenSim or retraining.')
    g=p.add_mutually_exclusive_group(required=True);g.add_argument('--out',type=Path);g.add_argument('--latest-data',action='store_true');g.add_argument('--latest-results',action='store_true');g.add_argument('--restore',type=Path)
    p.add_argument('--destination',type=Path);a=p.parse_args()
    try:
        if a.restore:
            if not a.destination:p.error('--restore needs --destination')
            restore(a.restore,a.destination);print('RESTORE VERIFIED:',a.destination)
        else:
            out=a.out
            if out is None:
                root=Path.home()/('Arm26_Return_Task_Data' if a.latest_data else 'Arm26_Return_Task_Results');out=Path(read(root/'LAST_RUN.json')['folder'])
            result=backup_experiment(out,reason='standalone retry',final=False)
            print('GITHUB VERIFIED:',result['commit']);print('REPOSITORY:',result['repository']);print('BRANCH:',result['branch']);print('FOLDER:',result['folder'])
    except Exception as exc:
        print('BACKUP/RESTORE FAILED:',exc,file=__import__('sys').stderr);raise SystemExit(1)
