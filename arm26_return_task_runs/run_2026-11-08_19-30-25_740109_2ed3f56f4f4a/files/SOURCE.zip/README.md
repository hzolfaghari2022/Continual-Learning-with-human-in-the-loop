# Fresh Arm26 data generation and sequential neural-network comparison

This release has two separate packages and two distinct Python entry points:

1. DATA package: collect_data.py — generate exactly250 TOTAL full teacher episodes.
2. NN package: train_nn.py — create a fresh NN, learn A, then compare ordinary
   sequential training with target-task replay continually learning on B,C,D.

Use a NEW extracted folder for each package. Your older datasets and results are
not deleted, overwritten, or required. The existing lstm-py312 environment must
have the same working OpenSim4.6, NumPy, PyTorch CUDA, matplotlib and Git setup
that ran the successful recovery. No administrator installation is attempted.

## The easiest VS Code instructions

DATA:
- Extract Arm26_Fresh_Data_Collection.zip.
- VS Code: File > Open Folder. Select the folder containing collect_data.py.
- Press F5. Choose the supplied launch configuration if prompted.
- Wait for SAVED, REPORT and GITHUB VERIFIED. The report is REPORT.html.

NN:
- Extract Arm26_Fresh_NN_Comparison.zip.
- VS Code: File > Open Folder. Select the folder containing train_nn.py.
- Press F5. It automatically reads the completed fresh dataset's LAST_RUN.json.
- Wait for the final report/verified backup. Do not launch duplicate jobs.

F5 configurations directly select
%USERPROFILE%\miniconda3\envs\lstm-py312\python.exe.
They do not depend on the active shell folder or conda activate. A START_*.bat
launcher is supplied too; double-click it if preferred. Do not run helper files
such as flow.py, learning.py or core/complex_engine.py directly.

Terminal alternative (only from the appropriate extracted package folder):

    & "$env:USERPROFILE\miniconda3\envs\lstm-py312\python.exe" -X utf8 .\collect_data.py --episodes 250 --workers 4

or

    & "$env:USERPROFILE\miniconda3\envs\lstm-py312\python.exe" -X utf8 .\train_nn.py --latest-data --workers 4

## Dated output and storage

Data: %USERPROFILE%\Arm26_Fresh_Data\run_DATE_TIME_MICROSECONDS
NN:   %USERPROFILE%\Arm26_Fresh_Results\run_DATE_TIME_MICROSECONDS

Each output has all newly generated artifacts for that run. NN training reads the
external data folder without duplicating it. Keep the dataset until training and
verified backup are complete. No cleanup/deletion is performed. The separate Git
backup cache also consumes space; see BACKUP_POLICY.md. The default5GiB free-space
reserve stops work before an export exhausts the drive.

## Data and physics

250 means TOTAL episodes, not250 per task. Default split:175 training,25 validation,
50 held-out test parent episodes. Task allocations:
A_90:44/6/13; B_60:44/6/13; C_30:44/6/12; D_45:43/7/12.
All time samples and instantaneous teacher queries remain with their parent split.
Starting reference angles50,60,70,80deg and both trajectory variants occur in every
split. Initial recovery combinations may recur across splits; claim generalization
to separate full reference episodes, not universally unseen initial states.

5kg dumbbell, control step0.005s, muscle excitation0.1. Muscle strengths are90%,60%,
30%,45% respectively. A:vertical reaches; B:variable speeds/reversals; C:cross-body
motion via prescribed yaw; D:reach/hold with known load pulses. Four copied-state
teacher queries every0.2s cover local recovery; these are not new integrated episodes.
The accepted affine-dynamics/PID teacher produces cable-force labels. Full compact
28-feature arrays, labels, times, settings, signals and model audits are retained.

No live viewer is required. OpenSim physics runs on CPU workers; OpenSim forward
dynamics is not a CUDA solver. BOTH ordinary-NN and CL training run on CUDA only.
Four independent headless physics workers are used by default. No silent CPU NN
training fallback is allowed.

## Experiment from scratch

Order is predeclared A_90 -> B_60 -> C_30 -> D_45 -> frozen return A_90.
The first A network is freshly initialized; no old model/result path is hard-coded.

Initial learning:
-6081-parameter direct force MLP,28 inputs,64tanh,64tanh,1 linear force output.
-600 ordinary-MSE CUDA epochs, Adam0.001, cosine decay to5%, batch2048.
-Then up to200 CUDA recovery epochs from that newly trained model, Adam0.0001.
-Recovery objective: weighted normalized-force MSE +0.1 local corrective-response
 penalty. Trajectory weights:first0.25s=25, remaining first1s=8, otherwise1;
 teacher-query rows=6. Finite differences use encoded step0.05, minimum corrective
 slope0.02, up to128 training examples per batch. This encourages corrective
 feedback but DOES NOT guarantee closed-loop stability.
-Physical validation at recovery epochs50,100,200 (capped by requested budget).
 Stop at the FIRST candidate passing ALL initial target references: completed,
 motion RMSE<=0.5deg AND motion max<=2deg. The3–123deg elbow envelope stays active.
-This incorporates the method that passed all six initial A validations in your
 earlier run. A fresh run must still demonstrate its own accuracy.

Sequential comparison:
-The accepted A checkpoint is copied byte-for-byte into the shared model path.
 Ordinary NN and every CL candidate start from EXACTLY those weights.
-Ordinary NN trains B,C,D on current-task examples only:120epochs/task, Adam0.001,
 optimizer reset at task boundaries, final fixed-budget checkpoint.
-CL trains the same B,C,D, with identical current-task batches/permutations/update
 counts and identical current-task loss. It also replays up to512 examples/update
 from a fixed1024-example A TRAINING-only buffer. Memory prioritizes startup states,
 then stratifies by parent episode/query type; full old weights are not CL memory.
-CL loss=current weighted force/response loss + beta times the same loss on memory.
 Replay weights1,4,16 are compared on validation only. Replay adds computation/old
 data access, so total examples and wall time are NOT equal between branches.
-New-task validation force RMSE must be within1.5x ordinary NN, with a1N floor.
 Eligible candidates prefer all-reference target accuracy, then lower mean target
 validation angle RMSE, then smaller beta. All candidates/failures are retained.
 No fallback is silently selected if all candidates fail adaptation constraints.
-Models, memory and selection are frozen before held-out test values are decoded.
-Target A held-out episodes are tested with the shared-initial, ordinary-final and
 selected-CL-final models, without updates on return. Final D is tested separately
 for both branches. Default test rollouts:39 A +24 D =63.

These are learned NN feedback controllers. Error, bounded integral, previous cable
force, measured muscle/state variables and known task parameters are NN inputs;
there is no separate PID added at NN deployment. No physical-sensor implementation
or universal stability guarantee is claimed.

## Progress, reports and interpretation

The terminal refreshes every2s with CURRENT phase iteration/total and percentage.
Percentages count epochs or episodes IN THAT PHASE; they are not a total runtime
estimate. GitHub backup shows an elapsed waiting indicator until remote verification;
transfer percentage is not invented. Detailed output is in RUN.log. PROGRESS.json
can be inspected independently. A diagnostic phase can legitimately stop before
held-out tests if scientific acceptance fails; this produces a report, not fabricated
tracking success.

Both packages produce REPORT.html and OVERLEAF_REPORT.zip. Collection also creates
DATA_SUMMARY.json and EPISODES.csv. NN produces learning curves, force metrics,
angle/velocity/error overlays, every target-reference gallery, all attempted episode
metrics/failures, split counts,28input definitions, topology, loss/memory/selection
explanations and limitations. Labels explicitly distinguish the shared A model
BEFORE B/C/D from ordinary/CL models AFTER B/C/D; they do not call recovery tuning
continual learning. Figures are generated from actual saved signals. Failed trials
have no invented final RMSE; partial metrics/failure counts are separate.

CONTEXT.zip is the diagnostic upload after
a run. Full large arrays are excluded from NN context because the collector owns
and backs them up. No dramatic baseline failure, perfect CL tracking, or CL
superiority is guaranteed. A single seed is exploratory, not statistical proof.

## Resume and backup

Keep source and options unchanged. DATA interrupted:

    python -X utf8 collect_data.py --resume-latest --episodes 250 --workers 4

NN interrupted:

    python -X utf8 train_nn.py --resume-latest --workers 4

Use the environment's full Python path if the terminal interpreter is uncertain.
Completed native episodes/checkpoints are verified and reused; optimizer state,
shuffle/replay generator state and epoch history are restored. --out FULL_FOLDER
selects an explicit existing run. Model/source/data corruption causes a clear stop;
no files are silently changed to bypass a hash check.

For GitHub-only retry, add --backup-only --resume-latest to the appropriate launcher.
No simulation or training is executed in backup-only mode. Every successful run
prints a VERIFIED remote commit URL. Full input data are backed up by the collector;
NN-result backup does not duplicate the external input dataset.

## Verification and limits

Compile/CLI checks; mocked250episode end-to-end collection and NN workflow; matching
branch initialization; held-out test lock/seal; initial/CL gating failures; repeat
resume; actual uploaded206394-row A data weighting/memory tests; corrective-response
direction checks; HTML/report generation and Overleaf compile; final packaged no-clone
backup integration tests against a local bare Git remote. Mocked workflows are NOT
measurements of physical tracking or GPU performance. CUDA/OpenSim cannot run in the
build environment, so final native execution must be verified on your Windows PC.
The supplied code does not promise zero environment/runtime errors.
