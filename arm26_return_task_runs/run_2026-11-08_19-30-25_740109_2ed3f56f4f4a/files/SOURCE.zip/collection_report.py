"""Compact data-readiness report, including honest partial/error output."""
import csv,html,io,json,zipfile
from pathlib import Path
from complex_engine import read,write

def build_error_report(out,error):
    out=Path(out);(out/'ERROR_REPORT.html').write_text('<html><meta charset="utf-8"><h1>Run stopped</h1><p>'+html.escape(error)+'</p><p>Completed data/checkpoints are preserved. Inspect RUN.log and GITHUB_STATUS.json. No missing results are counted as zero.</p></html>',encoding='utf-8')

def build_collection_report(out):
    out=Path(out);manifest=read(out/'COLLECTION_COMPLETE.json');rows=[];quality=[]
    for r in manifest['episodes']:
        folder=out/r['folder'].replace('\\','/');s=read(folder/'status.json');m=s.get('motion_only') or {}
        quality.append(dict(episode_id=r['episode_id'],task=r['task'],split=r['split'],accepted=bool(s.get('accepted_for_imitation')),completed=s['status']=='completed',motion_rmse_deg=m.get('rmse_deg'),full_max_error_deg=(s.get('all_samples') or {}).get('max_abs_error_deg'),trajectory_rows=r['samples'],query_rows=r['probes']))
    for task in ['A_90','B_60','C_30','D_45']:
        for split in ['train','validation','test']:
            rr=[r for r in quality if r['task']==task and r['split']==split]
            rows.append(dict(task=task,split=split,episodes=len(rr),trajectory_rows=sum(r['trajectory_rows'] for r in rr),query_rows=sum(r['query_rows'] for r in rr),worst_teacher_motion_rmse_deg=max((r['motion_rmse_deg'] for r in rr if r['motion_rmse_deg'] is not None),default=None)))
    write(out/'DATA_SUMMARY.json',dict(episodes=len(quality),all_accepted=all(r['accepted'] for r in quality),groups=rows,physics='CPU OpenSim; no viewer',next_step='Run train_nn.py in the neural-network package. CUDA is required for NN optimization.'))
    with (out/'EPISODES.csv').open('w',encoding='utf-8',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(quality[0]));w.writeheader();w.writerows(quality)
    def table(headers,rs):return '<table><tr>'+''.join('<th>'+html.escape(str(h))+'</th>' for h in headers)+'</tr>'+''.join('<tr>'+''.join('<td>'+html.escape(str(v))+'</td>' for v in row)+'</tr>' for row in rs)+'</table>'
    intro='Generated '+str(len(quality))+' complete accepted OpenSim teacher episodes. All data stay inside this timestamped folder. No neural network has been trained yet.'
    method='Tasks: A_90 vertical reaches (90% muscle strength), B_60 variable speeds/reversals (60%), C_30 cross-body motion (30%), D_45 reach/hold with known load pulses (45%). Fixed 5 kg dumbbell, 0.005 s control samples, muscle excitation 0.1. Whole parent episodes are split before fitting: default 175 train,25 validation,50 test. Four instantaneous copied-state teacher queries every 0.2 s add recovery examples, not integrated episodes. Startup combinations may recur across episode splits; this is not a claim that all initial states are unseen. OpenSim dynamics uses CPU workers and no viewer; CUDA is for the later NN optimization. The 28-feature arrays, force labels, time stamps, settings, compact signals and hashes are retained. Test data may be audited for teacher quality here, but the NN trainer locks test decoding until all models and validation-only selection are frozen.'
    headers=['Task','Split','Episodes','Trajectory rows','Recovery query rows','Worst teacher motion RMSE (deg)'];body=[[r[k] for k in ['task','split','episodes','trajectory_rows','query_rows','worst_teacher_motion_rmse_deg']] for r in rows]
    page='<html><meta charset="utf-8"><style>body{font:17px Georgia;max-width:1050px;margin:30px auto;line-height:1.5}td,th{padding:8px;border-bottom:1px solid #ccc}</style><h1>Data collection report</h1><p>'+html.escape(intro)+'</p><p>'+html.escape(method)+'</p>'+table(headers,body)+'<h2>Next step</h2><p>Run train_nn.py from the NN package. It reads the completed folder recorded in Arm26_Fresh_Data/LAST_RUN.json. Keep this dataset until training and backups have been verified.</p></html>'
    (out/'REPORT.html').write_text(page,encoding='utf-8')
    from target_report import texescape,table_tex
    tex=r'\documentclass[11pt]{article}\usepackage[margin=0.7in]{geometry}\usepackage{longtable,booktabs}\begin{document}\section*{Data collection report}'+'\n'+texescape(intro)+'\n\n'+texescape(method)+'\n'+table_tex(['Task','Split','Episodes','Rows','Queries','Max teacher RMSE'],[[r[0],r[1],r[2],r[3],r[4],f'{r[5]:.4f}' if r[5] is not None else '--'] for r in body])+r'\end{document}'
    with zipfile.ZipFile(out/'OVERLEAF_REPORT.zip','w',zipfile.ZIP_DEFLATED) as z:z.writestr('main.tex',tex)
    with zipfile.ZipFile(out/'CONTEXT.zip','w',zipfile.ZIP_DEFLATED) as z:
        for p in sorted(out.rglob('*')):
            if p.is_file() and p.name!='CONTEXT.zip' and p.suffix in ['.json','.html','.zip','.log','.txt'] and 'interrupted' not in p.parts:z.write(p,p.relative_to(out))
