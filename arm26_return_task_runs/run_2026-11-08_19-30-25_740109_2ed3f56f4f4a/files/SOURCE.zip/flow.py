"""Targeted return-task retention. Collection is separate; old studies stay read-only."""
import argparse,contextlib,csv,hashlib,io,json,math,os,sys,time,zipfile
from concurrent.futures import ThreadPoolExecutor,wait,FIRST_COMPLETED
from datetime import datetime
from pathlib import Path
from types import SimpleNamespace
import numpy as np
from complex_engine import read,write,sha
from atomic_io import atomic_bytes
from complex_trajectories import FEATURES,encode
from four_trajectories import reference_digest
from task_plan import make_episode
from process_helpers import run_logged
from storage_guard import require_space
ROOT=Path(__file__).resolve().parent;CORE=ROOT/'core'
TASKS={'A':'A_90','B':'B_60','C':'C_30','D':'D_45'}

from progress import Progress

def signature(value):return hashlib.sha256(json.dumps(value,sort_keys=True,allow_nan=False).encode()).hexdigest()
def winpath(value):return Path(value.replace('\\','/'))
def relative_file(root,name):
    p=(root/winpath(name)).resolve()
    if not p.is_relative_to(root.resolve()):raise ValueError('Path escapes dataset/study: '+name)
    return p
def source_hashes():
    files=list(ROOT.glob('*.py'))+list(CORE.glob('*.py'))+[CORE/'arm26_exosuit.osim']+list((CORE/'Geometry').glob('*.vtp'))
    return {p.relative_to(ROOT).as_posix():sha(p) for p in sorted(files)}
def publish_npz(path,**arrays):
    b=io.BytesIO();np.savez_compressed(b,**arrays);atomic_bytes(path,b.getvalue())

def new_output(a,p,kind):
    home=Path.home()/('Arm26_Fresh_Data' if kind=='collect' else 'Arm26_Fresh_Results');index=home/'LAST_RUN.json'
    if a.resume_latest:
        if not index.exists():p.error('No previous run is recorded. Start a new run first.')
        folder=Path(read(index)['folder'])
        if not folder.is_dir():p.error('The last folder was deleted/moved. Use --out with its actual path.')
    elif a.out:folder=a.out.expanduser().resolve()
    else:folder=(a.output_root or home)/('run_'+datetime.now().astimezone().strftime('%Y-%m-%d_%H-%M-%S_%f'))
    folder=folder.resolve()
    if folder==ROOT or folder.is_relative_to(ROOT):p.error('Save results outside the code folder.')
    folder.mkdir(parents=True,exist_ok=True);require_space(folder)
    return folder,index

def lock_output(a,index,protocol):
    file=a.out/'PROTOCOL.json'
    if file.exists() and read(file)!=protocol:raise ValueError('Output protocol/source/options changed. Resume with original code/options or choose a new output.')
    if not file.exists():write(file,protocol)
    now=datetime.now().astimezone().isoformat()
    if not (a.out/'RUN_INFO.json').exists():write(a.out/'RUN_INFO.json',dict(created_local=now,folder=str(a.out)))
    write(index,dict(folder=str(a.out),last_selected_local=now))
    if not (a.out/'SOURCE.zip').exists():
        b=io.BytesIO()
        with zipfile.ZipFile(b,'w',zipfile.ZIP_DEFLATED) as z:
            for n in source_hashes():z.write(ROOT/n,n)
            for extra in [*ROOT.glob('*.bat'),*ROOT.glob('*.ps1'),*(ROOT/'.vscode').glob('*.json')]:
                if extra.is_file():z.write(extra,extra.relative_to(ROOT))
            for n in ['README.md','CORRECTED_PROMPT.txt','BACKUP_POLICY.md']:
                if (ROOT/n).exists():z.write(ROOT/n,n)
        atomic_bytes(a.out/'SOURCE.zip',b.getvalue())
    checkpoint_backup(a,'run initialized')

def checkpoint_backup(a,reason):
    callback=getattr(a,'checkpoint_backup',None)
    if callback is not None:callback(reason)

def episode(folder,cfg,a):
    folder=Path(folder);folder.mkdir(parents=True,exist_ok=True);identity=dict(settings=signature(cfg),engine=sha(CORE/'complex_engine.py'),policy=sha(CORE/'policy_numpy.py'))
    if cfg.get('neural_checkpoint'):
        identity['model']={n:sha(Path(cfg['neural_checkpoint']).parent/n) for n in ['policy.pt','policy_inference.npz','policy_inference.json']}
    marker=folder/'CASE_COMPLETE.json'
    if marker.exists():
        old=read(marker)
        if old['identity']!=identity or any(sha(folder/n)!=h for n,h in old['hashes'].items()):raise ValueError('Completed evaluation changed: '+str(folder))
        return read(folder/'status.json')
    if any(folder.iterdir()):
        archive=folder.parent/'interrupted';archive.mkdir(exist_ok=True);folder.rename(archive/(folder.name+'_'+str(time.time_ns())));folder.mkdir()
    require_space(folder);write(folder/'settings.json',cfg)
    run_logged([sys.executable,'-X','utf8',CORE/'complex_engine.py','--worker',folder],folder/'console.log',allowed=(0,2),timeout=a.episode_timeout)
    status=read(folder/'status.json')
    if status.get('export_error'):raise RuntimeError(status['export_error'])
    error=status.get('error','')
    if status['status']=='failed' and any(s in error for s in ['ImportError','ModuleNotFoundError','AttributeError','TypeError','OSError','PermissionError','MemoryError','live_viewer.py']):raise RuntimeError('Infrastructure failure: '+error)
    if cfg.get('neural_checkpoint') and not status.get('frozen_weights_verified'):raise RuntimeError('Frozen-model verification failed: '+str(folder))
    names=[n for n in ['settings.json','status.json','signals.csv','training_arrays.npz','probe_arrays.npz'] if (folder/n).exists()]
    write(marker,dict(identity=identity,hashes={n:sha(folder/n) for n in names}))
    return status

def collection_plan(options=None):
    options=options or SimpleNamespace(data_seed=2026110810,initial_angles=[50.,60.,70.,80.],episodes=250,train_reps=None,validation_reps=None,test_reps=None)
    args=SimpleNamespace(seed=options.data_seed,initial_errors=[-2.,0.,2.],initial_velocities=[-15.,0.,15.],mass_kg=5.,dt=.005,muscle_excitation=.1,rmse_limit=.2,max_error_limit=3.)
    configs=[]
    if getattr(options,'episodes',None) is not None:
        n=options.episodes;split_totals=[('train',int(.7*n+.5)),('validation',int(.1*n+.5))]
        split_totals.append(('test',n-sum(v for _,v in split_totals)))
        tasks=list(TASKS.values());quotas={t:{} for t in tasks};cursor=0
        for split,total in split_totals:
            for t in tasks:quotas[t][split]=0
            for i in range(total):quotas[tasks[(cursor+i)%len(tasks)]][split]+=1
            cursor+=total
        for task in tasks:
            # Interleave angles and variants so small validation allocations cover
            # all four default angles and both variants as evenly as possible.
            conditions=[dict(task_id=task,variant=['A','B'][(i+round_)%2],start_deg=q,key=f'{task}_{["A","B"][(i+round_)%2]}_e{q:g}') for round_ in range(2) for i,q in enumerate(options.initial_angles)]
            for split,_ in split_totals:
                for i in range(quotas[task][split]):
                    condition=conditions[i%len(conditions)];rep=i//len(conditions)
                    c=make_episode(args,condition,split,rep,factor=.8)
                    c.update(collect_probes=True,compact_export=True,live_viewer=False,save_plots=False);configs.append(c)
        return configs
    for task in TASKS.values():
        for variant in ['A','B']:
            for angle in options.initial_angles:
                condition=dict(task_id=task,variant=variant,start_deg=angle,key=f'{task}_{variant}_e{angle:g}')
                for split,n in [('train',options.train_reps),('validation',options.validation_reps),('test',options.test_reps)]:
                    for rep in range(n):
                        c=make_episode(args,condition,split,rep,factor=.8)
                        c.update(collect_probes=True,compact_export=True,live_viewer=False,save_plots=False);configs.append(c)
    return configs

def collect(a,index,console):
    plan=collection_plan(a)
    counts={t:{s:sum(c['task_id']==t and c['split']==s for c in plan) for s in ['train','validation','test']} for t in TASKS.values()}
    protocol=dict(kind='return_task_collection_v3_exact_budget',source_hashes=source_hashes(),plan=plan,split_counts=counts,seed=a.data_seed,total_episodes=len(plan),split='Full parent episodes; all instantaneous queries inherit parent split. Default 175 train / 25 validation / 50 test, task totals within one episode.',execution='Headless CPU OpenSim workers. CUDA does not accelerate this engine.')
    lock_output(a,index,protocol);a.progress.stage('Data episodes',len(plan));records={}
    def work(cfg):
        folder=a.out/'data'/cfg['task_id']/cfg['split']/cfg['episode_id'];status=episode(folder,cfg,a)
        if not status.get('accepted_for_imitation'):raise RuntimeError('Teacher failed quality criteria. Inspect '+str(folder/'status.json')+'. No automatic gain/speed changes were made.')
        return dict(task=cfg['task_id'],split=cfg['split'],episode_id=cfg['episode_id'],folder=folder.relative_to(a.out).as_posix(),reference_sha256=cfg['reference_sha256'],samples=status['sample_count'],probes=status.get('instantaneous_teacher_probe_count',0),hashes={n:sha(folder/n) for n in ['settings.json','status.json','training_arrays.npz','probe_arrays.npz']})
    # Keep only a bounded number in flight; a failure cannot leave hundreds queued.
    pending={};it=iter(plan);pool=ThreadPoolExecutor(max_workers=a.workers)
    try:
        for _ in range(min(a.workers,len(plan))):
            cfg=next(it);pending[pool.submit(work,cfg)]=cfg
        while pending:
            done,_=wait(pending,return_when=FIRST_COMPLETED)
            for future in done:
                pending.pop(future);record=future.result();records[record['episode_id']]=record
                write(a.out/'COLLECTION_PROGRESS.json',dict(done=len(records),total=len(plan),workers=a.workers));a.progress.advance()
                if len(records)%getattr(a,'github_every',10)==0:checkpoint_backup(a,'data episodes '+str(len(records)))
                cfg=next(it,None)
                if cfg is not None:pending[pool.submit(work,cfg)]=cfg
    except BaseException:
        for future in pending:future.cancel()
        raise
    finally:pool.shutdown(wait=True,cancel_futures=True)
    ordered=[records[c['episode_id']] for c in plan]
    write(a.out/'COLLECTION_COMPLETE.json',dict(protocol_sha256=sha(a.out/'PROTOCOL.json'),episodes=ordered,split_counts=counts,total_episodes=len(ordered)))
    checkpoint_backup(a,'collection complete')

class Dataset:
    def __init__(self,folder):
        self.root=Path(folder).expanduser().resolve();self.manifest=read(self.root/'COLLECTION_COMPLETE.json');self.source_protocol=read(self.root/'PROTOCOL.json')
        if sha(self.root/'PROTOCOL.json')!=self.manifest['protocol_sha256']:raise ValueError('Collection protocol changed')
        original=self.source_protocol['source_hashes']
        model_key=next(k for k in original if k.replace('\\','/')=='core/arm26_exosuit.osim')
        if sha(CORE/'arm26_exosuit.osim')!=original[model_key]:raise ValueError('Dataset OpenSim model differs from this release')
        seen=set();self.records=self.manifest['episodes']
        for r in self.records:
            if r['episode_id'] in seen:raise ValueError('Duplicate parent episode across splits')
            seen.add(r['episode_id']);folder=relative_file(self.root,r['folder'])
            for n,h in r['hashes'].items():
                if sha(folder/n)!=h:raise ValueError('Dataset file missing/changed: '+str(folder/n))
            cfg=read(folder/'settings.json');status=read(folder/'status.json')
            if not status.get('accepted_for_imitation') or cfg['split']!=r['split'] or cfg['task_id']!=r['task'] or cfg['episode_id']!=r['episode_id']:raise ValueError('Unaccepted or incorrectly split teacher episode')
            if reference_digest(cfg)!=r['reference_sha256']:raise ValueError('Reference definition changed')
        for task in TASKS.values():
            for split in ['train','validation','test']:
                if not self.records_for(task,split):raise ValueError('Missing task/split '+task+'/'+split)
        self.test_unlocked=False;self.loss_weights={}
    def records_for(self,task,split):return sorted([r for r in self.records if r['task']==task and r['split']==split],key=lambda r:r['episode_id'])
    def load(self,task,split):
        if split=='test' and not self.test_unlocked:raise RuntimeError('Held-out values remain locked until models/selection are sealed.')
        xs=[];ys=[];groups=[];weights=[]
        for r in self.records_for(task,split):
            folder=relative_file(self.root,r['folder'])
            for name,role in [('training_arrays.npz','trajectory'),('probe_arrays.npz','probe')]:
                p=folder/name
                if sha(p)!=r['hashes'][name]:raise ValueError('Dataset changed during run')
                with np.load(p,allow_pickle=False) as z:
                    if z['feature_names'].tolist()!=FEATURES:raise ValueError('Feature order differs')
                    x=encode(z['X_raw']);y=z['y_force_N']/650;times=z['time_s']
                if x.shape!=(len(y),28) or y.shape!=(len(x),1) or not np.isfinite(x).all() or not np.isfinite(y).all():raise ValueError('Invalid teacher arrays')
                w=np.full(len(x),6. if role=='probe' else 1.,np.float32)
                if role=='trajectory':w[times<1.]=8.;w[times<.25]=25.
                weights.append(w);xs.append(x);ys.append(y);groups.extend([r['episode_id']+'/'+role]*len(x))
        self.loss_weights[(task,split)]=np.concatenate(weights)
        return (np.concatenate(xs),np.concatenate(ys)),np.array(groups)

def checkpoint(base,rel):return base/rel/'policy.pt'
def seal(a):
    files={p.relative_to(a.out).as_posix():sha(p) for p in sorted((a.out/'models').rglob('*')) if p.is_file() and p.name in ['policy.pt','policy_inference.npz','policy_inference.json','COMPLETE.json']}
    for n in ['SELECTION.json','memory_target.npz','memory_target.json','INITIAL_VALIDATION.json']:
        if (a.out/n).exists():files[n]=sha(a.out/n)
    file=a.out/'FINAL_MODELS_FROZEN.json';payload=dict(protocol_sha256=sha(a.out/'PROTOCOL.json'),collection_sha256=sha(a.out/'COLLECTION_COMPLETE.json'),hashes=files)
    if file.exists() and read(file)!=payload:raise ValueError('Sealed experiment changed; refusing to rewrite seal.')
    if not file.exists():write(file,payload)
    verify_seal(a)
def verify_seal(a):
    s=read(a.out/'FINAL_MODELS_FROZEN.json')
    if s['protocol_sha256']!=sha(a.out/'PROTOCOL.json') or s['collection_sha256']!=sha(a.out/'COLLECTION_COMPLETE.json'):raise ValueError('Sealed protocol/collection changed')
    for n,h in s['hashes'].items():
        if sha(relative_file(a.out,n))!=h:raise ValueError('Sealed artifact changed: '+n)

def evaluate_return(a,data,policy,task,split,label,sealed=False):
    rows={};records=data.records_for(task,split)
    a.progress.stage(label+' '+split,len(records))
    if split=='test' and not sealed:raise RuntimeError('Testing requires a frozen-model seal')
    def work(r):
        if sealed:verify_seal(a)
        cfg=read(relative_file(data.root,r['folder'])/'settings.json');cfg.pop('muscle_strength_audit',None)
        cfg.update(neural_checkpoint=str(policy.resolve()),collect_probes=False,compact_export=True,live_viewer=(split=='test' and not a.no_viewer),save_plots=False,accept_rmse_deg=2.,accept_max_error_deg=5.)
        folder=a.out/split/label/r['episode_id'];status=episode(folder,cfg,a)
        st=status.get('motion_only') or {};allm=status.get('all_samples') or {};motion=[]
        if (folder/'signals.csv').exists():
            with (folder/'signals.csv').open(encoding='utf-8',newline='') as f:motion=[z for z in csv.DictReader(f) if int(z['moving'])]
        motion_max=max((abs(float(z['error_deg'])) for z in motion),default=None)
        speed_rmse=float(np.sqrt(np.mean([(math.degrees(float(z['reference_velocity_rad_s'])-float(z['velocity_rad_s'])))**2 for z in motion]))) if motion else None
        passed=bool(status['status']=='completed' and st and st['rmse_deg']<=a.target_rmse and motion_max is not None and motion_max<=a.target_max and not status.get('geometry_rejection'))
        return dict(task=task,split=split,label=label,episode_id=r['episode_id'],completed=status['status']=='completed',rmse_deg=st.get('rmse_deg') if status['status']=='completed' else None,partial_rmse_deg=st.get('rmse_deg') if status['status']!='completed' else None,motion_max_error_deg=motion_max,all_max_error_deg=allm.get('max_abs_error_deg'),speed_rmse_deg_s=speed_rmse,saturation_percent=st.get('saturation_percent'),high_accuracy=passed,error=status.get('error'),folder=folder.relative_to(a.out).as_posix())
    workers=getattr(a,'workers',1) if (a.no_viewer or split!='test') else 1
    pending={};it=iter(records);pool=ThreadPoolExecutor(max_workers=workers)
    try:
        for _ in range(min(workers,len(records))):
            r=next(it);pending[pool.submit(work,r)]=r
        while pending:
            done,_=wait(pending,return_when=FIRST_COMPLETED)
            for future in done:
                pending.pop(future);row=future.result();rows[row['episode_id']]=row;a.progress.advance()
                if len(rows)%getattr(a,'github_every',10)==0:checkpoint_backup(a,label+' '+split+' episodes '+str(len(rows)))
                r=next(it,None)
                if r is not None:pending[pool.submit(work,r)]=r
    except BaseException:
        for future in pending:future.cancel()
        raise
    finally:pool.shutdown(wait=True,cancel_futures=True)
    checkpoint_backup(a,label+' '+split+' group complete')
    return [rows[r['episode_id']] for r in records]

def comparison(a,index,console):
    from learning import fit,make_memory
    data=Dataset(a.collection);order=[TASKS[t] for t in a.order];target=TASKS[a.return_task];target_index=order.index(target);prefix=order[:target_index+1];suffix=order[target_index+1:]
    protocol=dict(kind='fresh_sequential_replay_v1',source_hashes=source_hashes(),collection_path=str(data.root),collection_manifest_sha256=sha(data.root/'COLLECTION_COMPLETE.json'),order=order,return_task=target,seed=a.seed,common_epochs=a.common_epochs,adapt_epochs=a.adapt_epochs,lr=.001,batch_size=2048,replay_weights=[1.,4.,16.],memory_rows=1024,target_rmse_deg=a.target_rmse,target_motion_max_deg=a.target_max,adaptation_tolerance=1.5,training_device='cuda REQUIRED; no CPU fallback',physics_device='CPU OpenSim; headless unless --viewer',baseline='ordinary current-task fine-tuning; no replay, no deliberate degradation',continual_learning='target-only episodic replay, 1024 startup-priority/stratified training examples; weighted force and corrective-response replay loss; validation-only selection',initial_rule='Fresh 600-epoch ordinary-MSE fit (configurable), then up to 200 CUDA recovery epochs with startup/query weights and corrective-response penalty. First recovery checkpoint at 50/100/200 epochs passing all six target validation trials becomes the shared starting model; tests remain locked',later_rule='Both branches use identical startup/query-weighted current-task loss plus 0.1 corrective-response penalty, same current-task batches/order/update budgets, and final checkpoints. Replay adds <=512 target examples/update; its extra loss uses the same weighting/response rule',test_rule='return-task test episodes are predeclared by collection split; no fitting or reselection; also report final new-task test performance',units='angle RMSE and motion maximum in degrees; velocity RMSE in degrees/s; forces in N; return accuracy gate excludes initial recovery hold but full maximum is also reported',limitations='More episodes do not guarantee sufficient coverage. No guaranteed perfect tracking, baseline failure, CL benefit or statistical significance from one seed.')
    protocol.update(recovery_epochs=a.recovery_epochs,recovery_lr=.0001,recovery_milestones=sorted(set([min(50,a.recovery_epochs),min(100,a.recovery_epochs),a.recovery_epochs])),weighting=dict(startup_first_quarter_second=25,startup_rest_first_second=8,other_trajectory=1,teacher_queries=6),response_penalty=dict(coefficient=.1,minimum_encoded_slope=.02,encoded_step=.05,max_examples=128))
    lock_output(a,index,protocol)
    copy=a.out/'COLLECTION_COMPLETE.json'
    if copy.exists() and read(copy)!=data.manifest:raise ValueError('Different dataset already attached to this output')
    if not copy.exists():write(copy,data.manifest)
    configs=data.source_protocol.get('plan',[])
    details=dict(source=str(data.root),episodes=len(data.records),tasks={t:dict(strength_ratios=sorted({c['strength_scale'] for c in configs if c['task_id']==t}),reference_families=sorted({c['trajectory'] for c in configs if c['task_id']==t}),initial_reference_degrees=sorted({c['profile']['start_deg'] for c in configs if c['task_id']==t})) for t in order},mass_kg=sorted({c['mass_kg'] for c in configs}),dt_s=sorted({c['dt_s'] for c in configs}),muscle_excitation=sorted({c['muscle_excitation'] for c in configs}),initial_offsets_deg=sorted({c.get('initial_offset_deg',0) for c in configs}),initial_velocity_deg_s=sorted({c.get('initial_velocity_deg_s',0) for c in configs}),integrator_accuracy=sorted({c['integrator_accuracy'] for c in configs}),source_protocol_sha256=data.manifest['protocol_sha256'])
    write(a.out/'DATASET_DETAILS.json',details)
    nv=len(data.records_for(target,'validation'));nt=len(data.records_for(target,'test'));nd=len(data.records_for(order[-1],'test'))
    a.lr=.001;a.batch_size=2048;a.epochs_initial=a.common_epochs;a.epochs_adapt=a.common_epochs;a.replay_weight=0.;a.anneal=True
    a.weighted_mode=False;a.repair_mode=False
    train,groups=data.load(target,'train');val=data.load(target,'validation')[0]
    a.current_weights=data.loss_weights[(target,'train')]
    base=fit(a.out/'models'/'initial_base'/('after_'+target),train,{target:val},None,[],a,0)
    a.weighted_mode=True;a.repair_mode=True;a.anneal=False;a.lr=.0001;a.epochs_adapt=a.recovery_epochs
    review_file=a.out/'INITIAL_REPAIR_CANDIDATES.json'
    reviews=read(review_file) if review_file.exists() else []
    def review(policy,epoch):
        label='initial_recovery_epoch_'+str(epoch)
        old=next((r for r in reviews if r['epoch']==epoch),None)
        if old:
            if old['policy_hashes']!={n:sha(policy.parent/n) for n in ['policy.pt','policy_inference.npz','policy_inference.json']}:raise ValueError('Initial recovery candidate changed')
            return old['all_passed']
        rows=evaluate_return(a,data,policy,target,'validation',label)
        reviews.append(dict(epoch=epoch,policy=policy.relative_to(a.out).as_posix(),policy_hashes={n:sha(policy.parent/n) for n in ['policy.pt','policy_inference.npz','policy_inference.json']},all_passed=all(r['high_accuracy'] for r in rows),rows=rows))
        write(review_file,reviews);checkpoint_backup(a,'initial recovery validation epoch '+str(epoch))
        return reviews[-1]['all_passed']
    a.repair_review=review
    initial=fit(a.out/'models'/'shared'/('after_'+target),train,{target:val},base,[],a,0)
    epoch=read(initial.parent/'COMPLETE.json')['actual_epochs']
    accepted=next(r for r in reviews if r['epoch']==epoch)
    # These exact candidate files were copied byte-for-byte into the shared folder.
    if accepted['policy_hashes']!={n:sha(initial.parent/n) for n in ['policy.pt','policy_inference.npz','policy_inference.json']}:raise ValueError('Shared controller differs from physically validated recovery candidate')
    initial_rows=[dict(r,label='initial_target') for r in accepted['rows']]
    write(a.out/'INITIAL_VALIDATION.json',initial_rows)
    if not all(r['high_accuracy'] for r in initial_rows):
        write(a.out/'STATE.json',dict(status='initial_quality_failed',message='Return task was not learned accurately enough BEFORE adaptation. No forgetting comparison is claimed; no new collection is automatic. Existing data remain reusable.'))
        from target_report import build_report
        build_report(a.out);return
    a.repair_mode=False;a.weighted_mode=True;a.lr=.001
    target_train,target_groups=data.load(target,'train');memory=make_memory(a.out/'memory_target.npz',target_train,target_groups,a.seed+77,limit=1024,weights=data.loss_weights[(target,'train')])
    target_val=data.load(target,'validation')[0];a.epochs_adapt=a.adapt_epochs;a.anneal=False
    baseline_current={};parent=initial
    for offset,task in enumerate(suffix,target_index+1):
        current=data.load(task,'train')[0];v=data.load(task,'validation')[0];a.current_weights=data.loss_weights[(task,'train')]
        parent=fit(a.out/'models'/'noCL'/('after_'+task),current,{target:target_val,task:v},parent,[],a,offset)
        meta=read(parent.parent/'policy_inference.json')['metadata'];baseline_current[task]=meta['validation'][task]['rmse_N']
    baseline=parent;baseline_rows=evaluate_return(a,data,baseline,target,'validation','noCL_final');write(a.out/'BASELINE_VALIDATION.json',baseline_rows)
    choices=[]
    for weight in [1.,4.,16.]:
        a.replay_weight=weight;parent=initial;adaptation={}
        for offset,task in enumerate(suffix,target_index+1):
            current=data.load(task,'train')[0];v=data.load(task,'validation')[0];a.current_weights=data.loss_weights[(task,'train')]
            parent=fit(a.out/'models'/('replay_'+str(int(weight)))/('after_'+task),current,{target:target_val,task:v},parent,[memory],a,offset)
            metric=read(parent.parent/'policy_inference.json')['metadata']['validation'][task]['rmse_N'];limit=1.5*max(baseline_current[task],1.)
            adaptation[task]=dict(force_rmse_N=metric,noCL_force_rmse_N=baseline_current[task],limit_N=limit,passed=metric<=limit)
        label='replay_'+str(int(weight));rs=evaluate_return(a,data,parent,target,'validation',label)
        eligible=all(v['passed'] for v in adaptation.values()) and all(r['completed'] for r in rs)
        choices.append(dict(weight=weight,label=label,checkpoint=parent.relative_to(a.out).as_posix(),adaptation=adaptation,eligible=eligible,target_high_accuracy=all(r['high_accuracy'] for r in rs),mean_target_rmse_deg=float(np.mean([r['rmse_deg'] for r in rs])) if all(r['completed'] for r in rs) else None,rows=rs))
        write(a.out/'CANDIDATES.json',choices)
    eligible=[c for c in choices if c['eligible']]
    selected=min(eligible,key=lambda c:(not c['target_high_accuracy'],c['mean_target_rmse_deg'],c['weight'])) if eligible else None
    selection=dict(selected=selected,candidates=choices,baseline_checkpoint=baseline.relative_to(a.out).as_posix(),initial_checkpoint=initial.relative_to(a.out).as_posix(),rule='First require new-task validation force adaptation within 1.5x noCL (floor 1 N); among eligible prefer meeting return-angle criteria, then lowest mean return validation angle RMSE, then lower replay weight. No test selection or guaranteed benefit. No fallback if all adaptation constraints fail.')
    write(a.out/'SELECTION.json',selection)
    if selected is None:
        write(a.out/'STATE.json',dict(status='no_eligible_CL_candidate',message='No replay candidate met adaptation constraints. All outcomes retained; tests remain unopened.'))
        from target_report import build_report
        build_report(a.out);return
    seal(a);data.test_unlocked=True
    test_file=a.out/'TEST_RESULTS.json';rows=[]
    for label,path in [('initial_target',initial),('noCL_final',baseline),('CL_final',a.out/selected['checkpoint'])]:
        rows+=evaluate_return(a,data,path,target,'test',label,sealed=True);write(test_file,dict(complete=False,rows=rows))
    # Learning later tasks remains real; final new-task accuracy is disclosed too.
    for label,path in [('noCL_new_task',baseline),('CL_new_task',a.out/selected['checkpoint'])]:
        rows+=evaluate_return(a,data,path,order[-1],'test',label,sealed=True);write(test_file,dict(complete=False,rows=rows))
    verify_seal(a);write(test_file,dict(complete=True,rows=rows,seal_sha256=sha(a.out/'FINAL_MODELS_FROZEN.json')))
    offline=[]
    from policy_numpy import NumpyPolicy
    for task in [target,order[-1]]:
        (x,y),_=data.load(task,'test')
        policies=[('noCL',baseline),('CL',a.out/selected['checkpoint'])]
        if task==target:policies=[('initial_target',initial)]+policies
        for label,path in policies:
            pred=np.clip(NumpyPolicy(path.parent/'policy_inference.npz').predict(x),0,650)
            offline.append(dict(task=task,branch=label,teacher_forced_force_rmse_N=float(np.sqrt(np.mean((pred-y[:,0]*650)**2))),samples=len(y)))
    write(a.out/'TEST_FORCE_METRICS.json',offline);write(a.out/'STATE.json',dict(status='complete',selected_replay_weight=selected['weight'],target_high_accuracy_validation=selected['target_high_accuracy']))
    from target_report import build_report
    build_report(a.out)

def environment_check(a):
    # A real native/model and Torch optimizer/export check, in an isolated subprocess.
    flags=['--device',a.device] if hasattr(a,'device') else ['--physics-only']
    run_logged([sys.executable,'-X','utf8',CORE/'environment_check.py',*flags,'--report',a.out/'ENVIRONMENT.json'],a.out/'environment_check.log',timeout=120)

def choose_collection(a,p):
    if a.collection is not None:return a.collection.expanduser().resolve()
    # Resumption keeps the original data dependency even if a newer collection exists.
    previous=None
    if a.resume_latest:
        marker=Path.home()/'Arm26_Fresh_Results'/'LAST_RUN.json'
        if marker.exists():previous=Path(read(marker)['folder'])/'PROTOCOL.json'
    elif a.out:previous=a.out.expanduser().resolve()/'PROTOCOL.json'
    if previous and previous.exists() and not a.latest_data:return Path(read(previous)['collection_path'])
    marker=Path.home()/'Arm26_Fresh_Data'/'LAST_RUN.json'
    if not marker.exists():p.error('No new dataset is recorded. Run the collector first, or supply --collection "completed data folder".')
    folder=Path(read(marker)['folder'])
    if not (folder/'COLLECTION_COMPLETE.json').exists():p.error('The last collection is incomplete. Let it finish/resume it; training has not started.')
    if read(folder/'PROTOCOL.json').get('kind') not in ['return_task_collection_v2_large_headless','return_task_collection_v3_exact_budget']:p.error('The latest folder belongs to an older small-data release. Run the updated collector, or explicitly pass --collection if that older data is intended.')
    return folder

def main(kind):
    p=argparse.ArgumentParser(description='Collect return-task data' if kind=='collect' else 'Sequential NN versus target-task replay CL')
    dest=p.add_mutually_exclusive_group();dest.add_argument('--out',type=Path);dest.add_argument('--output-root',type=Path);dest.add_argument('--resume-latest',action='store_true')
    p.add_argument('--reserve-gb',type=float,default=5.);p.add_argument('--episode-timeout',type=float,default=900.);p.add_argument('--no-github',action='store_true')
    p.add_argument('--github-every',type=int,default=10,help='Automatic verified backup after this many completed episodes.')
    p.add_argument('--github-epochs',type=int,default=50,help='Automatic verified backup every this many training epochs and every completed stage.')
    p.add_argument('--backup-only',action='store_true',help='Retry backup of --out/--resume-latest without any OpenSim/training work.')
    p.add_argument('--workers',type=int,default=max(1,min(4,os.cpu_count() or 1)),help='Parallel independent CPU OpenSim episodes, default up to 4; optional viewer forces serial tests.')
    viewer=p.add_mutually_exclusive_group();viewer.add_argument('--viewer',dest='no_viewer',action='store_false',help='Optional final test viewer. Default is headless.');viewer.add_argument('--no-viewer',dest='no_viewer',action='store_true');p.set_defaults(no_viewer=True)
    if kind=='collect':
        p.add_argument('--episodes',type=int,help='Exact total full episodes, default 250; approximately 70/10/20 group split.')
        p.add_argument('--initial-angles',nargs='+',type=float,default=[50.,60.,70.,80.]);p.add_argument('--train-reps',type=int);p.add_argument('--validation-reps',type=int);p.add_argument('--test-reps',type=int);p.add_argument('--data-seed',type=int,default=2026110810)
    if kind=='compare':
        datasets=p.add_mutually_exclusive_group();datasets.add_argument('--collection',type=Path,help='Explicit completed dataset folder.');datasets.add_argument('--latest-data',action='store_true',help='Use the updated collector last completed dataset. This is the fresh-run default.')
        p.add_argument('--order',nargs=4,choices=list(TASKS),default=['A','B','C','D']);p.add_argument('--return-task',choices=['A'],default='A')
        p.add_argument('--seed',type=int,default=42);p.add_argument('--device',choices=['cuda'],default='cuda',help='CUDA is required for training; never silently fall back to CPU.')
        p.add_argument('--common-epochs',type=int,default=600);p.add_argument('--recovery-epochs',type=int,default=200);p.add_argument('--adapt-epochs',type=int,default=120)
        p.add_argument('--target-rmse',type=float,default=.5);p.add_argument('--target-max',type=float,default=2.)
    a=p.parse_args()
    if not math.isfinite(a.reserve_gb) or a.reserve_gb<0 or not math.isfinite(a.episode_timeout) or a.episode_timeout<=0 or a.workers<1 or a.github_every<1 or a.github_epochs<1:p.error('Invalid disk reserve, worker count, backup interval or episode timeout')
    if a.backup_only and (a.no_github or not (a.out or a.resume_latest)):p.error('--backup-only needs --out or --resume-latest, and cannot use --no-github.')
    if kind=='collect':
        reps=[a.train_reps,a.validation_reps,a.test_reps]
        if any(v is not None for v in reps):
            if a.episodes is not None or any(v is None or v<1 for v in reps):p.error('Specify either --episodes, or ALL three positive per-condition replicate counts.')
        else:
            if a.episodes is None:a.episodes=250
            if a.episodes<40:p.error('Use at least 40 full episodes for a four-task grouped split.')
        if len(set(a.initial_angles))!=len(a.initial_angles) or not all(math.isfinite(v) and 30<=v<=85 for v in a.initial_angles):p.error('Use unique finite initial angles between 30 and 85 degrees')
    if kind=='compare':
        if a.order!=['A','B','C','D']:p.error('This release predeclares A -> B -> C -> D, then frozen return to A.')
        if a.common_epochs<1 or a.recovery_epochs<1 or a.adapt_epochs<1 or not all(math.isfinite(v) and v>0 for v in [a.target_rmse,a.target_max]):p.error('Invalid training budget or tracking criterion')
        if not a.backup_only:a.collection=choose_collection(a,p)
    os.environ['ARM26_MIN_FREE_GB']=str(a.reserve_gb);a.out,index=new_output(a,p,kind)
    console=sys.stdout;print('OUTPUT:',a.out,flush=True)
    if a.backup_only:
        from backup import backup_experiment
        result=backup_experiment(a.out,None,reason='backup-only retry',final=False)
        print('GITHUB VERIFIED:',result['commit_url'],flush=True);return
    from backup import cache_lock
    import tempfile
    run_lock=cache_lock(Path(tempfile.gettempdir())/'Arm26_Fresh_Run_Locks'/hashlib.sha256(str(a.out).encode()).hexdigest()[:16])
    try:run_lock.__enter__()
    except RuntimeError:
        print('ERROR: Another process is using this output folder.');return
    a.progress=Progress(0,console,a.out);a.backup_failed=False
    def verified_checkpoint(reason,final=False):
        if a.no_github:return
        try:
            from backup import backup_experiment
            with a.progress.waiting('GitHub backup | verifying remote commit'):
                return backup_experiment(a.out,ROOT,reason=reason,final=final)
        except Exception:
            a.backup_failed=True
            raise RuntimeError('GitHub backup was NOT verified. Work is saved locally. Inspect GITHUB_STATUS.json and retry --backup-only --resume-latest after fixing access/network.')
    a.checkpoint_backup=verified_checkpoint
    error=None
    try:
        with (a.out/'RUN.log').open('a',encoding='utf-8',buffering=1) as log,contextlib.redirect_stdout(log),contextlib.redirect_stderr(log):
            try:
                with a.progress.waiting('Checking OpenSim and CUDA' if kind=='compare' else 'Checking OpenSim'):
                    environment_check(a)
                if kind=='collect':
                    collect(a,index,console)
                    from collection_report import build_collection_report
                    with a.progress.waiting('Generating collection report'):build_collection_report(a.out)
                else:comparison(a,index,console)
                verified_checkpoint('final results and reports',final=True)
            except BaseException as exc:
                import traceback
                traceback.print_exc(file=log);error=exc
                write(a.out/'ERROR_STATUS.json',dict(status='error',message=str(exc)))
                from collection_report import build_error_report
                build_error_report(a.out,str(exc))
                if not a.no_github and not a.backup_failed:
                    try:verified_checkpoint('error or interruption',final=False)
                    except Exception:traceback.print_exc(file=log)
        if error is None:a.progress.stage('Run finished',1,1)
    finally:
        a.progress.close();run_lock.__exit__(None,None,None)
    if error is not None:
        print('ERROR:',error);print('Details:',a.out/'RUN.log');print('REPORT:',a.out/'ERROR_REPORT.html');raise SystemExit(1)
    print('SAVED:',a.out,flush=True)
    if (a.out/'REPORT.html').exists():print('REPORT:',a.out/'REPORT.html',flush=True)
    if not a.no_github:print('GITHUB VERIFIED:',read(a.out/'GITHUB_STATUS.json')['commit_url'],flush=True)
    else:print('GITHUB: explicitly disabled by --no-github',flush=True)
    state=a.out/'STATE.json'
    if state.exists() and read(state)['status']!='complete':print('STOPPED:',read(state)['message'],flush=True)
