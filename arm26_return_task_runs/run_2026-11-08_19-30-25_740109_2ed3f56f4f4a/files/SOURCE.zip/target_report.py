"""Reports target retention separately from later-task learning; all candidates retained."""
import csv,html,io,json,zipfile
from pathlib import Path
import numpy as np
from complex_engine import read,write
from atomic_io import atomic_bytes
from complex_trajectories import FEATURES,SCALES

def dataset_counts(manifest,order):
    return [dict(task=t,split=s,episodes=sum(r['task']==t and r['split']==s for r in manifest['episodes']),trajectory_rows=sum(r.get('samples',0) for r in manifest['episodes'] if r['task']==t and r['split']==s),query_rows=sum(r.get('probes',0) for r in manifest['episodes'] if r['task']==t and r['split']==s)) for t in order for s in ['train','validation','test']]

def feature_table():
    rows=[]
    for i,name in enumerate(FEATURES):
        unit='dimensionless'
        if name.endswith('_rad'):unit='rad'
        elif name.endswith('_rad_s2'):unit='rad/s2'
        elif name.endswith('_rad_s'):unit='rad/s' if 'integral' not in name else 'rad s'
        elif name.endswith('_kg'):unit='kg'
        elif name.endswith('_N'):unit='N'
        encoding=f'raw / {float(SCALES[i]):g}'
        if i==2:encoding='(reference angle - actual angle) / 0.02 rad'
        elif i==3:encoding='(reference speed - actual speed) / 0.2 rad/s'
        rows.append([i+1,name,unit,encoding])
    return rows

def training_rows(out,protocol):
    rows=[]
    for meta in sorted((out/'models').rglob('policy_inference.json')):
        if meta.parent.parent.name=='repair_candidates':continue
        m=read(meta);history=read(meta.parent/'HISTORY.json') if (meta.parent/'HISTORY.json').exists() else []
        if not history:continue
        task=meta.parent.name.removeprefix('after_');v=m['metadata'].get('validation',{}).get(task,{})
        rows.append(dict(branch=meta.parent.parent.name,task=task,epochs=len(history),train_rmse_N=history[-1].get('current_train_rmse_N'),validation_rmse_N=v.get('rmse_N'),updates=m['metadata'].get('optimizer_updates'),device=m['metadata'].get('device',protocol.get('training_device','recorded in environment log')),resident=m['metadata'].get('cuda_data_resident')))
    return rows

def curves(out,protocol,selection):
    target=protocol['return_task'];idx=protocol['order'].index(target);result={}
    branches=[('noCL','noCL')]
    if selection and selection.get('selected'):branches.append(('CL',selection['selected']['label']))
    for name,branch in branches:
        xs=[];train=[];val=[];offset=0
        for i,task in enumerate(protocol['order']):
            group='shared' if i<=idx else branch;file=out/'models'/group/('after_'+task)/'HISTORY.json'
            budget=protocol['common_epochs'] if i<=idx else protocol['adapt_epochs']
            hh=read(file) if file.exists() else []
            if group=='shared':
                base=out/'models'/'initial_base'/('after_'+task)/'HISTORY.json'
                prefix_history=read(base) if base.exists() else []
                hh=[dict(r,epoch=j+1) for j,r in enumerate(prefix_history+hh)]
            if hh:
                for r in hh:
                    xs.append(offset+r['epoch']);train.append(r.get('current_train_rmse_N',np.nan));val.append(r.get('validation',{}).get(target,{}).get('rmse_N',np.nan))
            offset+=len(hh) if hh else budget
        result[name]=(xs,train,val)
    return result

def table_html(headers,rows):
    return '<table><tr>'+''.join('<th>'+html.escape(str(h))+'</th>' for h in headers)+'</tr>'+''.join('<tr>'+''.join('<td>'+html.escape(str(x))+'</td>' for x in row)+'</tr>' for row in rows)+'</table>'

def interpretation(groups,target,state):
    g={r['label']:r for r in groups if r['task']==target};n=g.get('noCL_final');c=g.get('CL_final');initial=g.get('initial_target')
    if state.get('status')=='initial_quality_failed':return 'The shared controller did not learn the return task accurately enough before adaptation. This is an initial learning or state coverage problem; no forgetting or CL-success claim is made. Tests were not opened.'
    if state.get('status')=='no_eligible_CL_candidate':return 'No replay candidate satisfied every later-task adaptation constraint. Preserving an old task without adequate new-task adaptation is not counted as successful continual learning. Tests were not opened.'
    if not n or not c:return 'The comparison is incomplete. Missing results are not zero; inspect STATE.json and the detailed logs.'
    text=[]
    if initial:text.append(f'On the return task, initial test motion RMSE was {initial["rmse_deg"]:.3f} deg.' if initial['rmse_deg'] is not None else 'The initial-controller test had incomplete runs.')
    if n['failed'] or c['failed']:text.append('Some final runs failed; compare failure counts and partial traces. A mean over completed runs does not summarize failed episodes.')
    if n['rmse_deg'] is not None and c['rmse_deg'] is not None:
        text.append(f'Final ordinary-NN RMSE was {n["rmse_deg"]:.3f} deg and CL RMSE was {c["rmse_deg"]:.3f} deg, averaged across completed return references.')
        if n['failed']==c['failed']==0:text.append(f'The descriptive relative change was {100*(n["rmse_deg"]-c["rmse_deg"])/max(n["rmse_deg"],1e-12):.1f}% lower with CL (a negative value means CL was worse).')
    text.append(f'CL passed the predeclared return-angle criteria on {c["high_accuracy"]}/{c["attempts"]} references. Later-task test performance is reported separately. This single-seed experiment cannot establish statistical significance or that CL is necessary for every controller/scenario.')
    return ' '.join(text)

def grouped(rows):
    result=[]
    keys=list(dict.fromkeys((r['task'],r['label']) for r in rows))
    for task,label in keys:
        rs=[r for r in rows if r['task']==task and r['label']==label];ok=[r for r in rs if r['completed']]
        result.append(dict(task=task,label=label,attempts=len(rs),failed=len(rs)-len(ok),high_accuracy=sum(r['high_accuracy'] for r in rs),rmse_deg=float(np.mean([r['rmse_deg'] for r in ok])) if ok else None,motion_max_error_deg=max([r['motion_max_error_deg'] for r in rs if r['motion_max_error_deg'] is not None],default=None),all_max_error_deg=max([r['all_max_error_deg'] for r in rs if r['all_max_error_deg'] is not None],default=None),speed_rmse_deg_s=float(np.mean([r['speed_rmse_deg_s'] for r in ok if r['speed_rmse_deg_s'] is not None])) if any(r['speed_rmse_deg_s'] is not None for r in ok) else None,saturation_percent=float(np.mean([r['saturation_percent'] for r in ok if r['saturation_percent'] is not None])) if any(r['saturation_percent'] is not None for r in ok) else None))
    return result

def texescape(s):
    return str(s).replace('\\',r'\textbackslash{}').replace('_',r'\_').replace('%',r'\%').replace('&',r'\&').replace('#',r'\#')

def table_tex(headers,rows,columns=None):
    columns=columns or ('l'*len(headers))
    text=r'\small\begin{longtable}{'+columns+r'}\toprule '+' & '.join(texescape(x) for x in headers)+r'\\\midrule'+'\n'
    for row in rows:text+=' & '.join(texescape(x) for x in row)+r'\\'+'\n'
    return text+r'\bottomrule\end{longtable}\normalsize'+'\n'

def build_report(out):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    plt.rcParams.update({'font.family':'serif','font.size':16})
    out=Path(out);protocol=read(out/'PROTOCOL.json');target=protocol['return_task'];selection=read(out/'SELECTION.json') if (out/'SELECTION.json').exists() else None
    test=read(out/'TEST_RESULTS.json') if (out/'TEST_RESULTS.json').exists() else None
    phase='HELD-OUT TEST' if test and test['complete'] else 'VALIDATION ONLY'
    if phase=='HELD-OUT TEST':rows=test['rows']
    else:
        rows=read(out/'INITIAL_VALIDATION.json') if (out/'INITIAL_VALIDATION.json').exists() else []
        if (out/'BASELINE_VALIDATION.json').exists():rows+=read(out/'BASELINE_VALIDATION.json')
        if selection and selection['selected']:
            for r in selection['selected']['rows']:
                r=dict(r);r['label']='CL_final';rows.append(r)
    groups=grouped(rows);state=read(out/'STATE.json') if (out/'STATE.json').exists() else {}
    summary=dict(phase=phase,order=protocol['order'],return_task=target,seed=protocol['seed'],groups=groups,state=state,selection_rule=selection['rule'] if selection else None)
    final={r['label']:r for r in groups if r['task']==target}
    if final.get('noCL_final') and final.get('CL_final'):
        n=final['noCL_final'];c=final['CL_final']
        if n['failed']==c['failed']==0 and n['rmse_deg'] is not None and c['rmse_deg'] is not None:
            summary['relative_return_improvement']=float((n['rmse_deg']-c['rmse_deg'])/max(n['rmse_deg'],1e-12))
    write(out/'SUMMARY.json',summary)
    if groups:
        b=io.StringIO(newline='');w=csv.DictWriter(b,fieldnames=list(groups[0]));w.writeheader();w.writerows(groups);atomic_bytes(out/'TRACKING_SUMMARY.csv',b.getvalue().encode('utf-8'))
    episode_fields=['task','split','label','episode_id','completed','rmse_deg','partial_rmse_deg','motion_max_error_deg','all_max_error_deg','speed_rmse_deg_s','saturation_percent','high_accuracy','error','folder']
    with (out/'EPISODE_METRICS.csv').open('w',encoding='utf-8',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=episode_fields,extrasaction='ignore');writer.writeheader();writer.writerows(rows)
    figures=[]
    fig,(ax,learning_ax)=plt.subplots(1,2,figsize=(12,5));labels=['initial_target','noCL_final','CL_final'];names=['After learning\ntarget','Return\nno CL','Return\ntargeted CL'];colors=['#777777','#D55E00','#0072B2']
    for i,(label,name,color) in enumerate(zip(labels,names,colors)):
        r=final.get(label)
        if not r:continue
        if r['rmse_deg'] is not None:ax.bar(i,r['rmse_deg'],width=.6,color=color)
        if r['failed']:ax.annotate(f'{r["failed"]}/{r["attempts"]} failed',(i,r['rmse_deg'] or 0),xytext=(0,5),textcoords='offset points',ha='center',fontsize=9)
    ax.axhline(protocol['target_rmse_deg'],color='black',ls=':',label='Predeclared accuracy target')
    ax.set(xticks=range(3),xticklabels=names,ylabel='Motion angle RMSE (deg)',title='Return to '+target)
    for (name,(xs,tr,va)),color in zip(curves(out,protocol,selection).items(),['#D55E00','#0072B2']):
        if xs:
            learning_ax.plot(xs,va,color=color,label=name+': target validation')
            learning_ax.plot(xs,tr,color=color,ls=':',alpha=.65,label=name+': current-task training')
    learning_ax.set(xlabel='Cumulative training epochs',ylabel='Force RMSE (N)',title='Learning history: force');learning_ax.grid(alpha=.2)
    if learning_ax.lines:learning_ax.legend(fontsize=12)
    ax.grid(axis='y',alpha=.2);ax.legend(fontsize=12);fig.suptitle(phase,fontsize=16);fig.tight_layout()
    for ext in ['png','pdf']:fig.savefig(out/('retention.'+ext),dpi=160)
    plt.close(fig);figures.append('retention')
    eids=sorted({r['episode_id'] for r in rows if r['task']==target})
    if eids:
        eid=eids[0];fig,grid=plt.subplots(2,2,figsize=(11,7),sharex=True);axs=[grid[0,0],grid[1,0],grid[0,1],grid[1,1]];ref_done=False
        for label,name,color in zip(labels,['Initial','Final, no CL','Final, targeted CL'],colors):
            row=next((r for r in rows if r['task']==target and r['episode_id']==eid and r['label']==label),None)
            if not row:continue
            path=out/row['folder']/'signals.csv'
            if not path.exists():continue
            with path.open(encoding='utf-8',newline='') as f:rs=list(csv.DictReader(f))
            if not rs:continue
            t=np.array([float(r['time_s']) for r in rs]);q=np.array([float(r['angle_deg']) for r in rs]);ref=np.array([float(r['reference_deg']) for r in rs])
            vr=np.degrees(np.array([float(r['reference_velocity_rad_s']) for r in rs]));v=np.degrees(np.array([float(r['velocity_rad_s']) for r in rs]))
            if not ref_done:axs[0].plot(t,ref,'k--',label='Reference');axs[2].plot(t,vr,'k--',label='Reference speed');ref_done=True
            caption=name+(' [partial failure]' if not row['completed'] else '')
            axs[0].plot(t,q,color=color,label=caption);axs[1].plot(t,ref-q,color=color,label=caption);axs[2].plot(t,v,color=color,label=caption);axs[3].plot(t,vr-v,color=color,label=caption)
        for ax in axs:ax.grid(alpha=.2);ax.legend(fontsize=12)
        axs[0].set_ylabel('Angle (deg)');axs[1].set(ylabel='Angle error (deg)',xlabel='Time (s)');axs[2].set_ylabel('Angular velocity (deg/s)');axs[3].set(ylabel='Velocity error (deg/s)',xlabel='Time (s)');fig.suptitle(phase+' — first preselected target reference');fig.tight_layout()
        for ext in ['png','pdf']:fig.savefig(out/('tracking.'+ext),dpi=160)
        plt.close(fig);figures.append('tracking')
    target_ids=list(dict.fromkeys(r['episode_id'] for r in rows if r['task']==target))
    gallery=[]
    for page,start in enumerate(range(0,len(target_ids),4),1):
        ids=target_ids[start:start+4];fig,axs=plt.subplots(2,2,figsize=(12,9),squeeze=False)
        for ax,episode_id in zip(axs.ravel(),ids):
            reference_drawn=False
            for label,caption,color in [('initial_target','Shared A before B/C/D','#777777'),('noCL_final','Ordinary NN after B/C/D','#D55E00'),('CL_final','Replay CL after B/C/D','#0072B2')]:
                row=next((r for r in rows if r['task']==target and r['episode_id']==episode_id and r['label']==label),None)
                if row is None:continue
                path=out/Path(row['folder'].replace('\\','/'))/'signals.csv'
                if not path.exists():continue
                with path.open(encoding='utf-8') as stream:signals=list(csv.DictReader(stream))
                tt=[float(z['time_s']) for z in signals]
                if not reference_drawn:ax.plot(tt,[float(z['reference_deg']) for z in signals],'k--',label='Reference');reference_drawn=True
                ax.plot(tt,[float(z['angle_deg']) for z in signals],color=color,label=caption+(' [partial failure]' if not row['completed'] else ''))
            ax.set(title=episode_id,xlabel='Time (s)',ylabel='Elbow (deg)');ax.grid(alpha=.2);ax.legend(fontsize=8)
        for ax in list(axs.ravel())[len(ids):]:ax.axis('off')
        fig.suptitle(phase+' - every predeclared return reference, page '+str(page));fig.tight_layout()
        name='all_return_references_'+str(page)
        for ext in ['png','pdf']:fig.savefig(out/(name+'.'+ext),dpi=150)
        plt.close(fig);figures.append(name);gallery.append(name)
    m=read(out/'COLLECTION_COMPLETE.json');counts={task:{s:sum(r['task']==task and r['split']==s for r in m['episodes']) for s in ['train','validation','test']} for task in protocol['order']}
    note=(f"Order: {' -> '.join(protocol['order'])}; return to {target} with frozen final weights. "
          f"Direct MLP 28 ->64 tanh ->64 tanh ->1 force output, 6081 parameters, clipped to 0-650 N. "
          f"Shared initial learning: {protocol['common_epochs']} ordinary-MSE epochs, then up to {protocol.get('recovery_epochs',200)} recovery-weighted epochs with response regularization. Validation selects the first passing repair milestone. Both branches clone EXACTLY the same accepted model. "
          f"Later tasks: {protocol['adapt_epochs']} epochs/task with Adam 0.001 and batch 2048, identical current-task data/order and update count. "
          "NoCL uses weighted current normalized-force MSE plus 0.1 corrective-response penalty. Targeted CL adds beta times the same objective on at most 1024 TARGET training examples, including startup-priority and stratified trajectory/probe samples; up to 512 replay examples/update. "
          "Replay uses extra old-data access and computation. Full deployment checkpoints are saved, but CL memory does not store an old parameter vector. "
          "Replay weights 1,4,16 are selected on validation target tracking with new-task force-adaptation constraints. No test-based tuning; all candidates retained. "
          f"Target accuracy: motion RMSE <= {protocol['target_rmse_deg']:g} deg and motion maximum <= {protocol['target_motion_max_deg']:g} deg. Initial recovery hold is excluded from those motion criteria; full maximum is separately shown. "
          "Angular velocity error is in deg/s, saturation in percent. Force imitation is reported separately from tracking. "
          "Inputs: elbow angle/velocity, position/velocity errors, reference acceleration, mass, shoulder angle/velocity/acceleration, previous tension, integrated error, six muscle activations, six normalized fiber lengths, strength ratio, yaw angle/velocity/acceleration and known external force. One learned cable; shoulder/yaw prescribed. "
          "Only the preselected return task is the primary retention endpoint. Final new-task test performance is also disclosed. One seed is exploratory; no statistical-significance or universal-necessity claim. "
          "Failed runs receive no finite final RMSE. Means use completed runs, with failures/attempts reported. Perfect tracking and CL superiority are not guaranteed.")
    note+=' Whole-episode train/validation/test counts: '+', '.join(t+':'+('/'.join(str(counts[t][s]) for s in ['train','validation','test'])) for t in protocol['order'])+'. '
    if selection and selection['selected']:note+='Selected replay beta: '+str(selection['selected']['weight'])+'. '
    def fmt(x):return '--' if x is None else f'{x:.3f}'
    headers=['Task','Checkpoint','RMSE deg','Motion max deg','Full max deg','Speed RMSE deg/s','Failed/attempted','High accuracy']
    tr=''.join('<tr>'+''.join('<td>'+html.escape(str(v))+'</td>' for v in [r['task'],r['label'],fmt(r['rmse_deg']),fmt(r['motion_max_error_deg']),fmt(r['all_max_error_deg']),fmt(r['speed_rmse_deg_s']),f'{r["failed"]}/{r["attempts"]}',f'{r["high_accuracy"]}/{r["attempts"]}'])+'</tr>' for r in groups)
    stats=dataset_counts(m,protocol['order']);features=feature_table();training=training_rows(out,protocol)
    physics=read(out/'DATASET_DETAILS.json') if (out/'DATASET_DETAILS.json').exists() else {}
    env=read(out/'ENVIRONMENT.json') if (out/'ENVIRONMENT.json').exists() else {}
    conclusion=interpretation(groups,target,state)
    physics_rows=[['Mass (kg)',physics.get('mass_kg','see episode settings')],['Control sample interval (s)',physics.get('dt_s','see episode settings')],['Muscle excitation',physics.get('muscle_excitation','see episode settings')],['Initial angle offsets (deg)',physics.get('initial_offsets_deg','see episode settings')],['Initial speeds (deg/s)',physics.get('initial_velocity_deg_s','see episode settings')],['Integrator accuracy',physics.get('integrator_accuracy','see episode settings')],['NN training device',env.get('device',protocol.get('training_device','see environment log'))],['GPU',env.get('gpu_name','see ENVIRONMENT.json')],['Physics device','CPU OpenSim; no CUDA forward dynamics'],['Viewer','Headless by default; optional final test viewer']]
    task_rows=[[t,{'A_90':'Vertical reaches','B_60':'Variable speeds and reversals','C_30':'Cross-body sweep via prescribed yaw','D_45':'Reach/hold with load pulses'}.get(t,t),physics.get('tasks',{}).get(t,{}).get('strength_ratios',{'A_90':[.9],'B_60':[.6],'C_30':[.3],'D_45':[.45]}.get(t,[])),physics.get('tasks',{}).get(t,{}).get('initial_reference_degrees','see settings')] for t in protocol['order']]
    stat_rows=[[r['task'],r['split'],r['episodes'],r['trajectory_rows'],r['query_rows']] for r in stats]
    train_rows=[[r['branch'],r['task'],r['epochs'],fmt(r['train_rmse_N']),fmt(r['validation_rmse_N']),r['updates'] if r['updates'] is not None else '--',r['device']] for r in training]
    network_rows=[['Input','28 encoded simulator features',0],['Hidden 1','64 tanh',1856],['Hidden 2','64 tanh',4160],['Output','1 linear normalized force',65],['Total','One cable tension, clipped to 0-650 N',6081]]
    sections=[
      ('Question and experimental sequence',f"Does sequential fine-tuning forget the preselected task {target}, and does target-only replay preserve it? Train {' -> '.join(protocol['order'])}; freeze the final weights; revisit {target} without learning. Ordinary NN runs first. Each CL candidate restarts from the exact same shared target-at-learning checkpoint. The last new task is tested separately, so preserved old-task behavior is not confused with successful new-task learning."),
      ('Data generation and split',"The affine-dynamics plus PID teacher supplies desired cable tension. Muscle strength is changed through maximum isometric force, not by changing excitation. Entire reference episodes are assigned to train/validation/test before NN fitting; all rows and instantaneous recovery queries stay with their parent split. Four copied-state teacher queries every 0.2 s cover +/-2 deg position, +/-12 deg/s speed and +/-0.02 rad s integral offsets. Queries are not additional integrated trials. No pilots or test values are fitted. Startup state combinations may recur across splits; whole reference episodes remain separate. Row counts are correlated samples, not independent episodes. More rows alone do not prove adequate state coverage."),
      ('NN controller and input/output meaning',"The feedforward MLP has 6081 parameters and one cable-force output. It is a learned feedback controller because measured state/error, bounded integral and previous tension are inputs; there is no recurrent hidden state and no separate PID, nominal or gain head. Shoulder elevation/yaw are prescribed. Simulation muscle states and known task parameters are available inputs; physical sensor deployment is not established by this study."),
      ('Training and CUDA execution',f"Initial fit: {protocol['common_epochs']} ordinary-MSE epochs, Adam lr0.001 with cosine decay to 5%, batch2048. Then up to {protocol.get('recovery_epochs',200)} recovery epochs, Adam lr0.0001, weighted force loss and corrective-response regularization. Milestones 50/100/200 are capped to the requested budget. The first checkpoint meeting every initial validation reference is shared by both branches. Later stages: {protocol['adapt_epochs']} epochs/task, Adam0.001, optimizer reset, final fixed-budget checkpoint. Both branches see identical current-task rows/permutations and update counts. Training uses CUDA, with no CPU fallback in this release; data remain GPU-resident when memory permits. OpenSim physics and report/data preparation remain CPU operations. Collection runs independent headless CPU episodes in parallel."),
      ('Continual-learning memory and objective',"During sequential learning, both branches minimize weighted MSE between raw force/650 and teacher force/650 plus 0.1 times a local corrective-response penalty. Trajectory weights:25 for first0.25 s,8 for remaining first1 s,1 otherwise; teacher-query weight6. The response penalty discourages force decreasing when actual angle or velocity decreases at fixed reference, using encoded finite differences of0.05 and minimum slope0.02 on up to128 training examples. This encourages corrective response but does not guarantee closed-loop stability. CL adds beta times the same objective on at most1024 target-training examples. Memory prioritizes startup samples then stratifies the remainder by episode/query type. Up to512 old examples are replayed per update. Float32 features/target/weights occupy at most120 KiB, plus indices/IDs. No previous full parameter vector is used by the CL mechanism; full deployment checkpoints are still saved. This is replay, not EWC. Replay adds data access/computation, so budgets are matched in current-task rows/updates, not total examples or wall time."),
      ('Validation-only selection and sealed tests',"Candidate replay weights are1,4,16. At every later stage, CL current-task validation force RMSE must be at most1.5 times the ordinary-NN reference, with a1 N floor. Among eligible candidates, prefer those meeting target angle criteria, then lower target validation tracking RMSE, then smaller beta. All candidates are reported. No hidden fallback is selected if all adaptation constraints fail. Models, memory and selection are sealed before held-out values are decoded; no test tuning, updates or return-task relearning occurs."),
      ('Metric definitions and acceptance criteria',f"Primary target accuracy: motion angle RMSE at most {protocol['target_rmse_deg']:g} deg AND motion maximum absolute error at most {protocol['target_motion_max_deg']:g} deg, on every selected reference. Initial recovery hold is excluded from motion criteria, but full-episode maximum is also shown. Velocity RMSE is in deg/s. Saturation is the percentage of motion samples whose requested force is clipped. Angle group means give equal weight to each completed reference. Teacher-forced force RMSE is pooled over saved teacher states/queries and is not a closed-loop angle metric. Failed runs retain failure counts/partial traces and receive no invented finite final RMSE."),
      ('How to interpret the outcome',conclusion),
      ('Limits and reproducibility',"Results from one seed do not establish statistical significance. Validation guided method selection; only the sealed held-out tests support the final reported comparison. The first reference overlay was chosen by episode ID, not by error. Initial poor tracking, forgetting, new-task adaptation and numerical/storage failures are different issues. All data hashes, source, checkpoints, candidate scores, histories and logs are retained. Perfect tracking, a large baseline failure and CL superiority are not guaranteed.")]
    content='<html><meta charset="utf-8"><style>body{font:17px Georgia;max-width:1150px;margin:30px auto;line-height:1.55}td,th{padding:7px;border-bottom:1px solid #ddd;text-align:left}img{max-width:100%}pre{white-space:pre-wrap}h2{margin-top:1.8em}table{font-size:14px;border-collapse:collapse}code{overflow-wrap:anywhere}</style><h1>Return-task retention: experiment and results</h1><p><b>'+phase+'</b> | seed '+str(protocol['seed'])+' | state '+html.escape(state.get('status','pending'))+'</p><h2>Measured outcome</h2><p>'+html.escape(conclusion)+'</p><table><tr>'+''.join('<th>'+h+'</th>' for h in headers)+'</tr>'+tr+'</table>'
    for title,paragraph in sections:content+='<h2>'+title+'</h2><p>'+html.escape(paragraph)+'</p>'
    content+='<h2>Tasks and physical conditions</h2>'+table_html(['Task','Reference','Strength ratio','Initial reference angles (deg)'],task_rows)+table_html(['Setting','Value'],physics_rows)
    content+='<h2>Actual dataset size and split</h2>'+table_html(['Task','Split','Episodes','Trajectory rows','Query rows'],stat_rows)
    content+='<h2>NN topology</h2>'+table_html(['Layer','Size/output','Parameters'],network_rows)+'<h2>All 28 inputs and normalization</h2>'+table_html(['Index','Raw feature','Raw unit','Encoded value'],features)
    content+='<h2>Training history at saved checkpoints</h2><p>Training RMSE is the online, last-epoch minibatch aggregate before/after intervening updates. Validation is evaluated at the saved final checkpoint. Force units are N; they do not represent angle error.</p>'+table_html(['Branch','After task','Epochs','Train RMSE N','Current val RMSE N','Updates','Device'],train_rows)
    content+='<h2>Figures and all-reference gallery</h2><p>Solid learning curves show return-task validation force RMSE; dotted curves show current-task training force RMSE. The current task changes between stages, so the dotted/solid gap is not a same-task generalization gap.</p>'+''.join(f'<img src="{n}.png">' for n in figures)
    if selection:
        content+='<h2>All replay candidates (validation)</h2><table><tr><th>Weight</th><th>Eligible adaptation</th><th>Target RMSE deg</th><th>Target accuracy passed</th></tr>'
        for c in selection['candidates']:content+='<tr>'+''.join('<td>'+html.escape(str(x))+'</td>' for x in [c['weight'],c['eligible'],fmt(c['mean_target_rmse_deg']),c['target_high_accuracy']])+'</tr>'
        content+='</table><details><summary>Adaptation constraints and selection</summary><pre>'+html.escape(json.dumps(selection,indent=2))+'</pre></details>'
    force=read(out/'TEST_FORCE_METRICS.json') if (out/'TEST_FORCE_METRICS.json').exists() else []
    force_rows=[[r['task'],r['branch'],fmt(r['teacher_forced_force_rmse_N']),r['samples']] for r in force]
    if force:content+='<h2>Separate teacher-forced force tests</h2>'+table_html(['Task','Checkpoint','Force RMSE N','Samples'],force_rows)
    content+='</html>';atomic_bytes(out/'REPORT.html',content.encode('utf-8'))
    tex=r'\documentclass[10pt]{article}\usepackage[T1]{fontenc}\usepackage{mathptmx}\usepackage[margin=.7in]{geometry}\usepackage{graphicx,booktabs,longtable,array}\setlength{\parindent}{0pt}\setlength{\parskip}{5pt}\begin{document}\section*{Return-task retention: experiment and results}'+'\n'+texescape(phase)+'. Seed '+str(protocol['seed'])+'. State: '+texescape(state.get('status','pending'))+'.\n'
    tex+=r'\subsection*{Measured outcome}'+texescape(conclusion)+'\n'
    result_rows=[[r['task'],r['label'],fmt(r['rmse_deg']),fmt(r['motion_max_error_deg']),fmt(r['all_max_error_deg']),fmt(r['speed_rmse_deg_s']),f'{r["failed"]}/{r["attempts"]}',f'{r["high_accuracy"]}/{r["attempts"]}'] for r in groups]
    tex+=table_tex(['Task','Checkpoint','RMSE','Motion max','Full max','Speed','Failed','Pass'],result_rows,'llrrrrrr')
    for title,paragraph in sections:
        if title=='How to interpret the outcome':continue
        tex+=r'\subsection*{'+texescape(title)+'}\n'+texescape(paragraph.replace('->','to'))+'\n'
    tex+=r'\[ \ell_w(D)=\frac{\sum_{i\in D}w_i(f_\theta(x_i)-F_i/650)^2}{\sum_{i\in D}w_i},\qquad L_{\mathrm{NN}}=\ell_w(D)+0.1R(D).\]\[ L_{\mathrm{CL}}=L_{\mathrm{NN}}+\beta[\ell_w(\mathcal{M}_{\mathrm{target}})+0.1R(\mathcal{M}_{\mathrm{target}})].\]'+'\n'
    tex+=r'\newpage\section*{Tasks, data and network}'+'\n'+table_tex(['Task','Reference','Strength','Initial angles'],task_rows,r'lp{.40\linewidth}lp{.24\linewidth}')+table_tex(['Setting','Value'],physics_rows,r'p{.36\linewidth}p{.52\linewidth}')
    tex+=r'\subsection*{Actual whole-episode split and row counts}'+table_tex(['Task','Split','Episodes','Trajectory rows','Queries'],stat_rows,'llrrr')
    tex+=r'\subsection*{Network topology}'+table_tex(['Layer','Size/output','Parameters'],network_rows,r'lp{.56\linewidth}r')
    tex+=r'\newpage\section*{Inputs, training and selection}'+'\n'+table_tex(['Index','Raw feature','Unit','Encoding'],features,r'rp{.36\linewidth}lp{.35\linewidth}')
    tex+=r'\subsection*{Saved-checkpoint force metrics}'+table_tex(['Branch','Task','Epochs','Train N','Val N','Updates'],[r[:6] for r in train_rows],'llrrrr')
    tex+='Train N is the online last-epoch aggregate; Val N is the saved-checkpoint current-task validation metric. Both are force metrics, not angle error.\n'
    if selection:
        tex+=r'\subsection*{All replay candidates: validation only}'+table_tex(['Beta','Eligible','Return RMSE deg','Accuracy'],[[c['weight'],c['eligible'],fmt(c['mean_target_rmse_deg']),c['target_high_accuracy']] for c in selection['candidates']],'llrl')
        if selection['selected']:tex+='Selected beta: '+str(selection['selected']['weight'])+'.\n'
    if force:tex+=r'\subsection*{Separate teacher-forced force tests}'+table_tex(['Task','Checkpoint','RMSE N','Rows'],force_rows,'llrr')
    for n in figures:
        tex+=r'\newpage\section*{'+('Retention and learning history' if n=='retention' else 'Preselected reference: angle and angular velocity' if n=='tracking' else 'All predeclared return references: '+n.replace('_',' '))+'}\n'+r'\includegraphics[width=\linewidth,height=7.5in,keepaspectratio]{'+n+'.pdf}\n'
        if n=='retention':tex+='Solid: target validation force RMSE; dotted: current-task training force RMSE. Tasks change between stages; these are not same-task train/validation gaps.\n'
        else:tex+='The first target test reference by episode ID is shown. It was not chosen for favorable error. Partial runs remain labeled; aggregate tables include all attempts.\n'
    tex+=r'\newpage\section*{Every attempted episode}'+table_tex(['Task','Model','Reference','Complete','RMSE','Partial','Peak'],[[r['task'],r['label'],r['episode_id'].replace('_validation','_val'),r['completed'],fmt(r.get('rmse_deg')),fmt(r.get('partial_rmse_deg')),fmt(r.get('motion_max_error_deg'))] for r in rows],r'lp{.14\linewidth}p{.27\linewidth}lrrr')
    tex+=r'\end{document}'
    report_path=out/'REPORT.html'
    individual=table_html(['Task','Model','Reference','Completed','Motion RMSE deg','Partial RMSE deg','Motion peak deg','Passed'],[[r['task'],r['label'],r['episode_id'],r['completed'],r.get('rmse_deg'),r.get('partial_rmse_deg'),r.get('motion_max_error_deg'),r['high_accuracy']] for r in rows])
    report_path.write_text(report_path.read_text(encoding='utf-8').replace('</html>','<h2>Every attempted episode</h2>'+individual+'</html>'),encoding='utf-8')
    with zipfile.ZipFile(out/'OVERLEAF_REPORT.zip','w',zipfile.ZIP_DEFLATED) as z:
        z.writestr('main.tex',tex)
        for n in figures:z.write(out/(n+'.pdf'),n+'.pdf')
    with zipfile.ZipFile(out/'CONTEXT.zip','w',zipfile.ZIP_DEFLATED) as z:
        for p in sorted(out.rglob('*')):
            rel=p.relative_to(out)
            if not p.is_file() or p.name in ['CONTEXT.zip','RESUME.pt','training_arrays.npz','probe_arrays.npz'] or 'interrupted' in rel.parts:continue
            if p.suffix in ['.json','.pt','.npz','.csv','.png','.pdf','.html','.zip','.log','.txt']:z.write(p,rel)
