Named checkpoints are frozen copies from this run. All other training checkpoints remain under models/.
PyTorch policy.pt contains architecture and state_dict; learning.py in SOURCE.zip defines DirectMLP.
NumPy deployment: add the inference/ folder to sys.path, import NumpyPolicy from policy_numpy, load a named policy_inference.npz, then pass a raw 28-feature vector in the order listed in policy_inference.json.
NumpyPolicy performs the recorded feature encoding and returns requested force in N. Apply the same 0..650 N clipping and simulator state/control timing used by core/complex_engine.py.
These simulation inputs include muscle states and known task parameters; physical sensor deployment is not established.
