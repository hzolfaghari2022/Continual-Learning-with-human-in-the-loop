"""Open this file in VS Code and select Run Python File in Terminal.
Uses existing data, bundled saved checkpoint, and the lstm-py312 interpreter.
"""
from pathlib import Path
import argparse
import hashlib
import json
import os
import shutil
import subprocess
import sys
from datetime import datetime

ROOT=Path(__file__).resolve().parent
DATA_REL='Arm26_600_20261112_145744/runs/run_2026-11-12_14-57-44_590837'

def checked_package(root):
    required=['train_nn.py','flow.py','corrective.py','learning.py','backup.py','core/complex_engine.py','core/arm26_exosuit.osim','starting_checkpoint/policy.pt','starting_checkpoint/policy_inference.npz','starting_checkpoint/policy_inference.json']
    for name in required:
        if not (root/name).is_file():raise RuntimeError('Package file missing: '+str(root/name)+'. Extract the complete ZIP first.')
    if "'--warm-start'" not in (root/'flow.py').read_text(encoding='utf-8'):raise RuntimeError('Wrong training version: warm-start support missing')
    for name,expected in json.loads((root/'CHECKPOINT_HASHES.json').read_text()).items():
        if hashlib.sha256((root/'starting_checkpoint'/name).read_bytes()).hexdigest()!=expected:raise RuntimeError('Bundled checkpoint changed: '+name)

def short_package(root,home):
    if len(str(root))<=75:return root
    target=home/('A26R_'+datetime.now().strftime('%m%d_%H%M%S_%f'))
    print('Preparing a short package path:',target,flush=True)
    shutil.copytree(root,target,ignore=shutil.ignore_patterns('runs','github_cache','__pycache__','.git'))
    checked_package(target)
    return target

def command(root,python_exe,collection,extra):
    return [str(python_exe),'-u','-X','utf8',str(root/'train_nn.py'),'--collection',str(collection),'--warm-start',str(root/'starting_checkpoint'/'policy.pt'),'--device','cuda','--workers','4',*extra]

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--collection',type=Path,default=Path.home()/DATA_REL)
    args,extra=p.parse_known_args()
    checked_package(ROOT)
    home=Path.home();collection=args.collection.expanduser().resolve()
    if not (collection/'COLLECTION_COMPLETE.json').is_file():
        print('Select your EXISTING completed 600-episode data folder',flush=True)
        import tkinter as tk
        from tkinter import filedialog
        ui=tk.Tk();ui.withdraw()
        selected=filedialog.askdirectory(title='Select completed data run containing COLLECTION_COMPLETE.json')
        ui.destroy()
        if not selected:raise RuntimeError('No dataset selected; training was not started')
        collection=Path(selected)
        if not (collection/'COLLECTION_COMPLETE.json').is_file():raise RuntimeError('Selected folder has no COLLECTION_COMPLETE.json')
    python_exe=home/'miniconda3'/'envs'/'lstm-py312'/'python.exe'
    if not python_exe.is_file():raise RuntimeError('Required Python environment missing: '+str(python_exe))
    root=short_package(ROOT,home)
    print('Recovery code:',root,flush=True)
    print('Existing dataset:',collection,flush=True)
    print('Using bundled saved initial NN; no full data recollection',flush=True)
    print('New results will be saved under:',root/'runs',flush=True)
    return subprocess.call(command(root,python_exe,collection,extra),cwd=root)

if __name__=='__main__':
    try:raise SystemExit(main())
    except Exception as error:
        print('STARTUP ERROR:',error,flush=True)
        raise SystemExit(1)
