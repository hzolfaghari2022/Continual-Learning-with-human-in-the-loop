@echo off
"%USERPROFILE%\miniconda3\envs\lstm-py312\python.exe" -u -X utf8 "%~dp0run_recovery.py"
pause
