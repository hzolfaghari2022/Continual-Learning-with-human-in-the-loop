import sys,tempfile,json,hashlib,types,importlib.util
from pathlib import Path
import numpy as np
root=Path(__file__).resolve().parent;sys.path[:0]=[str(root),str(root/'core')]
from complex_engine import read,write,sha
from complex_trajectories import FEATURES
import corrective
with tempfile.TemporaryDirectory() as td:
    td=Path(td);data=types.SimpleNamespace(root=td/'data',loss_weights={('A_90','train'):np.ones(2)})
    records=[]
    for variant in ['A','B']:
      for q in [50,60,70,80]:
       for i in range(4):
        d=data.root/f'{variant}{q}_{i}';d.mkdir(parents=True);write(d/'settings.json',dict(variant=variant,profile=dict(start_deg=q),split='train',episode_id=d.name))
        records.append(dict(folder=d.name,split='train',episode_id=d.name))
    data.records_for=lambda task,split:records if split=='train' else (_ for _ in ()).throw(AssertionError('Only train selection allowed'))
    for round_index in range(3):
      selected=corrective.select_records(data,'A_90',round_index)
      assert len(selected)==16 and len({r['episode_id'] for r in selected})==16
    a=types.SimpleNamespace(out=td/'out',workers=2,corrective_rounds=2,corrective_epochs=1)
    a.out.mkdir();a.progress=types.SimpleNamespace(stage=lambda *x:None,advance=lambda:None)
    initial=td/'initial'/'policy.pt';initial.parent.mkdir()
    for n in ['policy.pt','policy_inference.npz','policy_inference.json']:(initial.parent/n).write_bytes(b'checkpoint')
    calls=[]
    def episode(folder,cfg,a):
      assert cfg['split']=='train' and cfg['collect_corrective_labels'] and cfg['neural_checkpoint']
      folder.mkdir(parents=True,exist_ok=True)
      np.savez(folder/'corrective_arrays.npz',X_raw=np.zeros((3,28),np.float32),y_force_N=np.full((3,1),130,np.float32),source_split=np.array('train'),feature_names=np.array(FEATURES))
      return dict(status='failed') # useful expert targets retained even from failed NN rollout
    def fit(folder,train,validation,parent,memory,a,stage):
      assert train[0].shape==(50,28) and np.allclose(train[1][2:],.2)
      assert len(a.current_weights)==50 and memory==[]
      folder.mkdir(parents=True,exist_ok=True)
      for n in ['policy.pt','policy_inference.npz','policy_inference.json']:(folder/n).write_bytes(b'recovered')
      return folder/'policy.pt'
    flow=types.SimpleNamespace(relative_file=lambda root,rel:root/rel,episode=episode,evaluate_return=lambda *x:[dict(high_accuracy=True)],checkpoint_backup=lambda *x:calls.append(x),publish_npz=lambda path,**kw:np.savez(path,**kw))
    sys.modules['flow']=flow;sys.modules['learning']=types.SimpleNamespace(fit=fit)
    model,rows=corrective.recover(a,data,'A_90',(np.zeros((2,28),np.float32),np.zeros((2,1),np.float32)),(None,None),initial)
    assert rows[0]['high_accuracy'] and len(calls)==1
    assert read(a.out/'corrective_round_1_PROVENANCE.json')['teacher_actuated'] is False
    print('PASS: 16 training-only references, deterministic selection, failed-rollout expert targets, target scaling, weighting, checkpoint reuse, early stop and backup callback')
