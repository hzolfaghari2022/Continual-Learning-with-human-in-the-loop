"""Bounded training-only expert relabeling of states visited by the frozen NN.
No validation/test expert labels, teacher mixing, or weakened acceptance gate.
"""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor,as_completed
import shutil
import numpy as np
from complex_engine import read,write,sha
from complex_trajectories import FEATURES,encode


def select_records(data,target,round_index):
    from flow import relative_file
    groups={}
    for r in data.records_for(target,'train'):
        c=read(relative_file(data.root,r['folder'])/'settings.json')
        key=(c['variant'],c['profile']['start_deg'])
        groups.setdefault(key,[]).append(r)
    chosen=[]
    for key in sorted(groups):
        records=groups[key]
        for j in range(min(2,len(records))):chosen.append(records[(2*round_index+j)%len(records)])
    return chosen


def recover(a,data,target,train,val,initial):
    from learning import fit
    from flow import relative_file,episode,evaluate_return,checkpoint_backup,publish_npz
    parent=a.out/'models'/'reused_checkpoint';parent.mkdir(parents=True,exist_ok=True)
    for n in ['policy.pt','policy_inference.npz','policy_inference.json']:
        dest=parent/n
        if dest.exists() and sha(dest)!=sha(initial.parent/n):raise ValueError('Reused checkpoint changed')
        if not dest.exists():shutil.copy2(initial.parent/n,dest)
    parent=parent/'policy.pt';xs=[];ys=[];reviews=[]
    write(a.out/'CHECKPOINT_REUSE.json',dict(source=str(initial),sha256=sha(initial),original_dataset=str(data.root),new_full_collection=False))
    for round_index in range(a.corrective_rounds):
        selected=select_records(data,target,round_index)
        if any(r['split']!='train' for r in selected):raise ValueError('Nontraining recovery episode')
        label='corrective_round_'+str(round_index+1)
        a.progress.stage(label+' training rollouts',len(selected))
        def work(r):
            cfg=read(relative_file(data.root,r['folder'])/'settings.json');cfg.pop('muscle_strength_audit',None)
            cfg.update(neural_checkpoint=str(parent.resolve()),collect_corrective_labels=True,collect_probes=False,compact_export=True,live_viewer=False,save_plots=False)
            folder=a.out/'corrective_rollouts'/label/r['episode_id']
            status=episode(folder,cfg,a)
            file=folder/'corrective_arrays.npz'
            if not file.exists():raise RuntimeError('Expert label export missing: '+str(folder))
            with np.load(file,allow_pickle=False) as z:
                if str(z['source_split'])!='train' or z['feature_names'].tolist()!=FEATURES:raise ValueError('Corrective label schema/split mismatch')
                x=encode(z['X_raw']);y=z['y_force_N']/650.
            if not len(x) or not np.isfinite(x).all() or not np.isfinite(y).all():raise ValueError('Empty/nonfinite corrective samples')
            return r['episode_id'],x,y,dict(episode_id=r['episode_id'],split='train',rollout_completed=status['status']=='completed',expert_samples=len(x),arrays_sha256=sha(file))
        results=[]
        with ThreadPoolExecutor(max_workers=a.workers) as pool:
            futures=[pool.submit(work,r) for r in selected]
            for future in as_completed(futures):results.append(future.result());a.progress.advance()
        # Stable concatenation despite asynchronous worker completion
        for _,x,y,_ in sorted(results,key=lambda z:z[0]):xs.append(x);ys.append(y)
        x=np.concatenate(xs);y=np.concatenate(ys)
        write(a.out/(label+'_PROVENANCE.json'),dict(teacher_actuated=False,parent_policy_sha256=sha(parent),sources=[z[3] for z in sorted(results,key=lambda z:z[0])],cumulative_expert_samples=len(x)))
        publish_npz(a.out/(label+'_training.npz'),X_encoded=x,y_normalized=y)
        combined=(np.concatenate([train[0],x]),np.concatenate([train[1],y]))
        a.current_weights=np.concatenate([data.loss_weights[(target,'train')],np.full(len(x),6.,np.float32)])
        a.weighted_mode=True;a.repair_mode=False;a.anneal=False;a.lr=.0001;a.epochs_adapt=a.corrective_epochs;a.replay_weight=0.
        parent=fit(a.out/'models'/label/('after_'+target),combined,{target:val},parent,[],a,round_index)
        rows=evaluate_return(a,data,parent,target,'validation',label)
        passed=all(r['high_accuracy'] for r in rows)
        reviews.append(dict(round=round_index+1,all_passed=passed,rows=rows))
        write(a.out/'CORRECTIVE_VALIDATION.json',reviews)
        checkpoint_backup(a,label+' models, training-only expert labels and validation')
        if passed:
            a.current_weights=data.loss_weights[(target,'train')]
            return parent,rows
    # Preserve the original 50/100/200 recovery gate if bounded relabeling did
    # not solve every validation reference. No bypass and no fabricated CL result.
    a.current_weights=data.loss_weights[(target,'train')]
    return parent,None
