& {
    $ErrorActionPreference = 'Stop'
    & "$env:USERPROFILE\miniconda3\envs\lstm-py312\python.exe" -u -X utf8 "$PSScriptRoot\run_recovery.py"
    if ($LASTEXITCODE -ne 0) { throw 'Run stopped; see the error above' }
}
