# Arm26 full recovery package v2

## Run in VS Code

1. Extract the entire ZIP (do not open scripts inside the ZIP)
2. Open the extracted Arm26_Recovery_v2 folder in VS Code
3. Open run_recovery.py
4. Choose Run Python File in Terminal (the triangle at the upper right)

No command-line arguments, conda activation or PowerShell script are required. The Python launcher selects your lstm-py312 Python executable automatically. If the extracted package is in a long OneDrive path, it copies the source to a short folder under your Windows user directory before starting. It runs only the matching bundled training version, preventing the old script's unrecognized --warm-start error.

The saved initial NN checkpoint from your supplied context archive is INCLUDED, with SHA256 integrity checks. Your existing 600-episode data stay on your computer and are not bundled. The default data path is:
C:\Users\hzlfghri\Arm26_600_20261112_145744\runs\run_2026-11-12_14-57-44_590837
If you moved it, a folder picker asks you to select the data run containing COLLECTION_COMPLETE.json.

## What runs

Reuses the saved initial NN and original data. Adds up to three training-only corrective rollout rounds with expert labels and CUDA refinement. Checks all initial validation references with the original limits. If they pass, runs the original noCL versus replay comparison. The comparison in this package returns to case A; it is not the earlier 250-episode return A/B/C package.

OpenSim physics uses CPU; NN training requires CUDA. Progress percentages refer to each stage. New results go into the printed package's runs folder. Existing data and old results are not overwritten. Models, corrective examples, provenance, HTML and Overleaf report generation, and verified GitHub backup are included. Successful remote backup still depends on authentication/network access. The launcher does not disable GitHub.

Full OpenSim/CUDA simulation cannot be executed in the preparation environment. Local verification covers Python syntax, launcher path handling and validation, training-only sample selection, expert targets and checkpoint reuse. Passing physical validation or a CL improvement is not guaranteed. See README_RECOVERY.md for the experiment details.
