# Final Arm26 PID data collector

Run this package NOW to collect the new PID datasets. It does not train a neural
network, update any existing network or run continual learning. It supplies the
motion/data contract needed for those next steps, and does not force an NN failure
or guarantee a CL improvement.

## Progress, speed and GitHub update

Start in a NEW extracted code folder. This revision changes the plan and source,
so do not resume an older revision's collection.

- Two requested speed conditions:1.0x and1.25x (in addition to varying speeds inside
  each trajectory). At the same profile,1.25x scales speed by1.25 and acceleration
  by1.5625. These conditions have separate seeds; compare strengths on the same
  motion ID. Pilots may reduce infeasible requested speeds. Actual selected scales,
  peak reference deg/s and deg/s² are saved in FROZEN_PLAN.json and SPEED_DEMANDS.csv.
- Default full workload: 480 episodes, 240 per strength, including train/validation/test.
- Default independent pilots:192 minimum; up to960 if all five declared speed
  attempts are needed. Minimum total672; maximum planned total1440. A failed
  feasibility or operational check can stop early. Interrupted retries are extra.
- Console updates every5 seconds: known total/completed, pilots/full counts,
  elapsed time, current episode simulation progress and a provisional ETA.
  PROGRESS.html refreshes every5 seconds; PROGRESS.json stores the same information.
  ETA is estimated from measured wall time and reference durations, excludes
  report/GitHub time and may change with calibration or machine load.
- Plot titles identify muscle strength, split, pilot/full index, reference family,
  starting elbow angle, fixed/moving shoulder, load, requested/selected speed and
  recovery initial conditions. Actual angles and error remain clearly labelled.

### Automatic GitHub backup

GitHub backup is ENABLED by default. The program asks for your GitHub repository
URL or an existing local clone path before any physics. It uses your computer's
Git authentication and commit identity. Install Git for Windows and configure
access to the chosen EXISTING repository first. No token belongs in a URL or file.
The app connection in ChatGPT does not authenticate Git on your computer.

It checks read/write access by uploading the collection plan and code first.
A dedicated cache clone is used, so your existing working checkout is not changed.
The default branch is used; --github-branch can select an existing branch.
It commits and pushes periodically (every10 full motion pairs, i.e.20 full episodes;
also during pilot checkpoints), after pilots and after the final report.
It never force-pushes. A failed push stops with local data intact.

Remote folder layout:

```text
arm26_pid_data/<collection-name>/
  strength_90/<episode-id>/episode.zip
  strength_60/<episode-id>/episode.zip
  pilot_and_failed_attempts/strength_90/...
  pilot_and_failed_attempts/strength_60/...
  collection_metadata/       # reports, plans, data manifests, speed table
  collector_code.zip         # runnable source, model and Geometry
  BACKUP_MANIFEST.json        # archive and restored-file SHA256 checksums
```

Each episode archive contains ALL saved raw timesteps, arrays, states, settings,
plots, strength audits and logs. Large archives are split into40 MiB pieces to
avoid individual Git file-size limits; no rows are downsampled for upload.
GITHUB_STATUS.json reports the verified pushed commit and destination. GitHub may
impose repository/account quotas; a failed upload is reported and local files stay.
No actual upload to your repository has occurred while developing this ZIP.

Examples (replace the repository URL with YOUR actual destination):

```powershell
python .\collect_complex_pid.py --github-repo "https://github.com/OWNER/REPOSITORY.git"
```

If you intentionally want local data only, use --no-github. After fixing credentials,
retry backup WITHOUT any more simulation:

```powershell
python .\collect_complex_pid.py --backup-only --run-folder "C:\FULL\COLLECTION" --github-repo "https://github.com/OWNER/REPOSITORY.git"
```

To restore raw episode folders from a cloned GitHub backup:

```powershell
python .\github_backup.py --restore "C:\CLONE\arm26_pid_data\COLLECTION_NAME" --destination "C:\RESTORED_DATA"
```

Keep the original local collection for subsequent training. The manifests contain
original absolute paths; restored datasets require rebasing those paths before
training. The restore command verifies raw file checksums.

To collect a single speed tier explicitly, add `--speed-levels 1`. The default uses two tiers.

## Viewer startup fix

This revision fixes the initial Model-stage cable force read in the live viewer.
If your first pilot stopped with that error, extract this revision and start a NEW
collection without --resume. The old failed folder stays intact. Physical settings
and dataset definitions are unchanged; source integrity guards intentionally reject
resuming an old collection after changing its Python code.

## Start the full collection

Extract into a NEW folder. Open PowerShell in the inner code folder:

```powershell
conda activate lstm-py312
python .\collect_complex_pid.py
```

Default full workload: **480 episodes** (288 training,96 validation,96 test), plus
at least192 independent pilot episodes and any required slower pilot attempts.
The counts are attempts, not a promise that every episode will be accepted.
Pilot calibration and quality checks prevent silently using poor PID targets.
Nonfinite simulator states stop the job as numerical failures; they are not
counted as evidence of NN failure or silently accepted as training data.
The program prints the result directory and workload before running physics.
`WORKLOAD.json` records nominal simulated minutes; actual wall time also depends
on pilot slowdown, CPU dynamics, plotting and real-time viewers.

Default output:
`C:\Users\hzlfghri\Arm26_Final_PID_Data\final_pid_<timestamp>_<id>\`

Live OpenSim and the elbow/error/shoulder/cable dashboard are enabled. A persistent
viewer is shared across the episode workers; no new console is opened per episode.
PID collection runs in CPU OpenSim. CUDA is relevant to subsequent NN training.
There is no GPU physics backend hidden in this code.

## Exactly what is varied

- Muscle force capacities:90% and60% of the original maximum isometric forces.
- Elbow initial REFERENCE angles:20,45 and70 degrees.
- Small initial tracking OFFSETS:-0.5,0,+0.5 degrees, separate from the reference.
- Initial elbow velocities:-5,0,+5 deg/s. The first three training repetitions
  cover the negative,zero andpositive recovery variants. Further repetitions
  cover additional offset/velocity combinations. Validation/test choices are
  independently seeded.
- Fixed-shoulder poses chosen from-5,0,15 degrees per condition, held constant
  across splits. Moving-shoulder centers are0 or5 deg, keeping the motion
  inside a reviewed region of this model while still providing coupled motion.
- Moving shoulder: smooth8-14 degree oscillations with varied phase/frequency,
  imposed through a native OpenSim C2 prescribed-coordinate spline. Broader shoulder ranges exposed both nonfinite simulator states and poor
  PID tracking associated with abrupt muscle-force changes. Slowing those motions
  did not resolve all failures. The final default therefore uses a reviewed
  bounded shoulder range,while retaining the original muscle geometry and forces.
- Four elbow motion families: a smooth baseline; irregular variable-speed
  waypoints/reversals up to about114 deg; windowed multisine; increasing-frequency
  chirps. The references and their derivatives are smooth at starts/stops.
- Seeded timing,phases and targets, independent of any NN outcomes.

The initial actual elbow angle is reference angle + declared offset. Recovery
transients are real simulation states, not artificial errors added to plots.
Every time sample is retained, including the initial recovery. The all-run
maximum-error gate includes recovery; it is not omitted to make teacher accuracy
appear better. Separate initial_recovery metrics and phase labels are recorded.

The default dumbbell is5 kg and fixed muscle excitation is0.02. This preserves a
controlled loading case while the motions change. `--masses 1 3 5` adds a load
sweep and triples the full count. Do not change load between compared methods
if the aim is to isolate a different experimental factor.

Arm26 has shoulder elevation and elbow flexion. Shoulder motion is externally
prescribed; the elbow cable controller does not actuate/control that shoulder.
No wrist,extra anatomical coordinates or arbitrary3-D shoulder motion is invented.
The study guards actual elbow3-123 deg and shoulder-25 to65 deg, plus cable geometry.

## Independent pilots and PID quality

For every condition, separate PILOT seeds test both recovery extremes at every
requested strength. Pilots are never included in train/validation/test manifests.
The speed-scale ladder is1,0.8,0.64,0.512,0.4096. The fastest passing all requested
strengths and both recovery checks is frozen before full collection. Speed scales
linearly and acceleration quadratically; the reference shape is retained.

The teacher uses actual OpenSim acceleration compensation plus fixed PID gains:

F = clip_[0,650]((qref_ddot +120*error +22*velocity_error +15*integral -a0)/b)

a0 is actual elbow acceleration with0 N cable tension; b is acceleration at1 N
minus a0. Gravity,muscle effects,load and prescribed-shoulder coupling are included
in the physical response. The affine force response is checked at2 N initially.
The integral is limited to+/-0.15 rad*s with anti-windup. Kp=120 s^-2,Kd=22 s^-1,
Ki=15 s^-3 are fixed at all strengths. The flexor-only cable stays within0-650 N.

Acceptance requires completed simulation, motion RMSE<=0.1 deg and full-run
maximum absolute error<=1.1 deg by default. Every attempted run,partial CSV and
failure is retained. A manifest record is accepted only when the same motion
passes at ALL requested strengths. If final split coverage is missing,it is
reported. Full episodes are not repeatedly changed until an NN failure/success
appears. If pilot feasibility fails,the full collection stops with saved evidence.

## Data roles for the later CL experiment

The DEFAULT old skill A is now **variable_speed with a fixed shoulder**, so the
initial NN90 will itself learn a more demanding skill before adaptation:

- TASK_A_90.json: accepted old-skill90% train/validation/test episodes.
- TASK_B_60.json: accepted new-motion60% episodes; complex families and/or a
  moving shoulder. Simple fixed-shoulder baseline controls are excluded.
- DIAGNOSTIC_COMPLEX_90.json: the new motions at90%,for an initial generalization test.
- CONTROL_A_60.json: original A references at60%,to help isolate strength effects.
- ALL_ACCEPTED_90.json and ALL_ACCEPTED_60.json: all accepted records at each strength,
  including controls. Do NOT use ALL_ACCEPTED_90 for initial training if you later
  want to claim the complex diagnostic motions were unseen.

All paired strengths share motion IDs,reference parameters,initial offsets and
initial velocities. Different data splits use distinct seeds. Future studies can
compare ordinary sequential adaptation,EWC/replay,and joint A+B training using
the same fixed split-controlled records. Future training-seed repeats should
reuse that data rather than redraw the test set after seeing outcomes.

A failure of the original NN90 on an UNFAMILIAR motion is a generalization gap.
The later retention test is: train NN90 on A,adapt to B,then use the SAME frozen
adapted weights on the original held-out A90 references. Compare that with and
without CL. The initial A skill must first be demonstrated. No larger improvement
is promised merely because the reference is more complicated.

To retain the older smooth A definition,use `--old-family baseline_smooth` before
starting a new run. To collect an optional third strength:

```powershell
python .\collect_complex_pid.py --strengths 90 60 45
```

This creates720 full attempts plus at least288 pilots by default and also writes
TASK_C_45.json. The extra strength is subject to the same feasibility/quality gates.
Other integer strength percentages between30 and100 may be added,but90 and60 must
remain present. ALL_ACCEPTED_<percent>.json is written for every requested strength.

## File contract:24 inputs

Every full episode includes:

- signals.csv: actual physical states,references,error,force,saturation,cable
  geometry,muscle outputs,phase and declared recovery state.
- training_arrays.npz: X_raw [N,24],y_force_N [N,1],time_s,feature_names.
- legacy22_arrays.npz: first22 features with the same force/time data.
- states.csv and OpenSim states.sto; playback_model.osim.
- settings.json,status.json,muscle_strength_audit.json,tracking.pdf/png,console.log.
- file_integrity.json: checksums verified before reusing a completed attempt.

The24 features are the previous22 plus ACTUAL shoulder velocity and acceleration.
Actual shoulder angle is measured at each sample. NN targets are actual PID cable
forces in newtons. Input scales/order/error encoding and the650 N output scale
are recorded in TRAINING_HANDOFF.json for the next training-code update.

The previous22-input locked-shoulder training/simulation scripts must NOT consume
this dataset unchanged. They assume another feature/reference/provenance contract.
For the moving-shoulder CL study,we will need a new24-input NN90 trained on A,
then adaptation of that same architecture to B. This package collects only data.
The optional evaluate_frozen.py supports an old22-input exported policy as a
labelled generalization diagnostic,but it cannot add missing shoulder derivatives
to that already-trained model. No PID fallback is present in that diagnostic.

## Report and audit locations

Inside the printed collection directory:

- COLLECTION_OVERLEAF.zip: upload to Overleaf and compile main.tex.
- COLLECTION_REPORT.html: open figures without a LaTeX installation.
- COLLECTION_REPORT.pdf: available if pdflatex is installed locally.
- PID_DATA_QUALITY.csv: status,initial conditions,RMSE and acceptance per episode.
- DATASET_MANIFEST.json: all full attempts and individual/all-strength acceptance.
- COLLECTION_STATUS.json: full completion and any missing condition/split coverage.
- UNSCALED_PLAN.json,PILOT_CALIBRATION.json,FROZEN_PLAN.json: reference audit trail.
- COLLECTION.json,ENVIRONMENT.json,source/: frozen configuration and source snapshot.
- TRAINING_HANDOFF.json: primary array schema,encoding,targets and role-file names.

The report describes PID data quality and future experiment roles; it does not
claim an NN or CL result. Every raw timestep remains in the episode files.

## Preview,smaller run and resume

Preview only,without OpenSim physics:

```powershell
python .\collect_complex_pid.py --plan-only
```

Inspect collection_overleaf/figures/reference_preview.png and kinematics_preview.png
in the printed folder. Then repeat with --resume instead of --plan-only to collect
that exact configured plan. Ready-to-view nominal previews are also in this ZIP's
motion_preview folder; they are reference curves,not measured tracking results.

Smaller first run,keeping all four motion families and both shoulder modes:

```powershell
python .\collect_complex_pid.py --initial-angles 45 --train-reps 1 --validation-reps 1 --test-reps 1
```

This attempts96 full episodes plus at least64 pilots. For a full run with less
graphics overhead,add --no-live. Live display is enabled unless that flag is used.

Resume with the original flags plus --resume,or select the directory explicitly
with --run-folder "C:\FULL\COLLECTION". Completed attempts are checked and reused.
Interrupted partial attempts are archived before a replacement run starts. A GUI
startup/export failure may be retried on explicit resume after an environment
repair; its previous attempt is preserved. --no-live may be changed on resume.
Never edit source or physical settings of an unfinished collection; use a NEW run.

Rebuild the data-quality report without more physics:

```powershell
python .\collect_complex_pid.py --report-only --run-folder "C:\FULL\COLLECTION"
```

Run portable checks: `python -m unittest discover -s tests -v`.
See VALIDATION.txt for actual physics checks and remaining limits. The full default
collection is intended to run on your computer,with pilot gates validating your
chosen settings. Keep Arm26_Data and earlier result folders; this uses a new root.
