"""Joint-motion previews, real hand paths and a three-task PID quality report."""
from pathlib import Path
import csv,html,io,shutil,subprocess,zipfile
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from complex_engine import read,write
from atomic_io import atomic_bytes
from complex_trajectories import reference,shoulder_reference,FEATURES
from task_plan import TASKS

def escape(text):
 s=str(text)
 for a,b in [('\\',r'\textbackslash{}'),('_',r'\_\allowbreak{}'),('%',r'\%'),('&',r'\&'),('#',r'\#')]:s=s.replace(a,b)
 return s

def finish(fig,folder,name):
 folder=Path(folder);folder.mkdir(parents=True,exist_ok=True);fig.tight_layout()
 for extension in ('pdf','png'):
  buf=io.BytesIO();fig.savefig(buf,format=extension,dpi=160,bbox_inches='tight');atomic_bytes(folder/(name+'.'+extension),buf.getvalue())
 plt.close(fig)

def preview(out,plan):
 tids=[tid for tid in TASKS if any(c['task_id']==tid for c in plan)];fig,axs=plt.subplots(len(tids),2,figsize=(11,3*len(tids)),squeeze=False)
 for row,tid in enumerate(tids):
  candidates=[c for c in plan if c['task_id']==tid and c['split']=='train'];variants=sorted({c['variant'] for c in candidates})
  for variant in variants:
   c=min([c for c in candidates if c['variant']==variant],key=lambda c:abs(c['profile']['start_deg']-50));ts=np.linspace(0,c['duration_s'],800)
   axs[row,0].plot(ts,np.degrees([reference(t,c)[0] for t in ts]),label='Variant '+variant);axs[row,1].plot(ts,np.degrees([shoulder_reference(t,c)[0] for t in ts]),label='Variant '+variant)
  axs[row,0].set(title=tid+': elbow reference',ylabel='Elbow (deg)');axs[row,1].set(title=TASKS[tid]['name'],ylabel='Shoulder (deg)')
  for ax in axs[row]:ax.set_xlabel('Time (s)');ax.grid(alpha=.2);ax.legend()
 finish(fig,Path(out)/'collection_overleaf/figures','joint_reference_preview')

def build_report(out):
 out=Path(out).resolve();report=out/'collection_overleaf';figs=report/'figures';figs.mkdir(parents=True,exist_ok=True)
 plan=read(out/'FROZEN_PLAN.json') if (out/'FROZEN_PLAN.json').exists() else read(out/'UNSCALED_PLAN.json');preview(out,plan)
 source=read(out/'DATASET_MANIFEST.json') if (out/'DATASET_MANIFEST.json').exists() else {};records=source.get('records',[]);config=read(out/'COLLECTION.json')['config'];workload=read(out/'WORKLOAD.json');pictures=[('joint_reference_preview','Predeclared elbow and shoulder commands. These are joint references, not measured errors or arbitrary three-dimensional hand targets.')]
 fields=['task_id','task_name','task_order','strength_scale','episode_id','condition','split','variant','trajectory','status','samples','accepted','motion_rmse_deg','requested_speed_scale','selected_speed_scale']
 with (out/'PID_DATA_QUALITY.csv').open('w',newline='') as f:w=csv.DictWriter(f,fieldnames=fields,extrasaction='ignore');w.writeheader();w.writerows(records)
 tids=[tid for tid in TASKS if tid in workload['counts']];selected={}
 for tid in tids:
  candidates=[r for r in records if r['task_id']==tid and r['split']=='validation']
  selected[tid]=[min([r for r in candidates if r['variant']==v],key=lambda r:r['episode_id']) for v in sorted({r['variant'] for r in candidates})]
 if any(selected.values()):
  fig,axs=plt.subplots(1,len(tids),figsize=(4.5*len(tids),4.5),squeeze=False)
  for ax,tid in zip(axs[0],tids):
   for r in selected[tid]:
    file=Path(r['folder'])/'signals.csv'
    if not file.exists():continue
    with file.open() as f:rr=list(csv.DictReader(f))
    if rr:ax.plot([float(x['hand_x_m']) for x in rr],[float(x['hand_y_m']) for x in rr],label='Variant '+r['variant']+(' (partial)' if r['status']!='completed' else ''))
   ax.set(title=tid+' actual hand path',xlabel='Ground X (m)',ylabel='Ground Y (m)');ax.axis('equal');ax.grid(alpha=.2)
   if selected[tid]:ax.legend(fontsize=9)
  finish(fig,figs,'actual_hand_paths');pictures.append(('actual_hand_paths','Actual OpenSim hand paths in the model movement plane, using validation episodes selected by metadata only. The shoulder is prescribed and the cable controls elbow assistance. This is not unrestricted lateral or three-dimensional reaching.'))
 for tid in tids:
  if selected[tid]:
   r=selected[tid][0];folder=Path(r['folder'])
   if (folder/'tracking.pdf').exists():
    for extension in ('pdf','png'):shutil.copy2(folder/('tracking.'+extension),figs/(tid+'_pid_tracking.'+extension))
    pictures.append((tid+'_pid_tracking',tid+' measured PID validation tracking: '+r['episode_id']+'. Reference/actual elbow, tracking error, shoulder and cable force. This is teacher quality, not an NN/EWC result.'))
 if records:
  fig,axs=plt.subplots(1,2,figsize=(11,4))
  for tid in tids:
   rr=[r for r in records if r['task_id']==tid and r['split']!='test' and r['status']=='completed' and r['motion_rmse_deg'] is not None]
   if rr:axs[0].hist([r['motion_rmse_deg'] for r in rr],bins=12,alpha=.5,label=tid);axs[1].hist([r['samples'] for r in rr],bins=12,alpha=.5,label=tid)
  axs[0].set(title='PID development tracking quality',xlabel='Motion RMSE (deg)',ylabel='Episode count');axs[1].set(title='Saved development samples',xlabel='Samples per episode',ylabel='Episode count')
  for ax in axs:ax.grid(alpha=.2);ax.legend()
  finish(fig,figs,'teacher_quality');pictures.append(('teacher_quality','Training/validation PID quality and sample counts. Final neural test performance is not evaluated by this collector. Failed attempts remain in the quality CSV.'))
 rows=[]
 for tid in tids:
  for split in ('train','validation','test'):
   rs=[r for r in records if r['task_id']==tid and r['split']==split]
   rows.append(dict(task_id=tid,split=split,planned=workload['counts'][tid][split],attempted=len(rs),accepted=sum(r['accepted'] for r in rs),samples=sum(r['samples'] for r in rs if r['accepted'])))
 write(out/'DATA_COUNTS.json',rows)
 table='\n'.join(' & '.join([escape(r['task_id']),escape(r['split']),str(r['planned']),str(r['attempted']),str(r['accepted'])])+' '+chr(92)*2 for r in rows)
 feature_list='\n'.join(r'\item \texttt{'+escape(name)+'}' for name in FEATURES)
 body=r'''\documentclass[11pt]{article}
\usepackage[margin=20mm]{geometry}
\usepackage{graphicx,booktabs,amsmath,hyperref,longtable}
\setlength{\parindent}{0pt}\setlength{\parskip}{6pt}
\title{Arm26: Three-Task PID Data Collection}
\author{Hussein Zolfaghari}\date{\today}
\begin{document}\maketitle
\section*{Purpose and model scope}
This independent backup dataset supports a future sequential-learning study: learn Task 1, then Task 2, then Task 3; freeze each selected checkpoint and evaluate retention on exactly the original held-out Tasks 1 and 2. This package collects accurate PID demonstrations only. It does not train an MLP, implement EWC or impose an error difference.
The original Arm26 has shoulder and elbow rotations in a movement plane. A prescribed shoulder driver supplies shoulder motion; one independently controlled cable, \texttt{exo\_flexor}, supplies elbow assistance. This is not an unrestricted three-dimensional or second-cable control experiment. Actual hand X/Y/Z positions are recorded to show the physical paths.
\section*{Predeclared tasks}
\begin{tabular}{p{.12\linewidth}p{.12\linewidth}p{.66\linewidth}}\toprule Task & Strength & Motion \\\midrule
Task 1 & 90\% & Slow smooth elbow flexion/extension at two fixed shoulder postures.\\
Task 2 & 60\% & Variable-speed reversals with positive or negative shoulder--elbow coordination.\\
Task 3 & 30\% & Faster multisine/chirp elbow references with smooth mixed-frequency shoulder motion.\\\bottomrule\end{tabular}\par
For Task 2, $q_s=q_{s0}+g(q_r-q_0)$ with $g=+0.2$ or $-0.2$, and derivatives are prescribed consistently. Task 3 uses windowed mixtures of shoulder sinusoids; a quintic window joins initial/final holds smoothly. Commands are within the reviewed joint envelope; no claim of a straight horizontal hand target is made.
Requested speed multipliers are 0.85, 1.15 and 1.5 for Tasks 1, 2 and 3. Independent PID pilots may select factors 1, 0.8 or 0.64 before the full plan is frozen; actual selected speeds are logged. No neural error or final test outcome selects those factors.
All muscles have their maximum isometric force scaled from a fresh original model by 0.9, 0.6 or 0.3. Muscle excitation is EXCITATION in all three tasks; this is a simulated experimental setting, not a clinical calibration. Dumbbell mass is MASS kg and cable force is limited to 650 N.
\section*{Workload, split and readiness}
The default plan is 240 full episodes: 80 per task, comprising 56 training, 8 validation and 16 test episodes. Each task has four initial elbow references (20, 35, 50, 70 degrees) and two variants, with 7/1/2 independent repetitions per condition. The split unit is an entire episode; overlapping samples/windows never cross splits. Source task labels and strength values remain explicit metadata. Independent pilot seeds are excluded from all three splits.
Actual planned/attempted/accepted counts are below. All timesteps of accepted episodes are retained. A rejected full episode is preserved and makes readiness false; no final test episode is moved into training to repair the ratio.
\begin{center}\begin{tabular}{llrrr}\toprule Task & Split & Planned & Attempted & Accepted\\\midrule
COUNTSTABLE
\bottomrule\end{tabular}\end{center}
Actual full episode count: FULLCOUNT. Independent pilot range: PILOTMIN--PILOTMAX. Ready for neural training: READY.
\section*{Teacher controller}
OpenSim evaluates the current elbow acceleration at zero and one newton cable tension:
\[a_0=\ddot q(0),\quad b=\ddot q(1)-a_0,\quad a^*=\ddot q_r+120(q_r-q)+22(\dot q_r-\dot q)+15I.\]
The commanded tension is $F=\operatorname{clip}_{[0,650]}[(a^*-a_0)/b]$. The bounded integral $I$ uses saturation antiwindup. This is model-based compensation plus PID feedback in acceleration coordinates; it is not an uncompensated PID controller. The force/acceleration map is checked at 2 N at the initial state. Muscle strengths, initial perturbations, states and actual force commands are audited and saved.
Default acceptance limits are motion RMSE below 0.1 degree and full-episode maximum absolute error below 1.1 degrees. Actual configured limits: RMSELIMIT and MAXLIMIT degrees. These are PID teacher quality gates, not promised neural accuracy.
\section*{Future MLP/EWC comparison}
Use identical MLP topology, observations, parent weights, data, optimizer settings and per-stage training budgets in both branches. Ordinary training minimizes imitation error. EWC additionally protects parameters important for earlier tasks; a three-task implementation must consolidate after both Tasks 1 and 2. Protecting only Task 1 does not establish preservation of Task 2.
Use validation data to choose epochs and lambda. Keep final test arrays out of training, normalization fitting, importance estimation and lambda selection. Once all selected models are frozen, evaluate stored checkpoints on the same held-out references without learning; reset the physical initial state for each test. Test order does not itself create forgetting. Report newest-task learning alongside old-task retention, including failures and seed variability. Neither 5-degree no-CL error nor zero EWC error is guaranteed.
\section*{Saved network observations and extra signals}
The binary array contains 24 raw observations in the exact order below; force target is \texttt{y\_force\_N}, normalized by 650 N in a future trainer. Fixed encoding divides by documented scales, with input 3 encoded as $(q_r-q)/0.02$ and input 4 as $(\dot q_r-\dot q)/0.2$. Simulator muscle activation and fiber length are state observations; physical deployment would require appropriate sensing or estimation. Strength is a known descriptor in this raw contract. Any strength-unobserved variant must use identical inputs in both CL branches and be declared before final evaluation.
\small\begin{enumerate}
FEATURELIST
\end{enumerate}\normalsize
Actual hand X/Y/Z, human muscle torque, cable torque, reference derivatives, force saturation and full simulator states are also retained. Task IDs are not silently added as extra network inputs. The earlier two-task trainers require an explicit three-task update.
'''
 for a,b in {'EXCITATION':str(config['muscle_excitation']),'MASS':str(config['mass_kg']),'COUNTSTABLE':table,'FULLCOUNT':str(workload['full_episodes']),'PILOTMIN':str(workload['minimum_pilot_episodes']),'PILOTMAX':str(workload['maximum_pilot_episodes']),'READY':str(source.get('ready_for_training',False)),'RMSELIMIT':str(config['rmse_limit']),'MAXLIMIT':str(config['max_error_limit']),'FEATURELIST':feature_list}.items():body=body.replace(a,b)
 for name,caption in pictures:body+=r'\clearpage\section*{'+escape(name.replace('_',' ').title())+r'}\includegraphics[width=\linewidth]{figures/'+name+'.pdf}'+r'\par '+escape(caption)+'\n'
 body+=r'\end{document}';(report/'main.tex').write_text(body)
 compiled=False
 if shutil.which('pdflatex'):
  with (out/'REPORT_COMPILE.log').open('w') as f:
   for _ in range(2):
    result=subprocess.run(['pdflatex','-interaction=nonstopmode','-halt-on-error','main.tex'],cwd=report,stdout=f,stderr=subprocess.STDOUT)
    if result.returncode:break
  compiled=result.returncode==0
  if compiled:shutil.copy2(report/'main.pdf',out/'COLLECTION_REPORT.pdf')
 for name in ('DATA_COUNTS.json','WORKLOAD.json','COLLECTION.json','TRAINING_HANDOFF.json','PID_DATA_QUALITY.csv'):
  if (out/name).exists():shutil.copy2(out/name,report/name)
 with zipfile.ZipFile(out/'COLLECTION_OVERLEAF.zip','w',zipfile.ZIP_DEFLATED) as z:
  for file in report.rglob('*'):
   if file.is_file() and file.suffix in ('.tex','.pdf','.png','.json','.csv'):z.write(file,file.relative_to(report))
 page='<html><meta charset="utf-8"><style>body{max-width:1100px;margin:40px auto;font:18px Georgia}img{width:100%}</style><h1>Arm26 three-task PID collection</h1><p>Accurate teacher data, not measured neural/EWC results.</p><pre>'+html.escape(str(rows))+'</pre>'
 for name,caption in pictures:page+='<figure><img src="collection_overleaf/figures/'+name+'.png"><figcaption>'+html.escape(caption)+'</figcaption></figure>'
 (out/'COLLECTION_REPORT.html').write_text(page+'</html>');write(out/'REPORT_STATUS.json',dict(local_pdf_compiled=compiled,overleaf=str(out/'COLLECTION_OVERLEAF.zip'),note='Compile main.tex in Overleaf. See REPORT_COMPILE.log for a local LaTeX failure.'))
 print('COLLECTION REPORT SAVED:',out/'COLLECTION_OVERLEAF.zip','| local PDF:',compiled,flush=True)
