Validation scope
================
15 automated checks passed:
- Default 240-episode budget, exact 56/8/16 split for each of three tasks.
- Unique episode IDs and reference hashes separated across train/validation/test.
- Task strengths 0.9/0.6/0.3, common excitation 0.10, no neural policy or live viewer.
- Default elbow/shoulder references inside declared joint envelopes.
- Analytic shoulder velocity/acceleration consistent with finite differences for
  both coordination signs and both mixed-wave task variants.
- Temporary Windows lock retries, nonfatal progress display failures and critical
  data integrity errors; CSV truncation/force corruption rejection; complete
  multi-megabyte binary publication.
- A real local Git non-fast-forward race between two independent clones was
  resolved while preserving both collectors' commits, without force push.

Real OpenSim 4.6 validation:
- Six full-duration probes at DEFAULT dt=0.005 s and excitation 0.10 passed PID
  quality gates. These cover both variants across all three tasks, including
  initial elbow references of 20 and 70 deg and initial recovery disturbances.
- A reduced complete collection passed 12 episodes: 3 independent pilots and
  9 full episodes (train/validation/test for each task) at dt=0.01 s. All task
  records were accepted, all CSV/binary/state exports passed integrity checks,
  and readiness was true. This is workflow validation, not the default full run.
- The reduced run resumed without any worker reruns; 72 checked episode files
  remained byte-identical. All 12 attempt archives were pushed to a LOCAL bare
  Git test repository on a new branch and restored with matching binary-array
  checksums for T1_90, T2_60 and T3_30. The user's actual repository was not updated.
- Generated Overleaf source compiled successfully. Representative report pages,
  task tables, and real simulated hand paths were visually reviewed.

Limitations:
The full default 240 episodes have not run here. The user's collector performs
independent PID feasibility checks for all declared conditions before full data.
Physics validation used CPU, and there are no live windows in this package.
Native Windows lock behavior was simulated. The later MLP/EWC study is separate;
no neural tracking, forgetting, large no-CL error, near-zero EWC error or CL
advantage is claimed by these checks. The previous two-task trainers require an
explicit update for this new three-task manifest.
