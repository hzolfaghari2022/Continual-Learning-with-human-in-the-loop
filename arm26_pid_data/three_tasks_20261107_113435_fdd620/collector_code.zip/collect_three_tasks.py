"""Headless three-task PID collection; no neural training or CL-result selection."""
import runtime_setup
import argparse,copy,importlib.util,json,math,shutil,sys,time,uuid
from pathlib import Path
import episode_io
from episode_io import execute,validate_saved_attempt
from complex_engine import read,write,sha
from complex_trajectories import FEATURES,SCALES,configure,reference_digest,speed_statistics
from task_plan import TASKS,conditions,full_plan,counts,make_episode,pilot_recoveries
ROOT=Path(__file__).resolve().parent
REPO='https://github.com/hzolfaghari2022/Continual-Learning-with-human-in-the-loop.git'
PILOT_FACTORS=[1.,.8,.64]
PROGRESS=None

def main():
 global PROGRESS
 p=argparse.ArgumentParser(description=__doc__)
 p.add_argument('--output-root',type=Path,default=Path.home()/'Arm26_Three_Task_PID_Data');p.add_argument('--run-folder',type=Path);p.add_argument('--resume',action='store_true');p.add_argument('--plan-only',action='store_true');p.add_argument('--pilot-only',action='store_true');p.add_argument('--report-only',action='store_true');p.add_argument('--backup-only',action='store_true')
 p.add_argument('--tasks',nargs='+',choices=list(TASKS),default=list(TASKS));p.add_argument('--variants',nargs='+',choices=['A','B'],default=['A','B']);p.add_argument('--initial-angles',type=float,nargs='+',default=[20.,35.,50.,70.])
 p.add_argument('--train-reps',type=int,default=7);p.add_argument('--validation-reps',type=int,default=1);p.add_argument('--test-reps',type=int,default=2);p.add_argument('--initial-errors',type=float,nargs='+',default=[-.5,0.,.5]);p.add_argument('--initial-velocities',type=float,nargs='+',default=[-5.,0.,5.]);p.add_argument('--seed',type=int,default=2026111701)
 p.add_argument('--mass-kg',type=float,default=5.);p.add_argument('--muscle-excitation',type=float,default=.10);p.add_argument('--dt',type=float,default=.005);p.add_argument('--rmse-limit',type=float,default=.1);p.add_argument('--max-error-limit',type=float,default=1.1);p.add_argument('--episode-timeout',type=float,default=600.)
 p.add_argument('--github-repo',default=REPO);p.add_argument('--github-cache',type=Path);p.add_argument('--github-branch',default='arm26-three-task-data');p.add_argument('--github-every',type=int,default=20);p.add_argument('--no-github',action='store_true');a=p.parse_args()
 if min(a.train_reps,a.validation_reps,a.test_reps,a.github_every)<1:p.error('Positive repetition/backup counts required.')
 for values in (a.tasks,a.variants,a.initial_angles,a.initial_errors,a.initial_velocities):
  if len(values)!=len(set(values)):p.error('Repeated entries would duplicate episodes.')
 if not all(math.isfinite(v) and 20<=v<=70 for v in a.initial_angles):p.error('Use the reviewed 20..70 degree initial-angle range.')
 if not all(math.isfinite(v) and abs(v)<=.75 for v in a.initial_errors) or not all(math.isfinite(v) and abs(v)<=15 for v in a.initial_velocities):p.error('Recovery offsets <=0.75 deg and speeds <=15 deg/s required.')
 if not .001<=a.dt<=.02 or not 0<=a.mass_kg<=10 or not 0<a.muscle_excitation<=.15 or not all(math.isfinite(v) and v>0 for v in (a.rmse_limit,a.max_error_limit,a.episode_timeout)):p.error('Invalid physical/timing/quality setting.')
 if max(abs(v) for v in a.initial_errors)>a.max_error_limit:p.error('Initial disturbance exceeds acceptance limit.')
 pointer=ROOT/'LATEST_THREE_TASK_COLLECTION.txt'
 out=(a.run_folder or (Path(pointer.read_text().strip()) if (a.resume or a.report_only or a.backup_only) and pointer.exists() else a.output_root/('three_tasks_'+time.strftime('%Y%m%d_%H%M%S')+'_'+uuid.uuid4().hex[:6]))).resolve()
 if a.report_only:
  from task_report import build_report
  build_report(out);return 0
 cache=a.github_cache or Path.home()/'Arm26_ThreeTask_Git_Cache'/out.name
 if a.backup_only:
  from github_backup import GitBackup
  GitBackup(a.github_repo,out,a.github_branch,cache).sync(ROOT);return 0
 if not a.plan_only and importlib.util.find_spec('opensim') is None:raise ImportError('Activate lstm-py312 with OpenSim 4.6. No PyTorch or CUDA is required for PID collection.')
 out.mkdir(parents=True,exist_ok=True)
 excluded={'output_root','run_folder','resume','plan_only','pilot_only','report_only','backup_only','github_repo','github_cache','github_branch','github_every','no_github'}
 config={k:v for k,v in vars(a).items() if k not in excluded};config['task_definitions']=TASKS;config['source_hashes']={f.name:sha(f) for f in ROOT.glob('*.py')};config['model_sha256']=sha(ROOT/'arm26_exosuit.osim')
 if (out/'COLLECTION.json').exists():
  if read(out/'COLLECTION.json')['config']!=config:raise ValueError('Saved configuration/source changed. Use original settings/source to resume; create a new run for a revised experiment.')
 else:write(out/'COLLECTION.json',dict(format_version=3,protocol='three_tasks_pid_v1',config=config,features=FEATURES,collection_only=True))
 pointer.write_text(str(out));cs=conditions(a);plan=full_plan(a);recoveries=pilot_recoveries(a);minimum=len(cs)*len(recoveries)
 write(out/'UNSCALED_PLAN.json',plan);write(out/'WORKLOAD.json',dict(full_episodes=len(plan),counts=counts(plan),minimum_pilot_episodes=minimum,maximum_pilot_episodes=len(PILOT_FACTORS)*minimum,minimum_total=len(plan)+minimum,maximum_total=len(plan)+len(PILOT_FACTORS)*minimum,note='Counts exclude repeated interrupted/operational retries; no duration promise.'))
 from task_report import preview
 preview(out,plan)
 print('THREE-TASK RESULT FOLDER:',out,flush=True);print('PLAN:',json.dumps(counts(plan)),'| full',len(plan),'| pilots',minimum,'to',len(PILOT_FACTORS)*minimum,flush=True)
 print('HEADLESS PID ONLY | excitation',a.muscle_excitation,'| cable exo_flexor | shoulder prescribed | no CL gains are imposed',flush=True)
 if a.plan_only:return 0
 from collection_progress import Progress
 PROGRESS=Progress(out,minimum,len(PILOT_FACTORS)*minimum,len(plan),sum(c['duration_s'] for c in plan));episode_io.PROGRESS=PROGRESS
 backup=None
 if not a.no_github:
  from github_backup import GitBackup
  backup=GitBackup(a.github_repo,out,a.github_branch,cache);backup.sync(ROOT)
 else:write(out/'GITHUB_STATUS.json',dict(status='disabled_explicitly'))
 import opensim as o
 write(out/'ENVIRONMENT.json',dict(opensim=o.GetVersion(),python=sys.version,physics_device='CPU',collection_only=True,live_windows=False))
 snapshot=out/'source';snapshot.mkdir(exist_ok=True)
 for file in list(ROOT.glob('*.py'))+[ROOT/'arm26_exosuit.osim']:shutil.copy2(file,snapshot/file.name)
 shutil.copytree(ROOT/'Geometry',snapshot/'Geometry',dirs_exist_ok=True)
 cp=out/'PILOT_CALIBRATION.json';calibration=read(cp) if cp.exists() else {}
 for c in cs:
  key=c['key']
  if key in calibration and calibration[key]['selected_factor'] is not None:
   attempts=calibration[key]['attempts']
   for attempt in attempts:
    folder=Path(attempt['folder']);validate_saved_attempt(read(folder/'settings.json'),folder,read(folder/'status.json'))
   PROGRESS.done['pilot']+=len(attempts);PROGRESS.extra+=max(0,len(attempts)-len(recoveries));PROGRESS.refresh(force=True);continue
  attempts=[];selected=None
  for factor in PILOT_FACTORS:
   if factor!=1.:PROGRESS.add_pilot_batch(len(recoveries))
   ok=True
   for i,recovery in enumerate(recoveries):
    cfg=make_episode(a,c,'pilot',i,factor,pilot=True,recovery=recovery);folder=out/'pilot'/c['task_id']/key/('factor_'+format(factor,'.8g'))/('recovery_'+str(i));result=execute(cfg,folder,a.episode_timeout);ok &= result['accepted_for_imitation']
    attempts.append(dict(factor=factor,recovery=list(recovery),accepted=result['accepted_for_imitation'],status=result['status'],folder=str(folder),motion_only=result.get('motion_only')))
   if ok:selected=factor;break
  calibration[key]=dict(selected_factor=selected,attempts=attempts);write(cp,calibration)
  if selected is None:
   from task_report import build_report
   PROGRESS.stage('report');build_report(out);write(out/'COLLECTION_STATUS.json',dict(status='pilot_failed',condition=key,ready_for_training=False));raise RuntimeError('PID feasibility failed for '+key+' at every declared speed. Full data were not collected. Read the preserved pilot traces; no neural test was used to select a setting.')
  if backup is not None and PROGRESS.done['pilot']%a.github_every==0:PROGRESS.stage('github_backup');backup.sync(ROOT);PROGRESS.stage('pilot')
 if a.pilot_only:
  from task_report import build_report
  PROGRESS.stage('report');build_report(out);write(out/'PILOT_STATUS.json',dict(status='pilot_complete',note='Resume without --pilot-only for full data.'))
  if backup is not None:PROGRESS.stage('github_backup');backup.sync(ROOT,final_status='pilot_complete')
  PROGRESS.stage('pilot_complete');return 0
 final=[]
 for base in plan:
  cfg=copy.deepcopy(base);configure(cfg,cfg['requested_speed_scale']*calibration[cfg['condition']]['selected_factor']);cfg['reference_sha256']=reference_digest(cfg);cfg['speed_statistics']=speed_statistics(cfg);final.append(cfg)
 write(out/'FROZEN_PLAN.json',final);PROGRESS.full_seconds=sum(c['duration_s'] for c in final)
 if backup is not None:PROGRESS.stage('github_backup');backup.sync(ROOT)
 PROGRESS.stage('full');records=[]
 for i,cfg in enumerate(final,1):
  pct=round(100*cfg['strength_scale']);folder=out/'tasks'/cfg['task_id']/('strength_'+str(pct))/cfg['episode_id'];result=execute(cfg,folder,a.episode_timeout)
  records.append(dict(task_id=cfg['task_id'],task_name=cfg['task_name'],task_order=cfg['task_order'],strength_scale=cfg['strength_scale'],episode_id=cfg['episode_id'],motion_id=cfg['motion_id'],condition=cfg['condition'],split=cfg['split'],variant=cfg['variant'],trajectory=cfg['trajectory'],folder=str(folder),reference_sha256=cfg['reference_sha256'],arrays_sha256=sha(folder/'training_arrays.npz') if (folder/'training_arrays.npz').exists() else None,samples=result['sample_count'],status=result['status'],accepted=result['accepted_for_imitation'],motion_rmse_deg=(result.get('motion_only') or {}).get('rmse_deg'),requested_speed_scale=cfg['requested_speed_scale'],selected_speed_scale=cfg['speed_scale']))
  write(out/'DATASET_MANIFEST.json',dict(format_version=3,protocol='three_tasks_pid_v1',features=FEATURES,records=records,complete=False,ready_for_training=False))
  if backup is not None and i%a.github_every==0:PROGRESS.stage('github_backup');backup.sync(ROOT);PROGRESS.stage('full')
 ready=all(r['accepted'] for r in records) and len(records)==len(final)
 write(out/'DATASET_MANIFEST.json',dict(format_version=3,protocol='three_tasks_pid_v1',features=FEATURES,records=records,complete=True,ready_for_training=ready,planned_counts=counts(final),note='Rejected records are preserved, not silently reused or replaced; no held-out record enters development.'))
 for tid in a.tasks:write(out/(tid+'.json'),dict(task=TASKS[tid],task_id=tid,features=FEATURES,records=[r for r in records if r['task_id']==tid and r['accepted']],complete=True,ready_for_training=ready))
 write(out/'TRAINING_HANDOFF.json',dict(format_version=3,protocol='three_tasks_pid_v1',ready_for_training=ready,collection_only=True,task_order=a.tasks,features=FEATURES,scales=SCALES.tolist(),encoding='tracking_error_v1',target='y_force_N',target_scale_N=650.,raw_extra_signals=['hand_x_m','hand_y_m','hand_z_m','human_muscle_torque_Nm'],suggested_network='MLP; identical inputs/topology/training budgets in both branches',evaluation_matrix={'after_task1':['T1_90'],'after_task2':['T1_90','T2_60'],'after_task3':['T1_90','T2_60','T3_30']},test_access='Use validation during protocol/epoch/lambda selection. Freeze all selected checkpoints before final test access. Test stored checkpoints on exactly the same held-out references, without updates.',EWC_note='Three-task EWC must consolidate importance after Tasks 1 and 2; a penalty protecting only Task 1 does not protect Task 2.',compatibility='Earlier two-task 90/60 or 90/30 trainers require an explicit update. Task IDs are metadata, not automatically additional NN inputs.'))
 status='complete' if ready else 'complete_with_rejections';write(out/'COLLECTION_STATUS.json',dict(status=status,ready_for_training=ready,full_episodes=len(records),accepted=sum(r['accepted'] for r in records)))
 from task_report import build_report
 PROGRESS.stage('report');build_report(out)
 if backup is not None:PROGRESS.stage('github_backup');backup.sync(ROOT,final_status=status)
 PROGRESS.stage(status);print('THREE-TASK COLLECTION FINISHED | ready_for_training:',ready,'| report:',out/'COLLECTION_OVERLEAF.zip',flush=True)
 if not ready:print('Do not train yet: one or more full episodes failed teacher quality checks. All attempts are preserved.',flush=True)
 return 0 if ready else 2

if __name__=='__main__':
 try:raise SystemExit(main())
 except KeyboardInterrupt:
  if PROGRESS is not None:PROGRESS.stage('interrupted')
  print('Interrupted. Keep source/data; resume with the same settings plus --resume.',flush=True);raise SystemExit(130)
 except Exception as exc:
  if PROGRESS is not None:PROGRESS.stage('failed')
  print('COLLECTION STOPPED:',exc,flush=True);raise
