"""Predeclared three-task protocol, split before any neural training."""
import hashlib,itertools
from complex_trajectories import make_profile,configure,reference_digest,speed_statistics,FEATURES
TASKS={
 'T1_90':dict(order=1,name='Slow fixed-shoulder reaches',strength_scale=.9,requested_speed=.85),
 'T2_60':dict(order=2,name='Coordinated shoulder-elbow reaches',strength_scale=.6,requested_speed=1.15),
 'T3_30':dict(order=3,name='Fast irregular coupled reaches',strength_scale=.3,requested_speed=1.5)}

def seed_for(seed,key):return int(hashlib.sha256((str(seed)+'/'+key).encode()).hexdigest()[:8],16)

def conditions(args):
 return [dict(task_id=tid,variant=variant,start_deg=start,key=f'{tid}_{variant}_e{start:g}'.replace('.','p')) for tid,variant,start in itertools.product(args.tasks,args.variants,args.initial_angles)]

def pilot_recoveries(args):return sorted(set([(min(args.initial_errors),min(args.initial_velocities)),(max(args.initial_errors),max(args.initial_velocities))]))

def make_episode(args,condition,split,rep,factor=1.,pilot=False,recovery=None):
 tid=condition['task_id'];task=TASKS[tid];variant=condition['variant'];start=condition['start_deg'];key=condition['key'];mid=f'{key}_{split}_{rep:02d}';seed=seed_for(args.seed,mid)
 if recovery is None:
  k=rep if split=='train' else seed_for(args.seed,key+'/'+split+'/recovery')+rep
  recovery=(args.initial_errors[k%len(args.initial_errors)],args.initial_velocities[(k+k//len(args.initial_errors))%len(args.initial_velocities)])
 family='baseline_smooth' if tid=='T1_90' else 'variable_speed' if tid=='T2_60' else 'multisine' if variant=='A' else 'chirp'
 mode='fixed' if tid=='T1_90' else 'moving';profile=make_profile(family,seed,start,mode,pilot=pilot)
 profile['shoulder_start_deg']=(-5. if variant=='A' else 10.) if tid=='T1_90' else 2.5
 if tid=='T2_60':profile['shoulder_elbow_gain']=.2 if variant=='A' else -.2
 if tid=='T3_30':profile.update(shoulder_pattern='mixed_waves',shoulder_amplitude_deg=15. if pilot else 12.)
 cfg=dict(format_version=3,task_id=tid,task_name=task['name'],task_order=task['order'],episode_id=mid,motion_id=mid,condition=key,split=split,trajectory=family,variant=variant,mass_kg=args.mass_kg,strength_scale=task['strength_scale'],profile=profile,start_hold_s=1.,end_hold_s=1.,dt_s=args.dt,initial_offset_deg=float(recovery[0]),initial_velocity_deg_s=float(recovery[1]),muscle_excitation=args.muscle_excitation,force_cap_N=650.,accel_kp=120.,accel_kd=22.,accel_ki=15.,integral_limit_rad_s=.15,integrator_accuracy=1e-5,accept_rmse_deg=args.rmse_limit,accept_max_error_deg=args.max_error_limit,live_viewer=False,save_plots=True,requested_speed_scale=task['requested_speed'])
 configure(cfg,task['requested_speed']*factor);cfg['reference_sha256']=reference_digest(cfg)
 return cfg

def full_plan(args):
 return [make_episode(args,c,split,rep) for c in conditions(args) for split,n in [('train',args.train_reps),('validation',args.validation_reps),('test',args.test_reps)] for rep in range(n)]

def counts(plan):
 return {tid:{split:sum(c['task_id']==tid and c['split']==split for c in plan) for split in ('train','validation','test')} for tid in TASKS if any(c['task_id']==tid for c in plan)}
