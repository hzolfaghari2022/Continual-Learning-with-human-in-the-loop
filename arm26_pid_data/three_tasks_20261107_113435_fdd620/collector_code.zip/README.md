# Arm26 three-task PID data collector

This is an independent backup collection. Keep your currently running collector
and its source/results unchanged. Extract this package into a NEW folder.

In VS Code, open the folder that directly contains collect_three_tasks.py, select
the Python interpreter from lstm-py312, then use Run Python File or:

    conda activate lstm-py312
    python .\collect_three_tasks.py

No BAT file is required. Python imports resolve relative to the script folder.
No live OpenSim or plot windows open. Terminal progress prints every five seconds.

## Three predeclared tasks

| Task | Muscle strength | Motion | Requested speed |
| --- | ---: | --- | ---: |
| T1_90 | 90% | Smooth elbow motion, two fixed shoulder postures | 0.85x |
| T2_60 | 60% | Variable-speed reversals, positive/negative shoulder-elbow coordination | 1.15x |
| T3_30 | 30% | Multisine/chirp elbow motion, mixed-frequency moving shoulder | 1.5x |

Muscle excitation is 0.10 in all tasks, versus 0.02 in the previous collection.
This is a declared simulated experimental setting, not a clinical calibration.
It passed reduced real OpenSim checks; the full plan still performs independent
PID feasibility checks on your computer. Dumbbell mass is 5 kg. Every episode
starts from a fresh original model and scales all six maximum isometric muscle
forces by 0.9, 0.6 or 0.3, with a saved muscle-by-muscle audit.

Arm26 operates in a movement plane. The shoulder is prescribed externally;
one cable actuator exo_flexor controls elbow assistance (0..650 N). The new hand
paths are genuine simulated paths within this plane, not unrestricted lateral
3D reaching or two independently controlled exosuits.

Task 2 prescribes shoulder angle as shoulder_start + gain*(elbow_reference-start),
with gains +0.2 and -0.2 and consistent derivatives. Task 3 prescribes a windowed
mixture of shoulder sinusoids, timed differently from elbow reversals. Hand X/Y/Z
positions are logged at every sample. The report shows actual validation hand
paths, alongside the joint references and measured PID tracking.

## Workload and independent splits

240 full episodes total, keeping the reduced collection budget:

| Task | Training | Validation | Final test | Total |
| --- | ---: | ---: | ---: | ---: |
| T1_90 | 56 | 8 | 16 | 80 |
| T2_60 | 56 | 8 | 16 | 80 |
| T3_30 | 56 | 8 | 16 | 80 |

Each task has 4 initial elbow reference angles (20, 35, 50, 70 deg), 2 variants,
and 7/1/2 independently seeded repetitions per condition. Whole episodes are
assigned before collection; no time windows cross splits. A fresh seed separates
this collection from previous datasets. Initial offsets -0.5, 0, +0.5 deg and
velocities -5, 0, +5 deg/s provide recovery behavior.

Pilots are EXTRA and excluded from all training/validation/test manifests.
24 task conditions x 2 extreme recovery cases = 48 minimum pilot episodes.
Predeclared speed slowdown factors are 1.0, 0.8 and 0.64: at most 144 pilots.
An uninterrupted feasible full run therefore attempts 288..384 total episodes.
Actual selected speeds and peak reference demands are saved. PID speed selection
uses independent pilots only, never neural errors or final test outcomes.
A condition that cannot pass any declared speed stops before full collection.

The teacher is model-based acceleration compensation plus PID feedback. It checks
PID motion RMSE <=0.1 deg, full-run maximum error <=1.1 deg, force bounds, numerical
states, positive cable acceleration gain and joint envelopes. All partial or failed
attempts are retained. If ANY full episode fails acceptance, ready_for_training is
false; the split is not silently repaired by moving test episodes into training.

To run only pilots first:

    python .\collect_three_tasks.py --pilot-only

Then continue that same run into the full collection, retaining the same settings:

    python .\collect_three_tasks.py --resume

## Saved files and reports

C:\Users\hzlfghri\Arm26_Three_Task_PID_Data\three_tasks_<timestamp>_<id>\

- tasks\T1_90\strength_90, tasks\T2_60\strength_60, tasks\T3_30\strength_30:
  separate episode folders, settings, arrays, full signals/states, model XML,
  strength audit and tracking PNG/PDF.
- pilot: independent feasibility attempts and calibration history.
- DATASET_MANIFEST.json: all attempts, task labels, split, hashes, acceptance.
- T1_90.json / T2_60.json / T3_30.json: accepted per-task records.
- TRAINING_HANDOFF.json: exact input/target contract and future retention protocol.
- WORKLOAD.json, DATA_COUNTS.json, PID_DATA_QUALITY.csv, COLLECTION_STATUS.json.
- PROGRESS.json / PROGRESS.html: completed/total counts, elapsed time, current
  episode progress, measured ETA and estimated finish. Report/Git time is extra.
- COLLECTION_OVERLEAF.zip: upload into Overleaf and compile main.tex.
- COLLECTION_REPORT.html: immediately viewable saved report.
- COLLECTION_REPORT.pdf: produced when local pdflatex is available.

CSV, binary arrays, state playback files and tracking plots are published as
complete payloads with bounded retries for temporary Windows sharing locks.
Interrupted streaming records remain under *.partial.csv. Final CSV sample counts,
timestamps and force targets are checked against binary arrays before acceptance.
Progress-display file errors are nonfatal. Critical data integrity errors stop.

The full raw network input contract remains 24 observations:
elbow angle/velocity; elbow reference position/velocity/acceleration; load;
actual shoulder angle; previous applied cable tension; error integral;
6 muscle activations; 6 normalized fiber lengths; strength ratio;
actual shoulder velocity/acceleration. Input 3 is encoded as angle error/0.02 rad
and input 4 as velocity error/0.2 rad/s; other physical scales are documented.
The target is cable tension in N. Extra CSV signals include human muscle torque,
cable torque, reference derivatives, saturation and hand position. Internal muscle
states are available in simulation; physical deployment needs sensing/estimation.

## Future MLP/EWC experiment

This package DOES NOT train a network and cannot guarantee a large no-CL error or
near-zero EWC error. It collects accurate, unmodified PID demonstrations.

The future trainer should learn T1 -> T2 -> T3 in two identical MLP branches,
starting from the same learned Task-1 weights. One branch uses ordinary imitation;
the other uses EWC. Consolidate EWC importance after Tasks 1 AND 2 to protect both.
Use validation for epochs/lambda selection, then freeze all selected checkpoints
before opening final test arrays. Evaluate the stored checkpoints on the SAME
held-out references, without any updates, and reset each physical initial state.
Report newest-task learning as well as old-task retention, failures and seed
variation. Test order does not create forgetting; prior training may create it.

The earlier 90/60 or 90/30 TWO-TASK training packages require an explicit update.
Do not relabel task data to force compatibility. Task IDs are metadata and are
not silently additional NN inputs. If a strength-unobserved input variant is
chosen later, apply the same contract to both branches before final testing.

## GitHub while another collector is running

Configured repository:
https://github.com/hzolfaghari2022/Continual-Learning-with-human-in-the-loop.git

Default branch: arm26-three-task-data (created on the first successful backup).
Choose this branch in GitHub to see the new data. Your current collector can
continue backing up main. This avoids making its older push logic compete with
the new collector on the same branch. Existing repository content is preserved.
The new collector uses a separate per-run cache below Arm26_ThreeTask_Git_Cache.

Uploads occur before physics, periodically, and after report generation. Archives
retain all saved samples and are chunked below GitHub's file limit. The pushed
commit and committed backup manifest are verified. No force push or embedded
credentials is used. Authentication/commit identity must already work on your PC.
Your actual repository is updated when YOU run the collector, not during our QA.

Git failure leaves all local data intact. Retry without repeating physics:

    python .\collect_three_tasks.py --backup-only

--no-github is an explicit opt-out. --github-branch changes the destination, but
using the default branch is recommended while your older collector is running.
Both simulations share CPU and network resources, so each may run more slowly.
CUDA does not accelerate this OpenSim PID collection.

## Resume, preview and report-only

    python .\collect_three_tasks.py --resume
    python .\collect_three_tasks.py --plan-only
    python .\collect_three_tasks.py --report-only

Use the SAME source/settings to resume. Completed episodes are integrity-checked
and reused; interrupted attempts are archived and repeated. Specify --run-folder
"C:\path\to\three_tasks_..." when targeting a particular run. Run pointers are
local to this package and do not modify the currently running collector.

Dependencies: your existing lstm-py312 environment with OpenSim 4.6, NumPy,
Matplotlib and Git authentication. No PyTorch installation is needed for collection.
