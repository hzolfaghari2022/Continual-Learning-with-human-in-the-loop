"""Seeded C2 elbow/shoulder references. Parameters never depend on NN error."""
import hashlib,json,math
import numpy as np
FAMILIES=['baseline_smooth','variable_speed','multisine','chirp']
LEGACY_FEATURES=['angle_rad','velocity_rad_s','reference_rad','reference_velocity_rad_s','reference_acceleration_rad_s2','mass_kg','shoulder_angle_rad','previous_tension_N','error_integral_rad_s']
MUSCLES=['TRIlong','TRIlat','TRImed','BIClong','BICshort','BRA']
LEGACY_FEATURES += [m+'_activation' for m in MUSCLES]+[m+'_normalized_fiber_length' for m in MUSCLES]+['strength_scale']
FEATURES=LEGACY_FEATURES+['shoulder_velocity_rad_s','shoulder_acceleration_rad_s2']
SCALES=np.array([1.,2.,1.,2.,10.,20.,1.,650.,.1]+[1.]*13+[2.,10.],dtype=np.float32)


def encode(x):
    x=np.asarray(x,dtype=np.float32);z=x/SCALES[:x.shape[-1]]
    z=np.array(z,copy=True);z[...,2]=(x[...,2]-x[...,0])/.02;z[...,3]=(x[...,3]-x[...,1])/.2
    return z


def smooth(u):
    if u<=0:return 0.,0.,0.
    if u>=1:return 1.,0.,0.
    return 10*u**3-15*u**4+6*u**5,30*u*u-60*u**3+30*u**4,60*u-180*u*u+120*u**3


def window(t,D,ramp):
    if t<ramp:
        a,b,c=smooth(t/ramp);return a,b/ramp,c/ramp**2
    if t>D-ramp:
        a,b,c=smooth((D-t)/ramp);return a,-b/ramp,c/ramp**2
    return 1.,0.,0.


def make_profile(family,seed,start_deg,shoulder_mode,pilot=False):
    rng=np.random.default_rng(seed)
    sh0=float(rng.choice([-5.,15.,35.]));tempo=1.12 if pilot else float(rng.uniform(.85,1.10))
    p=dict(family=family,seed=int(seed),start_deg=float(start_deg),tempo=tempo,shoulder_mode=shoulder_mode,shoulder_start_deg=sh0,
           shoulder_amplitude_deg=15. if pilot else float(rng.uniform(8.,14.)),shoulder_cycles=float(rng.uniform(1.,2.2)),shoulder_phase=float(rng.uniform(-math.pi,math.pi)))
    if family=='baseline_smooth':
        p.update(duration=12.,knots=[0.,4.,8.,12.],angles=[float(start_deg),float(rng.uniform(72,80)),float(rng.uniform(22,30)),float(start_deg)])
    elif family=='variable_speed':
        d=np.array([2.8,1.4,2.6,1.6,2.4,3.2]);d*=float(rng.uniform(.96,1.04));knots=np.r_[0,np.cumsum(d)]
        p.update(duration=float(knots[-1]),knots=knots.tolist(),angles=[float(start_deg),float(rng.uniform(92,101)),float(rng.uniform(26,34)),float(rng.uniform(106,114)),float(rng.uniform(15,23)),float(rng.uniform(72,82)),float(start_deg)])
    elif family=='multisine':
        p.update(duration=16.,center=float(rng.uniform(57,63)),amplitudes=[18.,9.,5.],cycles=[2.,5.,9.],phases=rng.uniform(-math.pi,math.pi,3).tolist())
    elif family=='chirp':
        p.update(duration=18.,center=float(rng.uniform(57,63)),amplitude=22.,f0=.08,f1=.55 if pilot else float(rng.uniform(.45,.53)),phase=float(rng.uniform(-math.pi,math.pi)))
    else:raise ValueError('Unknown reference family.')
    return p


def wave(profile,t):
    D=profile['duration'];t=float(np.clip(t,0,D));q0=profile['start_deg']
    if profile['family'] in ['baseline_smooth','variable_speed']:
        knots=profile['knots'];angles=profile['angles'];i=min(len(knots)-2,max(0,int(np.searchsorted(knots,t,side='right'))-1));T=knots[i+1]-knots[i];u=(t-knots[i])/T;a,b,c=smooth(u);delta=angles[i+1]-angles[i]
        return angles[i]+delta*a,delta*b/T,delta*c/T**2
    w,dw,ddw=window(t,D,2.5);base=profile['center']-q0
    if profile['family']=='multisine':
        y=dy=ddy=0.
        for A,n,phase in zip(profile['amplitudes'],profile['cycles'],profile['phases']):
            omega=2*math.pi*n/D;a=omega*t+phase;y+=A*math.sin(a);dy+=A*omega*math.cos(a);ddy-=A*omega**2*math.sin(a)
    else:
        A=profile['amplitude'];k=(profile['f1']-profile['f0'])/D;phase=2*math.pi*(profile['f0']*t+.5*k*t*t)+profile['phase'];v=2*math.pi*(profile['f0']+k*t)
        y=A*math.sin(phase);dy=A*math.cos(phase)*v;ddy=A*(-math.sin(phase)*v*v+math.cos(phase)*2*math.pi*k)
    return q0+w*(base+y),dw*(base+y)+w*dy,ddw*(base+y)+2*dw*dy+w*ddy


def configure(cfg,speed_scale=1.):
    p=cfg['profile'];cfg['speed_scale']=float(speed_scale);cfg['time_scale']=1/(p['tempo']*speed_scale);cfg['motion_duration_s']=p['duration']*cfg['time_scale'];cfg['duration_s']=cfg['start_hold_s']+cfg['motion_duration_s']+cfg['end_hold_s'];return cfg


def reference(t,cfg):
    elapsed=t-cfg['start_hold_s'];p=cfg['profile'];s=cfg['time_scale'];x=elapsed/s
    if elapsed<0 or x>p['duration']:return math.radians(p['start_deg']),0.,0.,False
    q,v,a=wave(p,x);return math.radians(q),math.radians(v)/s,math.radians(a)/s**2,True


def shoulder_reference(t,cfg):
    p=cfg['profile'];q0=p['shoulder_start_deg']
    if p['shoulder_mode']=='fixed':return math.radians(q0),0.,0.
    x=(t-cfg['start_hold_s'])/cfg['time_scale'];D=p['duration']
    if x<0 or x>D:return math.radians(q0),0.,0.
    w,dw,ddw=window(x,D,2.5);A=p['shoulder_amplitude_deg'];omega=2*math.pi*p['shoulder_cycles']/D;phase=omega*x+p['shoulder_phase'];y=A*math.sin(phase);dy=A*omega*math.cos(phase);ddy=-A*omega**2*math.sin(phase);s=cfg['time_scale']
    return math.radians(q0+w*y),math.radians(dw*y+w*dy)/s,math.radians(ddw*y+2*dw*dy+w*ddy)/s**2


def reference_digest(cfg):
    keys=['profile','time_scale','start_hold_s','end_hold_s','duration_s']
    return hashlib.sha256(json.dumps({k:cfg[k] for k in keys},sort_keys=True).encode()).hexdigest()


def speed_statistics(cfg):
    # Reference-only grid; records requested vs pilot-selected demands honestly.
    ts=np.linspace(0,cfg['duration_s'],max(1000,int(cfg['duration_s']/.005)+1))
    elbow=np.degrees(np.array([reference(t,cfg)[:3] for t in ts]))
    shoulder=np.degrees(np.array([shoulder_reference(t,cfg) for t in ts]))
    return dict(peak_elbow_speed_deg_s=float(np.max(abs(elbow[:,1]))),peak_elbow_acceleration_deg_s2=float(np.max(abs(elbow[:,2]))),peak_shoulder_speed_deg_s=float(np.max(abs(shoulder[:,1]))),selected_speed_scale=cfg['speed_scale'],requested_speed_scale=cfg.get('requested_speed_scale',cfg['speed_scale']))

def episode_title(cfg):
    controller='Frozen neural controller' if cfg.get('neural_checkpoint') else 'PID data collection'
    speed=cfg.get('speed_scale',1.);requested=cfg.get('requested_speed_scale',speed)
    return (f"{controller} | muscle strength {100*cfg['strength_scale']:g}% | {cfg['split'].upper()} | {cfg.get('progress_label','')}\n"
            f"{cfg['trajectory'].replace('_',' ').title()} | elbow start {cfg['profile']['start_deg']:g} deg | {cfg['profile']['shoulder_mode']} shoulder | load {cfg['mass_kg']:g} kg\n"
            f"Speed requested {requested:g}x; selected {speed:g}x | initial offset {cfg.get('initial_offset_deg',0):+g} deg; velocity {cfg.get('initial_velocity_deg_s',0):+g} deg/s")
