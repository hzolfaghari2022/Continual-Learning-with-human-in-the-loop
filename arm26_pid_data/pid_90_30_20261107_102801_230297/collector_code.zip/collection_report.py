"""Reference previews and a PID-only data-quality Overleaf report."""
import csv,html,shutil,subprocess,zipfile,io
from pathlib import Path
import numpy as np
from complex_trajectories import FAMILIES,FEATURES,reference,shoulder_reference
from complex_engine import read,write


def escape(text):
    return str(text).replace('\\',r'\textbackslash{}').replace('_',r'\_').replace('%',r'\%').replace('&',r'\&').replace('#',r'\#')


def finish(fig,folder,name):
    folder=Path(folder);folder.mkdir(parents=True,exist_ok=True);fig.tight_layout()
    for extension in ('pdf','png'):
        buffer=io.BytesIO();fig.savefig(buffer,format=extension,dpi=180,bbox_inches='tight');(folder/(name+'.'+extension)).write_bytes(buffer.getvalue())
    import matplotlib.pyplot as plt
    plt.close(fig)


def preview(out,plan):
    import matplotlib;matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    plt.rcParams.update({'font.family':'serif','font.size':11})
    families=[f for f in FAMILIES if any(c['trajectory']==f for c in plan)];fig,axs=plt.subplots(len(families),2,figsize=(11,2.5*len(families)),squeeze=False);fig2,bxs=plt.subplots(len(families),2,figsize=(11,2.5*len(families)),squeeze=False)
    for i,family in enumerate(families):
        options=[c for c in plan if c['trajectory']==family];cfg=next((c for c in options if c['profile']['shoulder_mode']=='moving'),options[0]);t=np.linspace(0,cfg['duration_s'],1500);ref=np.array([reference(x,cfg)[:3] for x in t]);shoulder=np.array([shoulder_reference(x,cfg) for x in t]);q,v,a=np.degrees(ref).T
        axs[i,0].plot(t,q,color='#0072B2',lw=2);axs[i,1].plot(t,np.degrees(shoulder[:,0]),color='#009E73',lw=2);axs[i,0].set_ylabel(family.replace('_',' ')+'\nElbow (deg)');axs[i,1].set_ylabel('Shoulder (deg)')
        bxs[i,0].plot(t,v,color='#D55E00',lw=1.6);bxs[i,1].plot(t,a,color='#CC79A7',lw=1.6);bxs[i,0].set_ylabel(family.replace('_',' ')+'\nElbow speed (deg/s)');bxs[i,1].set_ylabel('Elbow accel. (deg/s²)')
        for ax in [*axs[i],*bxs[i]]:ax.grid(alpha=.2);ax.set_xlabel('Time (s)')
    axs[0,0].set_title('Elbow reference: independent motion families');axs[0,1].set_title('Externally prescribed shoulder motion');bxs[0,0].set_title('Nonuniform reference speeds');bxs[0,1].set_title('Smooth finite accelerations')
    folder=Path(out)/'collection_overleaf/figures';finish(fig,folder,'reference_preview');finish(fig2,folder,'kinematics_preview')


def build_report(out):
    out=Path(out).resolve();project=out/'collection_overleaf';figs=project/'figures';figs.mkdir(parents=True,exist_ok=True)
    plan=read(out/'FROZEN_PLAN.json') if (out/'FROZEN_PLAN.json').exists() else read(out/'UNSCALED_PLAN.json');preview(out,plan)
    data=read(out/'DATASET_MANIFEST.json') if (out/'DATASET_MANIFEST.json').exists() else {};records=data.get('records',[])
    with (out/'PID_DATA_QUALITY.csv').open('w',newline='') as f:
        fields=['episode_id','strength_scale','initial_reference_deg','initial_offset_deg','initial_velocity_deg_s','shoulder_mode','shoulder_start_deg','split','trajectory','regime','status','samples','requested_speed_scale','selected_speed_scale','peak_reference_speed_deg_s','motion_rmse_deg','individual_pid_accepted','paired_accepted'];w=csv.DictWriter(f,fieldnames=fields,extrasaction='ignore');w.writeheader();w.writerows(records)
    body=r'''\documentclass[11pt,a4paper]{article}
\usepackage[margin=18mm]{geometry}\usepackage{graphicx,booktabs,amsmath,hyperref}
\setlength{\parindent}{0pt}\setlength{\parskip}{6pt}\begin{document}
\begin{center}{\LARGE\bfseries Arm26 complex-motion PID data}\end{center}
This report describes data generation and PID teacher quality. It does not claim a neural-network or continual-learning benefit.
\section*{What changed?}
The elbow follows variable-speed quintic waypoints, a windowed multisine, or a frequency-swept chirp. Initial elbow angles and shoulder posture vary. In moving-shoulder episodes, the shoulder is prescribed externally as a smooth time function; the cable controller tracks the elbow, not the shoulder. The same motion is evaluated with 90\% and 30\% maximum isometric muscle force. Default initial reference angles are 20, 45 and 70 degrees. Small independently declared initial tracking errors and velocities provide recovery examples; both strengths share the same perturbations. Fixed human muscle excitation is 0.02; the unilateral flexor cable is limited to 0--650 N.
\section*{Keep these two questions separate}
\begin{tabular}{p{.30\linewidth}p{.62\linewidth}}\toprule
Test & What it establishes \\ \midrule
Frozen NN90 on new complex motion & Generalization to an unfamiliar trajectory, not forgetting. \\
NN90 learns A90, adapts on B30, then returns to A90 with frozen adapted weights & Retention after adaptation; compare identical tests with and without CL. \\ \bottomrule\end{tabular}\par
The initial NN90 must first demonstrate the original A skill. Making that initial test fail does not demonstrate loss of an already learned skill. Increased difficulty may affect both methods; trajectories are generated independently of NN errors, and no CL advantage is guaranteed.
\section*{Dataset role files}
\texttt{TASK\_A\_90.json}: fixed-shoulder baseline and variable-speed motions, old-skill candidate.\\
\texttt{TASK\_B\_30.json}: complex motions and/or moving shoulder, new skill.\\
\texttt{DIAGNOSTIC\_COMPLEX\_90.json}: same new motions at 90\%, for a generalization diagnostic.\\
\texttt{CONTROL\_A\_30.json}: old motions at 30\%, for isolating the strength effect.
Pilot seeds are separate from training, validation and test seeds. The fastest predeclared pilot speed passing the PID quality gate at every requested strength is frozen before full data collection. Failed attempts are retained. Final paired training records require PID acceptance at every requested strength, without considering NN errors.
'''
    body+=r'\par '+escape(f'Full-record attempts so far: {len(records)}; paired accepted: {sum(r["paired_accepted"] for r in records)}. Dataset complete: {data.get("complete",False)}; all condition/split coverage: {data.get("all_condition_split_coverage",False)}.')
    actual=read(out/'COLLECTION.json')['config']
    body+=r'\par The default full plan has 240 episodes: 120 per strength, with 84 training, 12 validation and 24 test episodes at each strength. Independent pilots are extra (48 minimum, 144 maximum). All raw data are unmodified physics outputs; no neural errors are imposed.'
    body+=r'\subsection*{Actual configured inputs}\begin{tabular}{ll}'
    for label,key in [('Requested speed levels','speed_levels'),('Strengths (percent)','strengths'),('Initial elbow references (deg)','initial_angles'),('Initial tracking offsets (deg)','initial_errors'),('Initial velocities (deg/s)','initial_velocities'),('Fixed shoulder pose choices (deg)','shoulder_poses'),('Moving shoulder centers (deg)','moving_shoulder_poses')]:
        body+=escape(label)+' & '+escape(', '.join(map(str,actual.get(key,[]))))+r' \\'+'\n'
    body+=r'\end{tabular}'
    for name,title in [('reference_preview','Reference trajectories'),('kinematics_preview','Velocity and acceleration demands')]:body+=r'\clearpage\section*{'+title+r'}\includegraphics[width=\linewidth]{figures/'+name+r'.pdf}\par These are reference previews, not measured tracking curves. The first available moving-shoulder case per family is shown; no cases were selected by NN failure.'
    if plan and 'speed_statistics' in plan[0]:
        with (out/'SPEED_DEMANDS.csv').open('w',newline='') as f:
            fields=['motion_id','condition','split','requested_speed_scale','selected_speed_scale','peak_elbow_speed_deg_s','peak_elbow_acceleration_deg_s2','peak_shoulder_speed_deg_s'];w=csv.DictWriter(f,fieldnames=fields,extrasaction='ignore');w.writeheader()
            for cfg in plan:w.writerow(dict(motion_id=cfg['motion_id'],condition=cfg['condition'],split=cfg['split'],**cfg['speed_statistics']))
        import matplotlib.pyplot as plt
        fig,axes=plt.subplots(1,2,figsize=(11,4))
        for level in sorted(set(c.get('requested_speed_scale',1.) for c in plan)):
            group=[c for c in plan if c.get('requested_speed_scale',1.)==level]
            for ax,key,title in [(axes[0],'peak_elbow_speed_deg_s','Elbow reference peak velocity'),(axes[1],'peak_elbow_acceleration_deg_s2','Elbow reference peak acceleration')]:
                vals=[c['speed_statistics'][key] for c in group];ax.hist(vals,bins=12,alpha=.65,label=f'Requested {level:g}x');ax.set_title(title);ax.set_ylabel('Number of reference episodes');ax.grid(alpha=.2);ax.legend()
        axes[0].set_xlabel('Peak speed (deg/s)');axes[1].set_xlabel('Peak acceleration (deg/s²)');finish(fig,figs,'speed_demands')
        body+=r'\clearpage\section*{Requested and feasible speeds}\includegraphics[width=\linewidth]{figures/speed_demands.pdf}\par The baseline smooth family uses the lower requested speed; the other families use the higher speed. The fixed 12-condition plan is declared before neural training. These distributions show the actual frozen reference demands after pilot calibration; they are not measured tracking errors. Any pilot slowdown is recorded in SPEED\_DEMANDS.csv and the frozen plan. More demanding references do not guarantee a neural-network failure or a continual-learning benefit.'
    samples=[r for r in records if r['paired_accepted'] and r['strength_scale']==.3 and r['split']=='validation']
    sample=next((r for r in samples if r['trajectory']=='chirp' and read(Path(r['folder'])/'settings.json')['profile']['shoulder_mode']=='moving'),samples[0] if samples else None)
    if sample and (Path(sample['folder'])/'tracking.pdf').exists():
        shutil.copy2(Path(sample['folder'])/'tracking.pdf',figs/'pid_tracking_example.pdf');shutil.copy2(Path(sample['folder'])/'tracking.png',figs/'pid_tracking_example.png')
        body+=r'\clearpage\section*{Actual PID tracking example}\includegraphics[width=.94\linewidth]{figures/pid_tracking_example.pdf}\par '+escape('Measured PID validation episode: '+sample['episode_id']+f'. Motion RMSE: {sample["motion_rmse_deg"]:.6g} deg. The shoulder trace comes from actual OpenSim states under a prescribed external driver. This is teacher quality, not a neural or CL result.')
    if (out/'PILOT_FORCE_CONTRAST.json').exists():
        contrast=read(out/'PILOT_FORCE_CONTRAST.json')
        body+=r'\clearpage\section*{Independent pilot strength contrast}'
        if (figs/'pilot_strength_contrast.pdf').exists():body+=r'\includegraphics[width=\linewidth]{figures/pilot_strength_contrast.pdf}\par '
        body+=escape(contrast['note'])+r'\par Average paired pilot force-RMSE difference (N): '+escape(format(contrast['mean_force_gap_rmse_N'],'.6g'))+r'. This quantity is the difference between two accurate PID force commands, not a neural tracking error or evidence of forgetting.'
        body+=r'\par A 10-degree sinusoidal amplitude and a 5-degree peak error would correspond to a 50-percent peak-error ratio, but are not the same as RMSE. No such value, or near-zero EWC error, is specified by this collector.'
    body+=r'''\clearpage\section*{Teacher controller and feasibility}
At the current physical state, OpenSim is evaluated at 0 and 1 N cable tension:
\[
a_0=\ddot q(F=0),\quad b=\ddot q(F=1\,\mathrm N)-a_0,
\]
\[
a^*=\ddot q_{\rm ref}+K_p(q_{\rm ref}-q)+K_d(\dot q_{\rm ref}-\dot q)+K_i I,
\quad F=\operatorname{clip}_{[0,650]}[(a^*-a_0)/b].
\]
The model supplies gravity, muscle and shoulder-coupling compensation through $a_0$ and $b$; the feedback term is PID in acceleration coordinates. $q$ is elbow angle in radians; $I=\int(q_{\rm ref}-q)dt$ is clipped to $\pm0.15$ rad s with saturation anti-windup. $K_p=120$ s$^{-2}$, $K_d=22$ s$^{-1}$ and $K_i=15$ s$^{-3}$. $b$ has units rad s$^{-2}$/N. These gains and the 650 N limit are fixed across the paired strengths. The affine response is checked using 2 N at the initial state. A positive cable gain and an elbow envelope of 3--123 degrees are enforced.
\par A completed PID episode is accepted only with motion RMSE $\le0.1$ deg and full-run maximum absolute error $\le1.1$ deg by default. The actual configured thresholds appear in each settings file. Force saturation, partial traces and failures are logged; a neural failure is never repaired by a hidden PID fallback.
\section*{Data and controller inputs}
\texttt{training\_arrays.npz} stores 24 features, PID force targets in N and time. \texttt{legacy22\_arrays.npz} stores the first 22 features for a documented legacy diagnostic. The two extra features are actual shoulder velocity and acceleration. Actual shoulder angle is logged, rather than a fixed pose label.
\par Initial recovery samples are retained in the training arrays; the full-run maximum-error gate includes the recovery transient. Initial-recovery metrics and a phase label are saved separately, while motion RMSE uses motion samples.\par The 24 inputs comprise elbow state; reference position, speed and acceleration; load; shoulder angle; previous tension; error integral; six activations; six normalized fiber lengths; strength scale; shoulder velocity and acceleration. Every sampled physical state and simulator state trajectory is retained. This is a new data/trajectory contract; the previous locked-shoulder trainer must not silently consume it.
\par Future MLP and EWC training is a separate step. The previous 90/60 trainer requires an explicit 90/30 update; do not relabel strength columns or load these files as 60-percent data. Use identical network inputs, topology and training schedules in both future comparison branches. Pilot cases are excluded from training, validation and test role files.
\end{document}'''
    (project/'main.tex').write_text(body)
    executable=shutil.which('pdflatex');compiled=False
    if executable:
        for _ in range(2):
            p=subprocess.run([executable,'-interaction=nonstopmode','-halt-on-error','main.tex'],cwd=project,capture_output=True,text=True)
            if p.returncode:break
        compiled=p.returncode==0
        if compiled:shutil.copy2(project/'main.pdf',out/'COLLECTION_REPORT.pdf')
    with zipfile.ZipFile(out/'COLLECTION_OVERLEAF.zip','w',zipfile.ZIP_DEFLATED) as z:
        for file in sorted(project.rglob('*')):
            if file.is_file() and file.suffix in ['.tex','.pdf','.png']:z.write(file,file.relative_to(project))
        z.write(out/'PID_DATA_QUALITY.csv','PID_DATA_QUALITY.csv')
        if (out/'SPEED_DEMANDS.csv').exists():z.write(out/'SPEED_DEMANDS.csv','SPEED_DEMANDS.csv')
        for name in ('PILOT_FORCE_CONTRAST.json','PILOT_FORCE_CONTRAST.csv'):
            if (out/name).exists():z.write(out/name,name)
    text='<html><meta charset="utf-8"><body style="max-width:1050px;margin:auto;font:18px system-ui"><h1>Complex PID collection</h1><p>PID teacher quality and reference previews; no CL benefit is claimed.</p>'
    for file in figs.glob('*.png'):text+='<h2>'+html.escape(file.stem)+'</h2><img width="100%" src="collection_overleaf/figures/'+file.name+'">'
    (out/'COLLECTION_REPORT.html').write_text(text+'</body></html>')
    write(out/'REPORT_STATUS.json',dict(local_pdf_compiled=compiled,overleaf=str(out/'COLLECTION_OVERLEAF.zip'),note='Upload ZIP and compile main.tex. See collection_overleaf/main.log if a local LaTeX build failed.'))
    print('COLLECTION REPORT:',out/'COLLECTION_OVERLEAF.zip',flush=True)
