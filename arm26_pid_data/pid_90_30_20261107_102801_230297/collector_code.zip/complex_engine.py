"""Real OpenSim forward dynamics: model-based PID teacher OR frozen NN, never both."""
import runtime_setup
import argparse,csv,hashlib,json,math,time,traceback,io
from pathlib import Path
import numpy as np
from complex_trajectories import episode_title,FEATURES,LEGACY_FEATURES,MUSCLES,SCALES,encode,reference,shoulder_reference
ROOT=Path(__file__).resolve().parent


def read(path):return json.loads(Path(path).read_text(encoding='utf-8-sig'))
from atomic_io import atomic_json as write, progress_json as write_progress,atomic_bytes
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def build(o,cfg):
    from add_dumbbell import add_dumbbell
    from strength_scaling import apply_strength
    o.ModelVisualizer.addDirToGeometrySearchPaths(str(ROOT/'Geometry'))
    m=o.Model(str(ROOT/'arm26_exosuit.osim'));add_dumbbell(o,m,cfg['mass_kg']);m.setGravity(o.Vec3(0,-9.80665,0))
    if [m.getCoordinateSet().get(i).getName() for i in range(2)]!=['r_shoulder_elev','r_elbow_flex']:raise ValueError('Unexpected coordinate order.')
    el=m.updCoordinateSet().get('r_elbow_flex');sh=m.updCoordinateSet().get('r_shoulder_elev');p=cfg['profile']
    el.setDefaultValue(math.radians(p['start_deg']+cfg.get('initial_offset_deg',0)));el.setDefaultSpeedValue(math.radians(cfg.get('initial_velocity_deg_s',0.)));el.setDefaultLocked(False)
    sh.setDefaultValue(math.radians(p['shoulder_start_deg']));sh.setDefaultSpeedValue(0)
    if p['shoulder_mode']=='moving':
        spline=o.SimmSpline()
        # The native C2 spline is the actual prescribed shoulder driver.
        for t in np.linspace(0,cfg['duration_s'],math.ceil(cfg['duration_s']/.01)+1):spline.addPoint(float(t),shoulder_reference(float(t),cfg)[0])
        sh.setPrescribedFunction(spline);sh.setDefaultLocked(False);sh.setDefaultIsPrescribed(True)
    else:sh.setDefaultLocked(True);sh.setDefaultIsPrescribed(False)
    cfg['muscle_strength_audit']=apply_strength(m,cfg['strength_scale']);mus=m.updMuscles()
    if [mus.get(i).getName() for i in range(mus.getSize())]!=MUSCLES:raise ValueError('Muscle order/schema differs.')
    ctrl=o.PrescribedController();ctrl.setName('fixed_human_muscle_excitation')
    for i in range(mus.getSize()):
        muscle=mus.get(i);o.Thelen2003Muscle.safeDownCast(muscle).setDefaultActivation(cfg['muscle_excitation']);ctrl.addActuator(muscle);ctrl.prescribeControlForActuator(muscle.getName(),o.Constant(cfg['muscle_excitation']))
    m.addController(ctrl);m.setUseVisualizer(False);state=m.initSystem();state.setTime(0);m.assemble(state);m.equilibrateMuscles(state)
    cable=o.PathActuator.safeDownCast(m.updForceSet().get('exo_flexor'));cable.overrideActuation(state,True);cable.setOverrideActuation(state,0)
    return m,state,el,sh,cable


def acceleration_response(model,state,elbow,cable,check=False):
    cable.setOverrideActuation(state,0.);model.realizeAcceleration(state);a0=float(elbow.getAccelerationValue(state))
    cable.setOverrideActuation(state,1.);model.realizeAcceleration(state);gain=float(elbow.getAccelerationValue(state))-a0
    if not math.isfinite(gain) or gain<=1e-7:raise RuntimeError('Nonpositive/invalid cable acceleration gain.')
    if check:
        cable.setOverrideActuation(state,2.);model.realizeAcceleration(state);a2=float(elbow.getAccelerationValue(state))
        if not np.isclose(a2,a0+2*gain,rtol=1e-6,atol=1e-7):raise RuntimeError('Cable-force/acceleration map is not affine at this state.')
    return a0,gain


def load_network(path):
    path=Path(path);weights=path if path.name.endswith('_inference.npz') else path.with_name(path.stem+'_inference.npz');meta=read(weights.with_suffix('.json'));features=meta['features']
    if features not in [LEGACY_FEATURES,FEATURES] or meta.get('encoding')!='tracking_error_v1' or meta['force_cap_N']!=650:raise ValueError('Need a documented 22- or 24-input tracking_error_v1, 650 N policy.')
    if not np.allclose(meta.get('scales',[]),SCALES[:len(features)]):raise ValueError('Policy input scales differ from the documented feature contract.')
    with np.load(weights,allow_pickle=False) as z:layers=[(z[f'W{i}'].copy(),z[f'b{i}'].copy()) for i in range(3)]
    if [x[0].shape for x in layers]!=[(64,len(features)),(64,64),(1,64)]:raise ValueError('Unsupported policy architecture.')
    def forward(raw):
        z=encode(np.asarray(raw,np.float32))
        for i,(w,b) in enumerate(layers):z=z@w.T+b;z=np.tanh(z) if i<2 else z
        return float(z.item())*650
    return forward,features,dict(weights=str(weights),weights_sha256=sha(weights),metadata_sha256=sha(weights.with_suffix('.json')),checkpoint_sha256=sha(path) if path.exists() else None,feature_count=len(features))


def summarize(rows,cfg):
    def calc(data):
        if not data:return None
        e=np.array([r['error_deg'] for r in data]);return dict(rmse_deg=float(np.sqrt(np.mean(e**2))),max_abs_error_deg=float(np.max(abs(e))),saturation_percent=100*float(np.mean([r['saturated'] for r in data])),peak_force_N=max(r['tension_N'] for r in data))
    return dict(all_samples=calc(rows),motion_only=calc([r for r in rows if r['moving']]),initial_recovery=calc([r for r in rows if r['time_s']<cfg['start_hold_s']]))


def plot_episode(folder,rows,cfg,status="completed"):
    if not rows:return
    import matplotlib;matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    plt.rcParams.update({'font.family':'serif','font.size':12})
    fig,axs=plt.subplots(4,1,figsize=(10,10),sharex=True);t=[r['time_s'] for r in rows]
    axs[0].plot(t,[r['reference_deg'] for r in rows],'k--',lw=2,label='Elbow reference');axs[0].plot(t,[r['angle_deg'] for r in rows],color='#0072B2',label='Actual elbow');axs[0].set_ylabel('Elbow (deg)')
    axs[1].plot(t,[r['error_deg'] for r in rows],color='#D55E00');axs[1].axhline(0,color='grey',lw=.8);axs[1].set_ylabel('Elbow error (deg)')
    axs[2].plot(t,[r['shoulder_reference_deg'] for r in rows],'k--',label='Prescribed shoulder');axs[2].plot(t,[r['shoulder_deg'] for r in rows],color='#009E73',label='Actual shoulder');axs[2].set_ylabel('Shoulder (deg)')
    axs[3].plot(t,[r['tension_N'] for r in rows],color='#CC79A7',label='Cable tension');axs[3].axhline(cfg['force_cap_N'],color='grey',ls=':');axs[3].set(ylabel='Cable (N)',xlabel='Time (s)')
    for ax in axs:ax.grid(alpha=.2)
    for ax in [axs[0],axs[2],axs[3]]:ax.legend(loc='upper right')
    fig.suptitle(episode_title(cfg)+'\n'+status.upper()+(' (partial trace)' if status!='completed' else ''),fontsize=10);fig.tight_layout();
    for extension in ('pdf','png'):
        buffer=io.BytesIO();fig.savefig(buffer,format=extension,dpi=170);atomic_bytes(folder/('tracking.'+extension),buffer.getvalue())
    plt.close(fig)


def run_episode(folder):
    import opensim as o
    from add_dumbbell import DEFAULT_GRIP
    from path_geometry import path_moment_arms
    o.Logger.setLevelString('Error');folder=Path(folder);cfg=read(folder/'settings.json');started=time.perf_counter();rows=[];state_rows=[];viewer=None;before=None
    result=dict(status='running',accepted_for_imitation=False,episode_id=cfg['episode_id'],controller='frozen_neural' if cfg.get('neural_checkpoint') else 'affine_dynamics_plus_PID_acceleration',source_split=cfg['split'])
    write(folder/'status.json',result)
    try:
        model,state,el,sh,cable=build(o,cfg);mus=model.getMuscles();
        if not np.isclose(math.degrees(el.getValue(state)),cfg['profile']['start_deg']+cfg.get('initial_offset_deg',0),atol=1e-7) or not np.isclose(math.degrees(el.getSpeedValue(state)),cfg.get('initial_velocity_deg_s',0),atol=1e-7):raise RuntimeError('Actual initial state does not match the declared recovery perturbation.')
        write(folder/'muscle_strength_audit.json',cfg['muscle_strength_audit']);model.printToXML(str(folder/'playback_model.osim'))
        network=features=None
        if cfg.get('neural_checkpoint'):network,features,before=load_network(cfg['neural_checkpoint']);write(folder/'frozen_model.json',before)
        write(folder/'settings.json',cfg)
        if cfg.get('live_viewer',True):
            from live_viewer import EpisodeViewer
            viewer=EpisodeViewer(o,model,state,ROOT)
        names=model.getStateVariableNames();names=[names.get(i) for i in range(names.getSize())];write(folder/'state_names.json',names)
        integral=previous=0.;steps=math.ceil(cfg['duration_s']/cfg['dt_s']);dt=cfg['dt_s']
        with (folder/'signals.partial.csv').open('w',newline='',buffering=1) as f,(folder/'states.partial.csv').open('w',newline='',buffering=1) as sf:
            writer=None;states=csv.writer(sf);states.writerow(['time_s']+names)
            for k in range(steps+1):
                if k%max(1,int(1/dt))==0 or k==steps:write_progress(folder/'episode_progress.json',dict(simulation_time_s=float(state.getTime()),duration_s=cfg['duration_s']))
                t=float(state.getTime());h=min(dt,max(0.,cfg['duration_s']-t));model.realizeAcceleration(state)
                q=float(el.getValue(state));v=float(el.getSpeedValue(state));qr,vr,ar,moving=reference(t,cfg);qsh=float(sh.getValue(state));vsh=float(sh.getSpeedValue(state));ash=float(sh.getAccelerationValue(state));error=qr-q
                if not all(math.isfinite(x) for x in [t,q,v,qsh,vsh,ash]):raise FloatingPointError('Nonfinite generalized state from OpenSim; this is a numerical failure, not tracking error.')
                if not math.radians(3)<=q<=math.radians(123):raise RuntimeError('Elbow outside independently checked 3-123 degree envelope.')
                if not math.radians(-25)<=qsh<=math.radians(65):raise RuntimeError('Shoulder outside prescribed study envelope.')
                arms=path_moment_arms(o,model,state,el,cable,mus);arm=float(arms[0])
                if arm<.005:raise RuntimeError('Insufficient or reversed cable moment arm.')
                r=dict(time_s=t,angle_rad=q,velocity_rad_s=v,reference_rad=qr,reference_velocity_rad_s=vr,reference_acceleration_rad_s2=ar,mass_kg=cfg['mass_kg'],shoulder_angle_rad=qsh,previous_tension_N=previous,error_integral_rad_s=integral,strength_scale=cfg['strength_scale'],shoulder_velocity_rad_s=vsh,shoulder_acceleration_rad_s2=ash)
                model.realizeDynamics(state)
                for i,name in enumerate(MUSCLES):
                    m=mus.get(i);r[name+'_activation']=float(m.getActivation(state));r[name+'_normalized_fiber_length']=float(m.getFiberLength(state)/m.getOptimalFiberLength());r[name+'_tendon_force_N']=float(m.getTendonForce(state));r[name+'_fiber_velocity_m_s']=float(m.getFiberVelocity(state))
                r['human_muscle_torque_Nm']=float(sum(float(arms[i+1])*r[name+'_tendon_force_N'] for i,name in enumerate(MUSCLES)))
                a0=gain=desired=None
                if network is None:
                    a0,gain=acceleration_response(model,state,el,cable,check=k==0);desired=ar+cfg['accel_kp']*error+cfg['accel_kd']*(vr-v)+cfg['accel_ki']*integral;raw=(desired-a0)/gain
                else:raw=network([r[n] for n in features])
                F=float(np.clip(raw,0,cfg['force_cap_N']))
                if not ((raw>cfg['force_cap_N'] and error>0) or (raw<0 and error<0)):integral=float(np.clip(integral+error*h,-cfg['integral_limit_rad_s'],cfg['integral_limit_rad_s']))
                cable.setOverrideActuation(state,F);model.realizeAcceleration(state);actual=float(cable.getActuation(state));shref=shoulder_reference(t,cfg)[0]
                if abs(actual-F)>1e-6:raise RuntimeError('Cable actuation override mismatch.')
                hand=model.getBodySet().get('r_ulna_radius_hand').findStationVelocityInGround(state,o.Vec3(*DEFAULT_GRIP))
                r.update(phase='initial_recovery' if t<cfg['start_hold_s'] else 'motion' if moving else 'end_hold',initial_offset_deg=cfg.get('initial_offset_deg',0),initial_velocity_deg_s=cfg.get('initial_velocity_deg_s',0),episode_id=cfg['episode_id'],motion_id=cfg['motion_id'],split=cfg['split'],trajectory=cfg['trajectory'],reference_deg=math.degrees(qr),angle_deg=math.degrees(q),error_deg=math.degrees(error),shoulder_deg=math.degrees(qsh),shoulder_reference_deg=math.degrees(shref),moving=int(moving),tension_N=actual,requested_force_N=raw,saturated=int(abs(raw-actual)>1e-7),moment_arm_m=arm,assistance_torque_Nm=arm*actual,elbow_acceleration_rad_s2=float(el.getAccelerationValue(state)),free_acceleration_rad_s2=a0,accel_per_newton=gain,desired_acceleration_rad_s2=desired,actual_hand_speed_m_s=math.sqrt(sum(hand.get(i)**2 for i in range(3))))
                if not all(math.isfinite(x) for x in r.values() if isinstance(x,(int,float))):raise FloatingPointError('Nonfinite physical signal.')
                if writer is None:writer=csv.DictWriter(f,fieldnames=list(r));writer.writeheader()
                writer.writerow(r);rows.append(r);values=model.getStateVariableValues(state);state_row=[t]+[values.get(i) for i in range(values.size())];state_rows.append(state_row);states.writerow(state_row)
                if viewer is not None:viewer.update(state,force=k==steps)
                if k==steps:break
                manager=o.Manager(model);manager.setIntegratorAccuracy(cfg['integrator_accuracy']);manager.setIntegratorMaximumStepSize(h/4);manager.initialize(state);state=o.State(manager.integrate(t+h));previous=actual
        result['status']='completed'
    except Exception:
        result.update(status='failed',error=traceback.format_exc());
        if 'state' in locals():
            try:
                values=model.getStateVariableValues(state);write(folder/'failure_terminal_state.json',dict(time_s=float(state.getTime()),values=[float(values.get(i)) if math.isfinite(values.get(i)) else str(values.get(i)) for i in range(values.size())]))
            except Exception:pass
        (folder/'error.txt').write_text(result['error'])
    finally:
        if viewer is not None:viewer.close()
        result.update(summarize(rows,cfg));m=result['motion_only'];result['sample_count']=len(rows);result['wall_seconds']=time.perf_counter()-started
        result['tracking_passed']=bool(result['status']=='completed' and m and m['rmse_deg']<=cfg['accept_rmse_deg'] and result['all_samples']['max_abs_error_deg']<=cfg['accept_max_error_deg'])
        result['accepted_for_imitation']=bool(result['tracking_passed'] and not cfg.get('neural_checkpoint'))
        try:
            if rows:
                if len(state_rows)!=len(rows):raise ValueError('Signal/state sample counts differ; refusing incomplete export')
                buffer=io.StringIO(newline='');writer=csv.DictWriter(buffer,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows);atomic_bytes(folder/'signals.csv',buffer.getvalue().encode('utf-8'))
                buffer=io.StringIO(newline='');writer=csv.writer(buffer);writer.writerow(['time_s']+names);writer.writerows(state_rows);atomic_bytes(folder/'states.csv',buffer.getvalue().encode('utf-8'))
                x=np.array([[r[n] for n in FEATURES] for r in rows],dtype=np.float32);y=np.array([[r['tension_N']] for r in rows],dtype=np.float32);ts=np.array([r['time_s'] for r in rows])
                buffer=io.BytesIO();np.savez_compressed(buffer,X_raw=x,y_force_N=y,time_s=ts,feature_names=np.array(FEATURES));atomic_bytes(folder/'training_arrays.npz',buffer.getvalue())
                buffer=io.BytesIO();np.savez_compressed(buffer,X_raw=x[:,:22],y_force_N=y,time_s=ts,feature_names=np.array(LEGACY_FEATURES));atomic_bytes(folder/'legacy22_arrays.npz',buffer.getvalue())
                buffer=io.StringIO();buffer.write(f'Arm26 complex motion states\nversion=1\nnRows={len(state_rows)}\nnColumns={len(names)+1}\ninDegrees=no\nendheader\n');buffer.write('\t'.join(['time']+names)+'\n')
                for rr in state_rows:buffer.write('\t'.join(map(str,rr))+'\n')
                atomic_bytes(folder/'states.sto',buffer.getvalue().encode('utf-8'))
                for temporary in ('signals.partial.csv','states.partial.csv'):(folder/temporary).unlink(missing_ok=True)
                if cfg.get('save_plots',True):plot_episode(folder,rows,cfg,status=result['status'])
            if before:
                _,_,after=load_network(cfg['neural_checkpoint'])
                if before!=after:raise ValueError('Frozen policy files changed during the diagnostic.')
                result['frozen_weights_verified']=True
        except Exception:result['export_error']=traceback.format_exc();result['accepted_for_imitation']=False
        write(folder/'status.json',result)
    return 0 if result['status']=='completed' and not result.get('export_error') else 2


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--worker',type=Path,required=True);a=p.parse_args();raise SystemExit(run_episode(a.worker))
