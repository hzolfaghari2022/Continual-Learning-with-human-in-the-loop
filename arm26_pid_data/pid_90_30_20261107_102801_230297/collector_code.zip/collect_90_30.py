"""Run fresh paired 90/30 PID data collection from any working directory."""
from collect_complex_pid import main
if __name__=='__main__':
    try:raise SystemExit(main())
    except KeyboardInterrupt:
        import collect_complex_pid as collector
        if collector.PROGRESS is not None:collector.PROGRESS.stage('interrupted')
        print('Interrupted. Keep data and resume this revision with --resume.',flush=True);raise SystemExit(130)
    except Exception as exc:
        import collect_complex_pid as collector
        if collector.PROGRESS is not None:collector.PROGRESS.stage('failed')
        print('COLLECTION STOPPED:',exc,flush=True);raise
