"""Incremental verified Git backup. No force push, deletion, token storage or LFS assumption."""
import argparse,hashlib,json,os,re,shutil,subprocess,tempfile,zipfile
from pathlib import Path
from complex_engine import read,write,sha
CHUNK=40*1024*1024

def git(args,cwd=None):
    env=os.environ.copy();env['GIT_TERMINAL_PROMPT']='0'
    p=subprocess.run(['git',*map(str,args)],cwd=cwd,env=env,text=True,capture_output=True,timeout=300)
    if p.returncode:raise RuntimeError('GitHub backup failed: git '+str(args[0])+'\n'+p.stderr[-2500:]+'\nData remains local. Check Git credentials/access, then use --backup-only.')
    return p.stdout.strip()

class GitBackup:
    def __init__(self,repo,out,branch=None,cache=None):
        if not shutil.which('git'):raise RuntimeError('Install Git for Windows and sign in before collection, or explicitly use --no-github.')
        self.out=Path(out).resolve();self.repo=str(repo);self.branch=branch
        # Only explicit local repo paths (for an existing clone) or GitHub URLs.
        local=Path(repo).expanduser().exists()
        if not local and not re.fullmatch(r'(https://github\.com/[\w.-]+/[\w.-]+(?:\.git)?|git@github\.com:[\w.-]+/[\w.-]+(?:\.git)?)',repo):raise ValueError('Use a GitHub repository URL without embedded credentials, or an existing local repository path.')
        remote=git(['remote','get-url','origin'],repo) if local and (Path(repo)/'.git').exists() else repo
        if remote.startswith('https://') and '@' in remote:raise ValueError('Remove embedded credentials from the Git remote; use Git Credential Manager or SSH.')
        self.remote=remote;key=hashlib.sha256(remote.encode()).hexdigest()[:12]
        self.clone=Path(cache or Path.home()/'Arm26_GitHub_Backup_Cache')/key
        self.clone.parent.mkdir(parents=True,exist_ok=True)
        if not (self.clone/'.git').exists():git(['clone',remote,str(self.clone)])
        if git(['status','--porcelain'],self.clone):raise RuntimeError('Backup cache has uncommitted files. Preserve it and select a new --github-cache directory; nothing was overwritten.')
        git(['fetch','origin'],self.clone)
        if branch:
            refs=git(['branch','-r'],self.clone).splitlines()
            if not any(x.strip()=='origin/'+branch for x in refs):raise RuntimeError('Requested branch does not exist on GitHub: '+branch)
            git(['checkout',branch],self.clone)
        self.branch=git(['branch','--show-current'],self.clone)
        if not self.branch:raise RuntimeError('Backup requires a named branch.')
        # Fast-forward only; a divergent history is reported, never reset.
        remote_refs=git(['ls-remote','--heads','origin','refs/heads/'+self.branch],self.clone)
        if remote_refs:git(['merge','--ff-only','origin/'+self.branch],self.clone)
        for field in ('user.name','user.email'):
            try:value=git(['config','--get',field],self.clone)
            except RuntimeError:raise RuntimeError('Git commit identity is missing. Set git config --global '+field+' to your own name/email before running.')
            if not value:raise RuntimeError('Git identity '+field+' is empty.')
        self.dest=self.clone/'arm26_pid_data'/self.out.name;self.dest.mkdir(parents=True,exist_ok=True)
        print('GITHUB DESTINATION:',remote,'branch',self.branch,'folder','arm26_pid_data/'+self.out.name,flush=True)
    def archive(self,folder,dest,previous):
        files=sorted(p for p in folder.rglob('*') if p.is_file())
        digest=hashlib.sha256(''.join(str(p.relative_to(folder))+sha(p) for p in files).encode()).hexdigest()
        if previous and previous.get('source_sha256')==digest and all((self.dest/f).exists() and sha(self.dest/f)==h for f,h in previous['archive_files'].items()):return previous
        dest.parent.mkdir(parents=True,exist_ok=True)
        with tempfile.TemporaryDirectory() as tmp:
            archive=Path(tmp)/'episode.zip'
            with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
                for p in files:z.write(p,p.relative_to(folder))
            parts={}
            if archive.stat().st_size<=CHUNK:
                shutil.copy2(archive,dest);parts[str(dest.relative_to(self.dest))]=sha(dest)
            else:
                with archive.open('rb') as f:
                    i=1
                    while True:
                        chunk=f.read(CHUNK)
                        if not chunk:break
                        part=dest.with_name(dest.name+f'.{i:03d}');part.write_bytes(chunk);parts[str(part.relative_to(self.dest))]=sha(part);i+=1
            return dict(source_sha256=digest,archive_files=parts,files={str(p.relative_to(folder)):sha(p) for p in files})
    def sync(self,source_root=None,final_status=None):
        try:return self._sync(source_root,final_status)
        except Exception as exc:
            previous=read(self.out/'GITHUB_STATUS.json') if (self.out/'GITHUB_STATUS.json').exists() else {}
            write(self.out/'GITHUB_STATUS.json',dict(status='failed',last_verified_commit=previous.get('commit',previous.get('last_verified_commit')),error=str(exc),note='All local data retained. Fix access and retry --backup-only.'))
            raise

    def _sync(self,source_root=None,final_status=None):
        print('GITHUB BACKUP: archiving all saved attempts and committing the 90/30 strength folders; simulation is paused during upload.',flush=True)
        mp=self.dest/'BACKUP_MANIFEST.json';previous=read(mp) if mp.exists() else {};items={}
        # All attempts, accepted/rejected and pilots, remain distinguishable.
        for status in sorted(self.out.rglob('status.json')):
            folder=status.parent
            if not (folder/'settings.json').exists():continue
            cfg=read(folder/'settings.json');pct=round(cfg['strength_scale']*100);relative=folder.relative_to(self.out)
            if relative.parts[0].startswith('strength_'):target=Path(f'strength_{pct}')/Path(*relative.parts[1:])/'episode.zip'
            else:target=Path('pilot_and_failed_attempts')/f'strength_{pct}'/relative/'episode.zip'
            key=str(relative);items[key]=self.archive(folder,self.dest/target,previous.get('episodes',{}).get(key))
        common=self.dest/'collection_metadata';common.mkdir(exist_ok=True)
        for f in self.out.iterdir():
            if f.is_file() and f.name!='GITHUB_STATUS.json' and f.suffix.lower() in ('.json','.csv','.html','.zip','.pdf'):shutil.copy2(f,common/f.name)
        if final_status and (common/'PROGRESS.json').exists():
            completion=read(common/'PROGRESS.json');completion['status']=final_status;completion['note']='Simulation/report complete; this completion snapshot is published by the verified final backup commit.';write(common/'PROGRESS.json',completion)
            (common/'PROGRESS.html').write_text('<html><meta charset="utf-8"><body><h1>Arm26 collection '+final_status+'</h1><p>Simulation and report completed. This file is published in the final backup commit; see COLLECTION_STATUS.json for data acceptance coverage.</p></body></html>',encoding='utf-8')
        if source_root is not None:
            root=Path(source_root);code=self.dest/'collector_code.zip'
            with zipfile.ZipFile(code,'w',zipfile.ZIP_DEFLATED) as z:
                for f in sorted(root.rglob('*')):
                    rel=f.relative_to(root)
                    if f.is_file() and (len(rel.parts)==1 and f.suffix in ('.py','.md','.txt','.bat','.osim') or rel.parts[0]=='Geometry'):z.write(f,rel)
        write(mp,dict(format_version=1,local_collection=str(self.out),episodes=items,storage='Each episode.zip retains every file and time sample. Split ZIPs must be concatenated before extraction.',strengths=sorted(set(round(read(s.parent/'settings.json')['strength_scale']*100) for s in self.out.rglob('status.json') if (s.parent/'settings.json').exists()))))
        relative=self.dest.relative_to(self.clone).as_posix();git(['add','-f','--',relative],self.clone)
        changed=git(['diff','--cached','--name-only'],self.clone)
        if changed:git(['commit','-m',f'Arm26 PID backup {self.out.name}: {len(items)} attempts'],self.clone)
        head=git(['rev-parse','HEAD'],self.clone)
        git(['push','origin','HEAD:refs/heads/'+self.branch],self.clone)
        remote=git(['ls-remote','--heads','origin','refs/heads/'+self.branch],self.clone).split()[0]
        if remote!=head:raise RuntimeError('GitHub head verification failed; local data retained.')
        for entry in items.values():
            for file,h in entry['archive_files'].items():
                if sha(self.dest/file)!=h:raise RuntimeError('Backup archive checksum changed: '+file)
        # Verify the manifest at the pushed commit, not a filename at an unrelated HEAD.
        saved=json.loads(git(['show',head+':'+relative+'/BACKUP_MANIFEST.json'],self.clone))
        if saved['episodes']!=items:raise RuntimeError('Committed backup manifest mismatch.')
        result=dict(status='verified',commit=head,repository=self.remote,branch=self.branch,folder=relative,episode_archives=len(items))
        write(self.out/'GITHUB_STATUS.json',result);print('GITHUB VERIFIED:',head,'|',len(items),'attempt archives',flush=True)
        return result

def restore(backup,destination):
    backup=Path(backup);dest=Path(destination);manifest=read(backup/'BACKUP_MANIFEST.json')
    for relative,entry in manifest['episodes'].items():
        folder=dest/relative;folder.mkdir(parents=True,exist_ok=True)
        with tempfile.TemporaryDirectory() as tmp:
            archive=Path(tmp)/'episode.zip'
            with archive.open('wb') as f:
                for name,h in sorted(entry['archive_files'].items()):
                    part=backup/name
                    if sha(part)!=h:raise ValueError('Archive checksum mismatch: '+name)
                    with part.open('rb') as src:shutil.copyfileobj(src,f)
            with zipfile.ZipFile(archive) as z:
                for name in z.namelist():
                    target=(folder/name).resolve()
                    if not target.is_relative_to(folder.resolve()):raise ValueError('Unsafe archive path')
                z.extractall(folder)
        for name,h in entry['files'].items():
            if sha(folder/name)!=h:raise ValueError('Restored file checksum mismatch: '+name)
    print('RESTORED AND VERIFIED:',dest)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--restore',type=Path,required=True);p.add_argument('--destination',type=Path,required=True);a=p.parse_args();restore(a.restore,a.destination)
