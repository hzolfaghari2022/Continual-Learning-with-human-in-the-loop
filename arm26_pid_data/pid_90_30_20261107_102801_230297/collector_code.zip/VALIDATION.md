Validation scope
================
13 automated tests pass:
- Default plan: 12 conditions, 240 full episodes, 84/12/24 per strength.
- Independent reference seeds across development/test splits and identical
  references between the 90% and 30% versions of each paired motion.
- Default reference geometry stays within the declared elbow-angle envelope.
- Explicit rejection of accidentally requesting the old 60% scenario.
- Temporary Windows sharing-lock retries; nonfatal progress update failures;
  critical failures remain visible.
- Truncated CSV or corrupted CSV force targets are rejected even before hashes
  are created; large final binary publication is complete after a temporary lock.

Real OpenSim 4.6 checks:
- A reduced full-duration collection ran 20 actual episodes: 8 independent
  pilots and 12 full episodes, fixed/moving shoulders and both 90%/30% strengths.
- Five additional full-duration boundary cases passed: moving-shoulder chirp
  from 70 degrees at both strengths; variable-speed motion from 20 degrees at
  both strengths; moving-shoulder multisine from 70 degrees at 30% strength.
- A resume check exposed incomplete streamed CSV publication. The final code
  now writes live output only to partial files, then publishes complete CSV,
  binary-array and state-playback files atomically from complete in-memory
  records, with flush/fsync and bounded replacement retries. It also checks
  CSV row counts, timestamps and target forces against the binary arrays.
- AFTER that fix, another reduced complete collection passed 8 actual episodes
  at both strengths using dt=0.02 s. Two additional full-duration cases passed
  with the DEFAULT dt=0.005 s at 30%: chirp/moving shoulder/start70 and variable
  speed/fixed shoulder/start20. All final CSV/NPZ/state files passed semantic
  and integrity checks.
- The final-code reduced run resumed with ZERO worker reruns; 36 checked
  episode files were unchanged. All eight attempt archives were pushed to a
  LOCAL bare Git test repository and restored with matching checksums, including
  separate strength_90 and strength_30 folders. The user's actual GitHub
  repository was not updated here.
- Generated collection Overleaf source compiled successfully and representative
  pages were visually reviewed. PID teacher accuracy is not a neural or CL result.

Practical limits:
The full default 240-episode plan has not run here. The collector performs the
independent PID feasibility checks on the user's machine before full collection.
Physics uses CPU. Native Windows locks were simulated; native GUI was not tested
(the default is headless). No NN was trained; no forgetting, 5-degree baseline
error, EWC improvement or near-zero EWC tracking error is claimed or guaranteed.
The prior 90/60 trainer needs an explicit update to consume this 90/30 experiment.
