"""Measure the mechanical strength change on independent PID pilots only."""
import csv
from pathlib import Path
import numpy as np
from complex_engine import read,write
from complex_trajectories import reference_digest

def summarize_pilots(out,calibration):
    out=Path(out);rows=[]
    for condition,cal in sorted(calibration.items()):
        speed=cal['selected_speed_scale'];pairs={}
        if speed is None:continue
        for r in cal['attempts']:
            if np.isclose(r['speed_scale'],speed) and r['accepted']:
                pairs.setdefault(tuple(r['recovery']),{})[r['strength']]=Path(r['folder'])
        for recovery,pair in sorted(pairs.items()):
            if set(pair)!={90,30}:raise ValueError('Incomplete 90/30 pilot contrast pair')
            cfg90=read(pair[90]/'settings.json');cfg30=read(pair[30]/'settings.json')
            if reference_digest(cfg90)!=reference_digest(cfg30):raise ValueError('Pilot contrast requires identical reference motions')
            forces={};torques={}
            for pct,folder in pair.items():
                with np.load(folder/'training_arrays.npz',allow_pickle=False) as z:forces[pct]=(z['time_s'].copy(),z['y_force_N'][:,0].copy())
                with (folder/'signals.csv').open() as f:signals=list(csv.DictReader(f))
                torques[pct]=float(np.mean([abs(float(r['human_muscle_torque_Nm'])) for r in signals]))
            t,a=forces[90];tb,b=forces[30]
            if len(t)!=len(tb) or not np.allclose(t,tb):raise ValueError('Pilot contrast sample times differ')
            delta=b-a
            rows.append(dict(condition=condition,initial_error_deg=recovery[0],initial_speed_deg_s=recovery[1],speed_scale=speed,samples=len(t),force_gap_rmse_N=float(np.sqrt(np.mean(delta**2))),mean_abs_force_gap_N=float(np.mean(abs(delta))),peak_abs_force_gap_N=float(np.max(abs(delta))),mean_force_90_N=float(np.mean(a)),mean_force_30_N=float(np.mean(b)),mean_abs_human_torque_90_Nm=torques[90],mean_abs_human_torque_30_Nm=torques[30]))
    if not rows:raise ValueError('No accepted paired independent pilot data')
    average=float(np.mean([r['force_gap_rmse_N'] for r in rows]))
    note='Paired PID pilots use identical references and initial perturbations. These are observed physical force-command differences, not NN errors, and do not establish catastrophic forgetting or EWC improvement. Muscle excitation remains 0.02 at both strengths. No final train/validation/test arrays are read for this diagnostic.'
    write(out/'PILOT_FORCE_CONTRAST.json',dict(rows=rows,mean_force_gap_rmse_N=average,note=note))
    with (out/'PILOT_FORCE_CONTRAST.csv').open('w',newline='') as f:w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    import matplotlib;matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    fig,axs=plt.subplots(1,2,figsize=(11,4.5));x=np.arange(len(rows));axs[0].bar(x,[r['force_gap_rmse_N'] for r in rows],color='#0072B2');axs[0].set(ylabel='Paired PID force difference RMSE (N)',xlabel='Independent pilot pair',title='Observed 90% vs 30% assistance difference')
    axs[1].plot(x,[r['mean_abs_human_torque_90_Nm'] for r in rows],'o-',label='90% strength');axs[1].plot(x,[r['mean_abs_human_torque_30_Nm'] for r in rows],'s-',label='30% strength');axs[1].set(ylabel='Mean absolute muscle torque (N m)',xlabel='Independent pilot pair',title='Observed human muscle contribution');axs[1].legend()
    for ax in axs:ax.grid(axis='y',alpha=.2)
    from collection_report import finish
    finish(fig,out/'collection_overleaf/figures','pilot_strength_contrast')
    print(f'PILOT STRENGTH CONTRAST: mean force-command difference RMSE {average:.4f} N | {len(rows)} independent pairs. This is not a prediction of NN forgetting.',flush=True)
    return rows
