# Arm26 PID data collection: 90% and 30% muscle strength

Run this Python file in VS Code, using your existing lstm-py312 interpreter:

    conda activate lstm-py312
    python .\collect_90_30.py

Open the extracted folder that directly contains collect_90_30.py before using the
terminal command. Alternatively, open that Python file and use Run Python File.
The entry point imports its modules relative to its own folder, independent of the
terminal working directory. This is a NEW collection; keep previous results.

## What this collects
Real OpenSim 4.6 forward-dynamics PID demonstrations, using a fresh original model
for each episode. Every muscle's maximum isometric force is multiplied by 0.9 or
0.3; the stored audit records original and scaled values for all six muscles.
The dumbbell is 5 kg. Human muscle excitations remain 0.02 in BOTH strengths.
One independently controlled cable, exo_flexor, supplies up to 650 N. The shoulder
is prescribed kinematically, not controlled by a second cable-force output.
The teacher is affine-dynamics compensation plus PID acceleration feedback.

Default full plan: 240 episodes, HALF the previous 480 full episodes:

| Strength | Training | Validation | Final test | Total |
| --- | ---: | ---: | ---: | ---: |
| 90% | 84 | 12 | 24 | 120 |
| 30% | 84 | 12 | 24 | 120 |

12 declared conditions: four motion families x elbow initial references
20, 45, 70 degrees. Each has 7/1/2 independently seeded repetitions.
- Baseline smooth: fixed shoulder, requested 1.0x speed.
- Variable speed / reversals: fixed shoulder, requested 1.25x speed.
- Multisine: moving shoulder, requested 1.25x speed.
- Chirp: moving shoulder, requested 1.25x speed.

There is one requested speed per condition, not another duplicated speed grid.
Both strengths have identical references, load and initial disturbances for each
paired episode. Initial errors -0.5, 0, +0.5 deg and velocities -5, 0, +5 deg/s
supply recovery examples. All actual timesteps, states and force targets are saved.

## Independent feasibility pilots and physical contrast
Before full data collection, 48 independent pilot episodes are attempted:
12 conditions x two strengths x two extreme recovery conditions.
If a PID pair fails, declared slowdown factors 1.0, 0.8, 0.64 are tried in order.
The total pilot count is 48 minimum, 144 maximum. Thus the COMPLETE default job is
288 attempts minimum and 384 maximum. A condition that fails every speed stops
collection; it is not passed off as valid teacher data. Actual selected speeds,
peak velocities, PID errors and rejected attempts are retained.

PILOT_FORCE_CONTRAST.json/.csv and a figure compare PID cable-force commands and
human muscle torque at 90% and 30% on matched independent pilots. These diagnostics
use only pilot data, never the future train/validation/test arrays. They quantify
the physical difference; they do NOT predict neural forgetting or EWC gains.
The collector's quality checks naturally write and validate the collected records;
no neural model, tuning, or final neural test is performed by this package.

To run only the independent pilots first:

    python .\collect_90_30.py --pilot-only

To continue that same pilot run into full collection, with the same settings:

    python .\collect_90_30.py --resume

No pilot physics is repeated when its saved files pass integrity checks.

## No imposed errors and no promised EWC advantage
The collector does not train any network and cannot guarantee 5-degree no-CL
error or near-zero EWC error. PID labels are accurate, unmodified physical outputs.
No noise, reference shift, test-label alteration, force corruption, artificial
instability or method-specific dynamics is added to create a desired comparison.
An amplitude of 10 deg and peak error of 5 deg would mean 50% peak-error ratio;
peak error and RMSE are different metrics. These are illustrative numbers,
not settings enforced in the data or guaranteed future outcomes.

A future valid forgetting experiment is: learn A90 well; adapt on B30;
freeze weights; revisit the SAME held-out A90 motions. Compare ordinary adaptation
and EWC using identical MLPs, initial weights, inputs, data and training budgets.
Both must also learn B30. EWC's benefit must be measured, not specified in advance.

## Data split and role files
Whole paired episodes have a predeclared 70/10/20 split, independently seeded at
collection time. Matching strength versions always share a split. Pilots are not
included in any training/validation/test role. No test result selects speed or
any future neural/EWC setting. A new seed separates this collection from old tests.

ALL_ACCEPTED_90.json and ALL_ACCEPTED_30.json contain all accepted paired records
at each strength, suitable for a same-motion strength-only experiment.
TASK_A_90.json contains the fixed-shoulder motion families at 90%; TASK_B_30.json
contains moving-shoulder complex families at 30%. These are an OPTIONAL sequential
motion-distribution-shift design. DIAGNOSTIC_COMPLEX_90 and CONTROL_A_30 retain
matched controls to separate strength effects from trajectory generalization.
The future trainer must explicitly choose its protocol before final testing.

Full accepted counts must match the declared repetitions for every condition and
split. If not, ready_for_training is false and the missing/rejected pairs are
reported; no test episode is moved into training, and no incomplete split is
silently treated as the requested ratio.

## Saved outputs
Default directory:
C:\Users\hzlfghri\Arm26_PID_90_30_Data\pid_90_30_<timestamp>_<id>\

- strength_90 and strength_30: separate complete episode directories.
- pilot: independent feasibility attempts, including rejected/failed attempts.
- DATASET_MANIFEST.json, COLLECTION_STATUS.json, TRAINING_HANDOFF.json.
- settings.json, training_arrays.npz, signals.csv, states.csv/.sto, model XML,
  full muscle strength audit and tracking PNG/PDF for each episode.
- PROGRESS.json / PROGRESS.html and terminal progress every five seconds:
  counts, elapsed time, current simulated progress, ETA and estimated finish.
- COLLECTION_OVERLEAF.zip: source and figures; upload to Overleaf, compile main.tex.
- COLLECTION_REPORT.html and COLLECTION_REPORT.pdf when local pdflatex is present.
- PID_DATA_QUALITY.csv and SPEED_DEMANDS.csv.
- PILOT_FORCE_CONTRAST.json/.csv and pilot muscle/force contrast figure.

No live windows open by default. Physics is CPU OpenSim; CUDA is not used for
PID data collection. Every sample is saved regardless of terminal output rate.
The resume code retries temporary Windows sharing locks; progress-display
failures are nonfatal. Critical data-file failures stop rather than lose data.

## GitHub
Configured repository:
https://github.com/hzolfaghari2022/Continual-Learning-with-human-in-the-loop.git
Git checks access before physics, uploads periodically and at completion, and
verifies the pushed commit. Distinct strength_90 / strength_30 episode archives
retain all samples, with reports, configuration and source code. Existing remote
content is preserved; no force push or embedded credentials is used.
Your actual GitHub upload happens on YOUR computer when this collector runs.
Git authentication and commit identity must already work.
--no-github is an explicit opt-out. To retry a backup without repeating physics:

    python .\collect_90_30.py --backup-only

## Resume and previews
After interruption, keep source/settings and data unchanged:

    python .\collect_90_30.py --resume

To target a specific run use --run-folder "C:\path\to\pid_90_30_..." --resume.
To preview only the declared plan, without physics or GitHub:

    python .\collect_90_30.py --plan-only

To rebuild only the collection report:

    python .\collect_90_30.py --report-only

This package collects PID data ONLY. The previous 90/60 GRU trainer does not
support these 90/30 role files without an explicit update. Do not relabel 30%
as 60%. The handoff documents all 24 raw features and the force target, and lists
an optional 23-input strength-unobserved variant to consider BEFORE testing.
A future MLP/EWC package must document whichever input contract it uses.
