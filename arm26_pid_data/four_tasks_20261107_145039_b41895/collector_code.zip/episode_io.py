"""Verified per-episode worker execution; independent of task planning."""
import csv,hashlib,json,sys,time
from pathlib import Path
import numpy as np
from complex_engine import read,write,sha
from complex_trajectories import FEATURES
from process_helpers import run_logged
ROOT=Path(__file__).resolve().parent
PROGRESS=None

def operational_error(folder,reason='Operational error; stop before collecting more data.'):
    path=Path(folder)/'error.txt'
    detail=path.read_text(encoding='utf-8',errors='replace') if path.exists() else '(Worker error.txt is absent; see console.log and status.json.)'
    raise RuntimeError(reason+'\nWORKER ERROR FILE: '+str(path)+'\n'+detail[-16000:])


def validate_saved_attempt(cfg,folder,result):
    if result.get('export_error'):raise RuntimeError('Export failed: '+str(folder/'status.json'))
    if result['status']=='failed' and any(k in result.get('error','') for k in ['AttributeError','ImportError','ModuleNotFoundError','Viewer','viewer','TypeError','FloatingPointError']):operational_error(folder)
    integrity=folder/'file_integrity.json'
    if integrity.exists():
        for name,value in read(integrity).items():
            if not (folder/name).exists() or sha(folder/name)!=value:raise ValueError('Saved episode file changed: '+str(folder/name))
    if result.get('sample_count',0):
        with np.load(folder/'training_arrays.npz',allow_pickle=False) as z:
            x=z['X_raw'];y=z['y_force_N'];t=z['time_s']
            if list(z['feature_names'])!=FEATURES or x.shape!=(len(t),len(FEATURES)) or y.shape!=(len(t),1) or len(t)!=result['sample_count']:raise ValueError('Invalid saved data dimensions: '+str(folder))
            if not np.isfinite(x).all() or not np.isfinite(y).all() or not np.allclose(x[:,21],cfg['strength_scale']) or not np.all(np.diff(t)>0) or y.min()<0 or y.max()>650.0001:raise ValueError('Invalid values/time/strength in saved data: '+str(folder))
            if not np.isclose(np.degrees(x[0,0]-x[0,2]),cfg['initial_offset_deg'],atol=1e-4) or not np.isclose(np.degrees(x[0,1]),cfg['initial_velocity_deg_s'],atol=1e-4):raise ValueError('Recorded initial state differs from the declared recovery state.')
            with (folder/'signals.csv').open(newline='') as stream:signals=list(csv.DictReader(stream))
            with (folder/'states.csv').open(newline='') as stream:
                state_reader=csv.reader(stream);header=next(state_reader);states=list(state_reader)
            if len(signals)!=len(t) or len(states)!=len(t) or not all(len(row)==len(header) for row in states):raise ValueError('CSV export sample count differs from binary arrays: '+str(folder))
            if not np.allclose([float(row['time_s']) for row in signals],t) or not np.allclose([float(row[0]) for row in states],t):raise ValueError('CSV export times differ from binary arrays: '+str(folder))
            if not np.allclose([float(row['tension_N']) for row in signals],y[:,0],rtol=1e-6,atol=1e-5):raise ValueError('CSV force targets differ from binary arrays: '+str(folder))
    if result.get('accepted_for_imitation') and (result['status']!='completed' or not result.get('tracking_passed')):raise ValueError('Invalid teacher acceptance flag.')
    if not integrity.exists():
        names=['settings.json','status.json','signals.csv','states.csv','states.sto','training_arrays.npz','legacy22_arrays.npz','muscle_strength_audit.json','playback_model.osim']
        write(integrity,{name:sha(folder/name) for name in names if (folder/name).exists()})
    return result


def execute(cfg,folder,timeout):
    folder.mkdir(parents=True,exist_ok=True)
    if PROGRESS is not None:cfg['progress_label']=PROGRESS.start(cfg,folder,'pilot' if cfg['split']=='pilot' else 'full')
    # Display/export settings do not change the physics identity.
    identity=hashlib.sha256(json.dumps({k:v for k,v in cfg.items() if k not in ['live_viewer','save_plots','progress_label']},sort_keys=True).encode()).hexdigest()
    ip=folder/'episode_identity.json';sp=folder/'status.json'
    if sp.exists() and read(sp)['status'] in ['completed','failed']:
        saved=read(sp)
        retry_operational=bool(saved.get('export_error')) or (saved['status']=='failed' and any(k in saved.get('error','') for k in ['AttributeError','ImportError','ModuleNotFoundError','Viewer','viewer','TypeError','FloatingPointError']))
        if not ip.exists() or read(ip)['sha256']!=identity:raise ValueError('Existing episode configuration changed: '+str(folder))
        if not retry_operational:
            print('REUSING VERIFIED SAVED ATTEMPT:',cfg['episode_id'],flush=True)
            result=validate_saved_attempt(cfg,folder,saved)
            if PROGRESS is not None:PROGRESS.finish(reused=True)
            return result
    if any(folder.iterdir()):
        archive=folder.parent/'interrupted_attempts';archive.mkdir(exist_ok=True);folder.rename(archive/(folder.name+'_'+str(time.time_ns())));folder.mkdir()
    write(folder/'settings.json',cfg);write(ip,dict(sha256=identity))
    print(f"PID {cfg['strength_scale']*100:g}% | {cfg['episode_id']} | {cfg['profile']['shoulder_mode']} shoulder | {cfg['duration_s']:.1f}s",flush=True)
    run_logged([sys.executable,ROOT/'complex_engine.py','--worker',folder],folder/'console.log',allowed=(0,2),timeout=timeout,heartbeat=PROGRESS.refresh if PROGRESS is not None else None)
    result=validate_saved_attempt(cfg,folder,read(sp))
    if result.get('export_error'):raise RuntimeError('Export failed: '+str(folder/'status.json'))
    if result['status']=='failed' and any(k in result.get('error','') for k in ['AttributeError','ImportError','ModuleNotFoundError','Viewer','viewer','TypeError','FloatingPointError']):operational_error(folder,'Operational error; no speed calibration performed.')
    m=result.get('motion_only') or {};print('  '+result['status']+f" | RMSE {m.get('rmse_deg','n/a')} deg | accepted {result['accepted_for_imitation']}",flush=True)
    if PROGRESS is not None:PROGRESS.finish()
    return result

