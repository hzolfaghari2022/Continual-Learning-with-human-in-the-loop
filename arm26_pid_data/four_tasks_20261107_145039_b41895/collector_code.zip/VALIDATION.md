# Validation and remaining limits

## Performed

- Default metadata plan: 640 episodes, 112/16/32 per task, 28 inputs, approximately 2,689,939 nominal full-episode raw samples. Pilot speed reductions can increase sample counts.
- OpenSim 4.6 model initializes with the added yaw carrier. Proximal muscle attachments co-rotate with that carrier to retain routing; an earlier direct-yaw prototype exposed nonfinite muscle states and was replaced rather than included.
- Independent geometry/physics probes: lateral Task C crossed the body midline over approximately 0.61 m in a representative run. D's smooth external-load pilot passed its teacher accuracy check.
- Thirty-two boundary pilots passed at both extreme starting angles (50/80 degrees), both trajectory variants and both extreme recovery states (−2°/−15°/s and +2°/+15°/s), across all four tasks. These probes used dt=0.01 s; the default collector still runs its own pilots at dt=0.005 s before collecting data.
- Complete small collection: 8 independent pilots plus 16 full episodes; all accepted. Custom 2/1/1 original splits were preserved. These QA data are not bundled as the user's dataset.
- Complete CPU neural run on that small collection used 200 initial epochs and 120 adaptation epochs per task/candidate, with 16 Fisher samples. All three positive lambda sequences ran, including consolidation of A/B/C for the later stages. All 22 held-out checkpoint/task rollouts completed and verified frozen weights. The larger default uses 1,024 Fisher samples and its larger collected train/validation pools.
- In the small run, final no-EWC versus EWC RMSE (degrees) was A 0.717/0.510, B 1.425/0.936, C 0.798/0.571, D 0.104/0.145. This is an accuracy/retention trade-off on one small dataset and one seed, not statistical significance or a promise for the full experiment. The selected lambda's validation adaptation constraint failed; this fallback is disclosed in the reports.
- Unit checks pass for PyTorch/NumPy/deployment decoder agreement, restoring feedback sensitivities, accumulated EWC penalties, 6,211 total / 1,243 selected parameters per memory, completed-epoch checkpoint resume, and test-access rejection before the global seal.
- Cached physics reuse was verified without reintegration. Report-only and old-result recovery exports were run without modifying frozen weights or saved test results.
- Trainer Overleaf compiles to three pages with exactly two figures; collector Overleaf compiles to two pages with two figures. Input tables and comparison pages were visually checked. The brief trainer HTML embeds its two figures for standalone sharing. Detailed plots remain separate.
- A simulated pdflatex failure preserves Overleaf source and produces a failure status instead of losing training. The old-result recovery exporter produced a one-page PDF plus HTML/Overleaf from an existing older three-task result folder without importing PyTorch/OpenSim or retraining.
- Local Git backup tests used a bare test repository, not the user's GitHub: training archive checksums were verified for 722 files; all 24 pilot/full collector attempt archives were restored and checked. Backup snapshot checksums are computed from the actual archived bytes, and Git's long-path option is enabled for Windows compatibility.

## Limits

- The complete default 640-episode dataset and full GPU study were not run remotely. Windows/Simbody visualization and the user's CUDA installation still need local verification.
- The yaw carrier is a simplified kinematic extension of planar Arm26, not a validated anatomical shoulder or collision model. Shoulder motion is prescribed; the learned output is one elbow cable force.
- More task diversity/data does not guarantee catastrophic forgetting or an EWC advantage. The code reports actual errors, failures and constraint results.
- The user's previous error traceback was not supplied, so its exact cause has not been diagnosed. New late-report/backup recovery protects saved results; the report-recovery tool cannot invent tests that were never saved.
