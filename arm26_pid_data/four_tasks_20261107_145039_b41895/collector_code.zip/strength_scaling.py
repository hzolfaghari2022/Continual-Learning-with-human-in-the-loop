"""Apply uniform muscle force-capacity scaling to a FRESH original model."""
import math

def apply_strength(model, strength_scale=0.60):
    if not math.isfinite(strength_scale) or not 0 < strength_scale <= 1:
        raise ValueError('Strength scale must be in (0, 1].')
    audit = []
    muscles = model.updMuscles()
    for i in range(muscles.getSize()):
        muscle = muscles.get(i)
        original_force = float(muscle.getMaxIsometricForce())
        muscle.setMaxIsometricForce(strength_scale * original_force)
        actual_force = float(muscle.getMaxIsometricForce())
        if not math.isclose(actual_force, strength_scale * original_force, rel_tol=1e-12):
            raise RuntimeError('Strength scaling failed: ' + muscle.getName())
        audit.append(dict(muscle=muscle.getName(), original_max_isometric_force_N=original_force,
                          scaled_max_isometric_force_N=actual_force, strength_scale=strength_scale))
    return audit
