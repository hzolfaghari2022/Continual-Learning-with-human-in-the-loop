"""Vectorized deployment for the four-task learned-feedback MLP."""
from pathlib import Path
import numpy as np,json
from complex_trajectories import encode,FEATURES,SCALES
class NumpyPolicy:
 def __init__(self,path):
  path=Path(path);self.meta=json.loads(path.with_suffix('.json').read_text())
  if self.meta['features']!=FEATURES or self.meta['encoding']!='four_task_feedback_v1' or not np.allclose(self.meta['scales'],SCALES):raise ValueError('Four-task policy contract mismatch.')
  with np.load(path,allow_pickle=False) as z:self.w={k:z[k].copy() for k in z.files}
 def reset(self):pass
 def normalized(self,x):
  x=np.asarray(x,dtype=np.float32);context=x.copy();context[...,2:4]=0.;h=context
  for i in range(3):
   h=h@self.w['W'+str(i)].T+self.w['b'+str(i)]
   if i<2:h=np.tanh(h)
  nominal=1/(1+np.exp(-np.clip(h[...,0],-80,80)));kp=.05*np.logaddexp(0,h[...,1]);kd=.05*np.logaddexp(0,h[...,2])
  return nominal+kp*x[...,2]+kd*x[...,3]
 def __call__(self,raw):return float(650*self.normalized(encode(np.asarray(raw,dtype=np.float32))))
 def predict(self,x,ids=None):return np.concatenate([650*self.normalized(x[i:i+8192]) for i in range(0,len(x),8192)])
