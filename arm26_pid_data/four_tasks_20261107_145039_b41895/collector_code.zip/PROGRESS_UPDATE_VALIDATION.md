# Terminal-progress update validation

- Original root Python modules, OpenSim model and physics/data settings are byte-identical to the previously supplied collector. Monitoring code lives in a subfolder, preserving the original root-level source-hash contract.
- Tested episode/sample/acceptance counters and ETA calculations against synthetic status/metadata fixtures without loading training arrays.
- Read-only watch mode was checked against a real completed four-task collection and verified not to write to the watched result folder.
- Tested that the complete updated code snapshot includes the original collector, model, geometry and progress launcher for the existing GitHub metadata backup.
- The original collector continues to own all physics, episode integrity checks, readiness flags, reports and GitHub uploads. The monitor does not change those algorithms.
- ETA is an estimate, not a promised finish time; it calibrates from observed runtimes and can change with pilot retries, CPU load, exports and network operations.
- End-to-end launcher run completed four pilots and twelve full episodes; dataset manifest and training handoff were ready. A resume run reused all sixteen saved attempts with zero worker launches, and every saved training-array checksum remained unchanged.
- A backup-only run against a local bare Git test repository archived all sixteen attempts. The verified commit contained the ready dataset manifest, NN handoff and updated progress-code snapshot. No user GitHub repository was used for this local QA test.
