"""Four-task commands, with C2 timing and real prescribed shoulder yaw."""
import math,hashlib,json
import numpy as np
from complex_trajectories import smooth,reference,shoulder_reference

def yaw_reference(t,cfg):
 p=cfg['profile'];q0=p.get('yaw_start_deg',0.)
 if 'yaw_knots' not in p:return math.radians(q0),0.,0.
 x=(t-cfg['start_hold_s'])/cfg['time_scale'];knots=p['yaw_knots'];angles=p['yaw_angles'];D=p['duration']
 if x<=0 or x>=D:return math.radians(angles[0] if x<=0 else angles[-1]),0.,0.
 i=min(len(knots)-2,max(0,np.searchsorted(knots,x,side='right')-1));T=knots[i+1]-knots[i];a,b,c=smooth((x-knots[i])/T);d=angles[i+1]-angles[i];s=cfg['time_scale']
 return math.radians(angles[i]+d*a),math.radians(d*b/T)/s,math.radians(d*c/T**2)/s**2

def load_force_y(t,cfg):
 """Known smooth external downward force, distinct from dumbbell inertia."""
 p=cfg['profile'];x=(t-cfg['start_hold_s'])/cfg['time_scale'];v=0.
 for onset,duration,force in p.get('load_pulses',[]):
  if onset<=x<=onset+duration:
   u=(x-onset)/duration;v-=force*math.sin(math.pi*u)**4
 return v

def reference_digest(cfg):
 keys=['profile','time_scale','start_hold_s','end_hold_s','duration_s']
 return hashlib.sha256(json.dumps({k:cfg[k] for k in keys},sort_keys=True).encode()).hexdigest()
