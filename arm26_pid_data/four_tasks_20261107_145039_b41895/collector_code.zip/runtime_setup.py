"""Set process-local MKL policy before scientific imports; never suppress duplicate-runtime checks."""
import os
# Keep NumPy's MKL from loading its threaded OpenMP runtime beside PyTorch's.
os.environ['MKL_THREADING_LAYER']='SEQUENTIAL'
os.environ['MKL_NUM_THREADS']='1'
os.environ['OPENBLAS_NUM_THREADS']='1'

# Required by deterministic CUDA matrix multiplication in the training workers.
os.environ.setdefault('CUBLAS_WORKSPACE_CONFIG',':4096:8')
