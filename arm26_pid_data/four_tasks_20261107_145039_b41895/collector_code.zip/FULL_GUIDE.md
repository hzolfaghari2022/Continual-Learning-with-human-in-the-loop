# Four-task Arm26: collector + neural training + HTML/Overleaf

This package contains the two updated programs in separate folders. **Use a fresh four-task collection.** Its yaw-enabled model and 28-input contract differ from the older two/three-task datasets. Your old data and trained checkpoints are not overwritten.

## 1. Collect the new data

Extract the ZIP. Open PowerShell in the extracted `Arm26_Four_Task_Complete` folder:

```powershell
conda activate lstm-py312
python .\Collector\collect_four_tasks.py
```

| Task | Strength | What changes |
|---|---|---|
| A | 90% | Smooth up/down elbow reaches at fixed shoulder elevation |
| B | 60% | Irregular reversals and chirps at different speeds, with coordinated shoulder elevation |
| C | 30% | Actual lateral cross-body sweeps using added prescribed shoulder yaw; elbow stays approximately bent |
| D | 45% | Reach-and-hold movements with smooth, varying external downward force pulses up to 20 N |

D changes the interaction load during stationary holds, providing a different control demand from the continuous motions in A/B/C. The extra force is not an increase in the dumbbell's inertia. Actual dumbbell mass remains 5 kg.

**More data:** 640 full episodes, compared with 240 previously. Each task has 160 episodes: **112 train / 16 validation / 32 test**. Four starting elbow angles (50°, 60°, 70°, 80°), two variants, and 14/2/4 independent repetitions per condition. Sampling remains 0.005 s: approximately **2.69 million raw samples before any pilot speed reduction**. All collected timesteps are saved. Independent pilots are additional and excluded from training/validation/test.

Initial errors −2/0/+2° and velocities −15/0/+15°/s provide recovery examples. Two CPU workers collect independent episodes; per-episode plotting is disabled to reduce runtime. Full CSV, NPZ, state and settings files are still saved. Progress and ETA appear in the terminal; per-worker details stay in each episode's `console.log`. `--workers 1` runs sequentially. Do not change source/physics settings mid-collection.

Independent PID pilots must pass the quality checks before full collection. Pilots may reduce speed by predeclared factors 1/0.8/0.64; actual speeds remain recorded. Rejected episodes are retained and prevent training readiness. No neural tracking error selects data. The default teacher acceptance uses motion-window RMSE ≤0.1° and full-episode peak error ≤2.5°; the latter includes the intentional initial disturbance.

Data are saved under:

```text
C:\Users\hzlfghri\Arm26_Four_Task_PID_Data\four_tasks_...
```

Resume collection with the same original options plus `--resume`:

```powershell
python .\Collector\collect_four_tasks.py --resume
```

A metadata/trajectory preview without collection is available with `--plan-only`. After any preview, start the real collection normally; the trainer must select the real result folder, not an unfinished preview folder.

## What the lateral model does

The original Arm26 is planar. This version mounts that arm on an additional **prescribed yaw carrier** about the vertical axis at the shoulder. Proximal muscle attachments follow the carrier, preserving their original relative routing; torso display geometry remains fixed. Actual hand X/Y/Z are measured. C must physically cross the model's ground-Z body midline with at least 0.25 m lateral range to be accepted.

This is a simplified movement-plane extension for simulation, **not a validated anatomical 3D shoulder or torso-collision model**. Shoulder elevation/yaw are prescribed; the neural controller learns the elbow exosuit cable force under those motions. It does not independently learn or actuate shoulder yaw. Angle and Cartesian tracking errors are recorded separately. This model still has one independently controlled cable, `exo_flexor`.

## 2. Train with and without EWC

From the same extracted root folder:

```powershell
python .\Trainer\run_study.py
```

You may launch the trainer before collection finishes. It automatically selects the latest four-task result folder and waits until the full dataset and training handoff are ready. For a custom output location:

```powershell
python .\Trainer\run_study.py --collection "C:\Users\hzlfghri\Arm26_Four_Task_PID_Data\four_tasks_YOUR_RUN"
```

It trains **A → B → C → D**, comparing:

- A frozen initial A network on all tasks: the no-adaptation baseline.
- Ordinary sequential fine-tuning, without EWC or replay.
- EWC: protects A during B, A+B during C, and A+B+C during D.

Both branches share identical A initialization, architecture, optimizer resets, batch ordering and training budgets. Later each branch continues from its own preceding solution. Every training row is used each epoch. Original episode splits stay unchanged. All chosen checkpoints and the lambda decision are sealed before any held-out test arrays are opened. Testing never updates weights and has no PID force fallback.

Default CUDA selection is automatic. To require your GPU instead of allowing CPU fallback:

```powershell
python .\Trainer\run_study.py --device cuda
```

The terminal prints the actual training device. OpenSim physics uses CPU. Dependencies: your existing Python 3.12 `lstm-py312` environment, OpenSim 4.6, NumPy, Matplotlib, and CUDA-enabled PyTorch for training. The collector does not require PyTorch. The code does not change the installed environment automatically.

### Accuracy-oriented controller update

The new controller uses a **28-input context MLP, two 64-unit tanh layers, three internal heads, and one physical cable-force output** (6,211 parameters). The internal heads learn nominal force and nonnegative angle-error/velocity-error feedback gains:

```text
force_N = 650 * clip(
    sigmoid(head_nominal)
    + 0.05 * softplus(head_q) * encoded_angle_error
    + 0.05 * softplus(head_v) * encoded_velocity_error,
    0, 1
)
```

The context branch zeros the two error channels, then those errors enter the learned feedback computation explicitly. Both comparison branches use this same structure. It is a learned feedback controller; its gains are not fixed to the PID teacher's gains. This helps avoid relying entirely on a flat force regressor's extrapolation during recovery. It is not a proof of closed-loop stability, and final accuracy is measured rather than guaranteed. There is no recurrent hidden state.

Inputs 1–24 retain the previous mechanical, muscle, strength and feedback signals. Inputs 25–28 add yaw angle, yaw velocity, yaw acceleration and the known external vertical force. All channels, units and fixed scales are exported in `NETWORK_INPUT_OUTPUT.json` and explained in both reports. In NN tests, previous force is the NN's own last applied force. Internal muscle states/known external load would need sensing or estimation on hardware.

One physical output: cable tension in N, bounded to 0–650. Three internal heads do not mean three exosuits. Two independent learned cable commands require two actuator targets, which are not present in this dataset.

### EWC and lambda

Each earlier task stores the top 20% of scalar parameters: 1,243 selected indices, anchors and importance values per task. Importance uses training-only per-example squared raw normalized-output Jacobians, globally mean-normalized. No old examples are replayed. D uses three memories. Full normal network/optimizer checkpoints are separately saved for resume.

The loss is deployment-clipped normalized-force imitation MSE plus `lambda/(2P)` times the sum of selected importance-weighted squared parameter changes over previous tasks. The predeclared lambda grid is 1/10/100; 10 has no special universal value. One lambda is chosen for the entire sequence from validation errors over nine seen-task/stage combinations. New-task validation must stay within 1.2 times the corresponding no-EWC reference (floored at 0.1 N). If no candidate qualifies, that failure is reported. Tests never select lambda.

Defaults: 200 initial epochs, 120 adaptation epochs per later task/branch/candidate, Adam 0.001, batch 2048, 1,024 Fisher samples, seed 42. Use the original options plus `--resume` after interruption; completed training resumes/reuses checkpoints rather than starting again.

### Shorter physical testing, without changing the data split

Every original held-out episode is evaluated for force prediction. By default, physical closed-loop tests use **four trajectories per task**, selected from angle/variant metadata before training. Those same trajectories are reused across all controller comparisons. The default is 88 physical rollouts per seed, rather than 704 if every original test trajectory is simulated for every checkpoint.

This subset is disclosed in the reports; it is not chosen by tracking error. To simulate every held-out trajectory:

```powershell
python .\Trainer\run_study.py --test-episodes-per-task 0
```

Choose this option before starting a new study. Native OpenSim visualization opens only during final tests and reuses one window. For faster headless tests:

```powershell
python .\Trainer\run_study.py --no-test-viewer
```

Windows/Simbody visualization and CUDA require local verification. A viewer error preserves completed training; fix the viewer or resume with `--no-test-viewer`.

## Reports and backups

The collector and trainer each generate **HTML and Overleaf**:

| Program | HTML | Overleaf |
|---|---|---|
| Collector | `REPORT.html` | `COLLECTION_OVERLEAF.zip` |
| Trainer | `REPORT.html` | `OVERLEAF_REPORT.zip` |

The trainer's primary HTML embeds its two main figures and can be shared as a single file. The Overleaf article is approximately three pages with exactly two figures. Detailed learning/lambda/force/trajectory plots remain in `DETAILED_REPORT.html` and `plots/`; share that folder too if you want all diagnostics. Reports document actual completion/failures and do not assume a large EWC advantage.

Upload the Overleaf ZIP and compile `main.tex`. A local PDF is also generated when `pdflatex` is available. PDF compilation failures are logged while HTML and Overleaf source remain saved; they do not discard trained weights. A compact recovery exporter is attempted if normal neural report generation encounters another error.

Training results are saved under `C:\Users\hzlfghri\Arm26_Four_Task_MLP_Results\mlp_four_tasks_...`. Collector/trainer print their exact result folders.

GitHub remains configured for your existing repository. Separate branches/caches prevent interference with old runs: `arm26-four-task-data` for collection, `arm26-four-task-results` for training. Git and your credentials must work. Local results are preserved if backup fails. `--no-github` disables uploading. Retry a saved run with `--backup-only`; regenerate reports with `--report-only`, without training. Keep source/settings unchanged during a study.

## Recover the report from your already-run older trainer

Your message did not include the old error traceback, so its exact cause is still unknown. If the old run saved `TEST_RESULTS.json`, the following exports those saved results to HTML and Overleaf **without retraining, rerunning tests, or changing model weights**:

```powershell
python .\recover_previous_results.py --study "C:\Users\hzlfghri\Arm26_Three_Task_MLP_Results\YOUR_OLD_RESULT_FOLDER"
```

Use the actual printed result folder from the older run. Outputs are `RECOVERED_REPORT.html`, `RECOVERED_OVERLEAF.zip`, and a PDF if local compilation succeeds. Incomplete saved tests are explicitly labeled partial; missing tests are not invented. If `TEST_RESULTS.json` does not exist, the utility stops and asks for the actual traceback instead of treating training-only files as test results.

## Verification command

```powershell
python .\tests\test_four_task.py -v
```

See `VALIDATION.md` for performed checks and the limits of the small local validation run.

`Example_Report/` contains visibly labeled HTML/Overleaf/PDF format checks from the small validation run. They are not results from your full dataset. Your actual programs generate their own reports.
