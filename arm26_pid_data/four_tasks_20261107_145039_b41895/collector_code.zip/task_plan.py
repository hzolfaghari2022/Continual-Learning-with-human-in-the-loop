"""A/B/C/D collection plan. Conditions and seeds are fixed before NN training."""
import hashlib,itertools
import numpy as np
from complex_trajectories import make_profile,configure,speed_statistics
from four_trajectories import reference_digest
TASKS={
 'A_90':dict(order=1,name='Vertical up/down reaches',strength_scale=.9,requested_speed=.85),
 'B_60':dict(order=2,name='Irregular variable-speed reversals',strength_scale=.6,requested_speed=1.2),
 'C_30':dict(order=3,name='Cross-body lateral sweeps',strength_scale=.3,requested_speed=.8),
 'D_45':dict(order=4,name='Reach-hold under external load pulses',strength_scale=.45,requested_speed=1.)}

def seed_for(seed,key):return int(hashlib.sha256((str(seed)+'/'+key).encode()).hexdigest()[:8],16)
def conditions(args):return [dict(task_id=t,variant=v,start_deg=q,key=f'{t}_{v}_e{q:g}'.replace('.','p')) for t,v,q in itertools.product(args.tasks,args.variants,args.initial_angles)]
def pilot_recoveries(args):return sorted(set([(min(args.initial_errors),min(args.initial_velocities)),(max(args.initial_errors),max(args.initial_velocities))]))
def make_episode(args,condition,split,rep,factor=1.,pilot=False,recovery=None):
 tid=condition['task_id'];task=TASKS[tid];variant=condition['variant'];start=condition['start_deg'];key=condition['key'];mid=f'{key}_{split}_{rep:02d}';seed=seed_for(args.seed,mid);rng=np.random.default_rng(seed)
 if recovery is None:
  k=rep if split=='train' else seed_for(args.seed,key+'/'+split+'/recovery')+rep
  recovery=(args.initial_errors[k%len(args.initial_errors)],args.initial_velocities[(k+k//len(args.initial_errors))%len(args.initial_velocities)])
 family='baseline_smooth' if tid in ('A_90','C_30','D_45') else ('variable_speed' if variant=='A' else 'chirp')
 profile=make_profile(family,seed,start,'fixed' if tid!='B_60' else 'moving',pilot=pilot);profile['yaw_start_deg']=0.
 if tid=='A_90':profile.update(shoulder_start_deg=(-5. if variant=='A' else 10.))
 if tid=='B_60':profile.update(shoulder_start_deg=2.5,shoulder_elbow_gain=.2 if variant=='A' else -.2)
 if tid=='C_30':
  # Almost fixed elbow posture with a genuine yaw-driven lateral sweep.
  amp=float(rng.uniform(3.,6.));direction=1 if variant=='A' else -1
  profile.update(duration=18.,knots=[0.,6.,12.,18.],angles=[start,start+amp,start-amp,start],shoulder_start_deg=5.,yaw_start_deg=-65.*direction,yaw_knots=[0.,6.,12.,18.],yaw_angles=[-65.*direction,65.*direction,-65.*direction,-65.*direction])
 if tid=='D_45':
  # Piecewise C2 reaches with long stationary intervals and changing external load.
  target=float(rng.uniform(75.,90.));low=float(rng.uniform(35.,45.))
  profile.update(duration=20.,knots=[0.,3.,7.,10.,14.,17.,20.],angles=[start,target,target,low,low,start,start],shoulder_start_deg=-5.,yaw_start_deg=15. if variant=='A' else -15.,load_pulses=[[3.2,3.4,float(rng.uniform(9.,15.))],[10.2,3.4,float(rng.uniform(12.,20.))],[17.2,2.5,float(rng.uniform(6.,12.))]])
 cfg=dict(format_version=4,task_id=tid,task_name=task['name'],task_order=task['order'],episode_id=mid,motion_id=mid,condition=key,split=split,trajectory=family,variant=variant,mass_kg=args.mass_kg,strength_scale=task['strength_scale'],profile=profile,start_hold_s=2.,end_hold_s=1.,dt_s=args.dt,initial_offset_deg=float(recovery[0]),initial_velocity_deg_s=float(recovery[1]),muscle_excitation=args.muscle_excitation,force_cap_N=650.,accel_kp=120.,accel_kd=22.,accel_ki=15.,integral_limit_rad_s=.15,integrator_accuracy=1e-5,accept_rmse_deg=args.rmse_limit,accept_max_error_deg=args.max_error_limit,live_viewer=False,save_plots=False,requested_speed_scale=task['requested_speed'])
 configure(cfg,task['requested_speed']*factor);cfg['reference_sha256']=reference_digest(cfg)
 return cfg

def full_plan(args):return [make_episode(args,c,s,r) for c in conditions(args) for s,n in [('train',args.train_reps),('validation',args.validation_reps),('test',args.test_reps)] for r in range(n)]
def counts(plan):return {t:{s:sum(c['task_id']==t and c['split']==s for c in plan) for s in ('train','validation','test')} for t in TASKS if any(c['task_id']==t for c in plan)}
