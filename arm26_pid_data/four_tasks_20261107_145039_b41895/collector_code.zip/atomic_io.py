"""Atomic JSON writes with bounded retries for Windows sharing violations."""
import json,os,tempfile,time
from pathlib import Path

def atomic_json(path,data,attempts=8):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    payload=json.dumps(data,indent=2,allow_nan=False)
    fd,name=tempfile.mkstemp(prefix=path.name+'.',suffix='.tmp',dir=path.parent)
    tmp=Path(name)
    try:
        with os.fdopen(fd,'w',encoding='utf-8') as stream:stream.write(payload)
        for attempt in range(attempts):
            try:os.replace(tmp,path);return
            except OSError as exc:
                transient=isinstance(exc,PermissionError) or getattr(exc,'winerror',None) in (5,32,33)
                if not transient or attempt==attempts-1:raise
                time.sleep(min(.025*2**attempt,.4))
    finally:
        try:tmp.unlink(missing_ok=True)
        except OSError:pass

_last_warning={}
def progress_json(path,data):
    try:atomic_json(path,data,attempts=4)
    except OSError as exc:
        key=str(path);now=time.monotonic()
        if now-_last_warning.get(key,-1e9)>60:
            print('PROGRESS FILE WARNING (simulation continues): '+str(exc),flush=True);_last_warning[key]=now

def patch_progress(module):
    module.write=progress_json
    original=module.Progress.refresh
    if getattr(original,'_io_safe',False):return
    def refresh(self,*args,**kwargs):
        try:return original(self,*args,**kwargs)
        except OSError as exc:
            now=time.monotonic()
            if now-getattr(self,'_io_warning_at',-1e9)>60:
                print('PROGRESS DISPLAY WARNING (simulation continues): '+str(exc),flush=True);self._io_warning_at=now
    refresh._io_safe=True
    module.Progress.refresh=refresh

def atomic_bytes(path,payload,attempts=8):
    """Publish a complete, flushed binary payload under its final name."""
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    fd,name=tempfile.mkstemp(prefix=path.name+'.',suffix='.tmp',dir=path.parent);tmp=Path(name)
    try:
        with os.fdopen(fd,'wb') as stream:
            stream.write(payload);stream.flush();os.fsync(stream.fileno())
        for attempt in range(attempts):
            try:os.replace(tmp,path);return
            except OSError as exc:
                transient=isinstance(exc,PermissionError) or getattr(exc,'winerror',None) in (5,32,33)
                if not transient or attempt==attempts-1:raise
                time.sleep(min(.025*2**attempt,.4))
    finally:
        try:tmp.unlink(missing_ok=True)
        except OSError:pass
