# Recovery validation — 2026-11-07

- Eleven automated checks passed: exit-code/log diagnostics, bounded retries, recognized startup failure, checksum-error propagation, allowed quality-failure exit code, progress/ETA, read-only monitoring, code capture and original source/model hashes.
- Ran the reported episode identity `B_60_A_e50_train_13` with the packaged default configuration using OpenSim. Completed and accepted; elbow tracking RMSE 0.01148 degrees. This validates that default local case, not the cause of the Windows process exit or a customized pilot speed.
- Injected a real subprocess termination (exit 23) before that same OpenSim worker. One retry succeeded with identical settings. The prior console log was preserved in interrupted_attempts and WORKER_FAILURES.json recorded the exit.
- Resumed an existing collection containing four pilot attempts and twelve full episodes. All sixteen saved attempts were reused; zero simulation workers launched. Existing training-array SHA-256 hashes stayed identical; dataset remained ready for training.
- Backup-only verification used a local bare Git remote, not the user's GitHub repository. The launcher's GitHub backup remains enabled by default and reports actual success/failure.
- Root collector Python files and model remain byte-identical to the previous package, preserving existing source locks. Recovery code lives under progress/ with explicit runtime provenance.

Limits: tests ran on Linux with available OpenSim. The original Windows worker console.log was not supplied; its underlying failure cannot be diagnosed from the generic parent traceback. Recovery is bounded and does not guarantee success for a persistently failing worker. No trajectory, PID, quality threshold or split was relaxed.
