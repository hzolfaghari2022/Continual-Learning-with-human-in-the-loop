# Four-task DATA COLLECTION

Extract this ZIP into its own folder. Open PowerShell in this folder, activate your existing environment and run:

```powershell
conda activate lstm-py312
python .\collect_four_tasks.py
```

Collects 640 episodes for A90/B60/C30/D45, using two workers. Saves under your user profile in `Arm26_Four_Task_PID_Data`. Keep this source unchanged during collection. Resume with `python .\collect_four_tasks.py --resume`. HTML and Overleaf reports are generated automatically.

The model uses prescribed shoulder elevation/yaw and one learned elbow cable-force output. The yaw carrier is a simplified movement-plane extension.

`FULL_GUIDE.md` describes the combined original package. In this standalone ZIP, omit `Collector\` or `Trainer\` from its command examples, and use the direct filenames shown above. Its original parent-folder test command is not included in this split package; performed verification is described in `VALIDATION.md`.
