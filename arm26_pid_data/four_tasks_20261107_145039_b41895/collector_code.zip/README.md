# Four-task collector: worker recovery and organized progress

This update adds worker recovery and better failure diagnostics to the progress launcher. The original collector, model, trajectories, sample counts, quality limits, data files and train/validation/test splits are unchanged. Your neural-network trainer remains compatible.

## Resume your interrupted collection (do this first)

Extract this package to a short folder such as `C:\Arm26_Collector`, open PowerShell in the folder containing `collect_four_tasks.py`, then run:

```powershell
conda activate lstm-py312
python .\progress\collect_with_progress.py --resume --workers 1 --run-folder "C:\Users\hzlfghri\Arm26_Four_Task_PID_Data\four_tasks_20261107_145039_b41895"
```

Keep that existing data folder. Completed episodes are checked and reused. Only unfinished/operationally failed work is rerun; previous partial attempts are retained under `interrupted_attempts`. If you originally changed collection options, repeat those options when resuming. A source/settings mismatch stops safely instead of mixing datasets.

The old traceback reports an unexpected worker exit, but omits the actual exit code and worker error. It cannot establish the underlying cause. This launcher now prints the exit code (including Windows exception code), failing folder and last worker output. It records failures in `WORKER_FAILURES.json` and operational provenance in `RUNTIME_RECOVERY.json`.

Unexpected worker exits/timeouts are retried with identical settings, up to **three attempts total**. Missing dependencies and other recognized startup errors stop immediately. Explicit transient export/sharing errors can also retry. Quality failures and corrupted saved arrays are not turned into accepted data. After a persistent failure, queued episodes are cancelled, active episodes finish, and a best-effort backup of completed work runs if GitHub is enabled.

Collection defaults to **one worker**, with one native math thread per worker. You may explicitly request more workers, but one is recommended for recovery. This reduces concurrency pressure; it is not a diagnosis of the original failure. Use **the progress launcher above**: running `python collect_four_tasks.py` directly bypasses these recovery changes.

## Start collection with the new display

Extract this ZIP, open PowerShell in its extracted folder, and run:

```powershell
conda activate lstm-py312
python .\progress\collect_with_progress.py
```

The display shows:

- Local start time, elapsed time, estimated remaining time and expected finish date/time.
- Completed/remaining episodes (iterations), completion percentage and accepted counts.
- Pilot conditions and attempts, saved sample counts, and train/validation/test totals for A/B/C/D.
- Each active worker's episode, simulated time and percentage.
- GitHub backup status/verified commit, training readiness, data folder and full terminal log.

Compatible terminals refresh one organized screen. Other terminals print periodic snapshots. `--plain` forces snapshots. The initial estimate calibrates after a completed episode; later estimates use measured episode runtimes, remaining trajectory durations, worker count and observed backup times. Pilot retries, final report generation and network delays can extend the estimate. GitHub/report stages are displayed separately instead of pretending the run is stuck at 100%.

The usual collector options pass through unchanged, for example:

```powershell
python .\progress\collect_with_progress.py --workers 1
python .\progress\collect_with_progress.py --resume
```

For a resumed run with custom collection settings, repeat those original settings. In a newly extracted folder without a pointer file, the launcher finds the newest four-task result folder; specify `--run-folder` to choose a different one explicitly. Existing completed episodes are verified/reused by the original collector, not regenerated. Saved counts include earlier sessions.

## Watch a collection that is already running

**Do not restart it just for the terminal display.** Open a second PowerShell window in this extracted folder and run:

```powershell
conda activate lstm-py312
python .\progress\collect_with_progress.py --watch "C:\Users\hzlfghri\Arm26_Four_Task_PID_Data\four_tasks_YOUR_RUN"
```

Use the actual printed result folder containing `COLLECTION.json`. Watch mode only reads progress/status files: it does not stop, alter or restart the running collector. Ctrl+C stops the watch window only. `--once --plain` prints a single snapshot.

## GitHub and saved neural-network data

GitHub backup stays **enabled by default** for your existing repository and `arm26-four-task-data` branch. The original collector uploads/verifies code, pilot/full-episode archives and metadata during collection and at completion. The launcher also saves `TERMINAL_PROGRESS_CODE.zip` in the result folder; the original backup includes this complete updated code snapshot in its collection metadata. Separate caches/branches are preserved.

All collected data remain saved locally under your user profile in `Arm26_Four_Task_PID_Data`. Final `DATASET_MANIFEST.json` and `TRAINING_HANDOFF.json` still control readiness for your existing NN trainer. The dashboard does not open or rewrite training arrays. The launcher writes progress/recovery metadata, logs and a code snapshot; the original collector verifies and exports episodes. Read-only watch mode writes nothing.

The dashboard reports GitHub's actual status. A failed upload is not called successful: local data remain saved, and you can retry with:

```powershell
python .\progress\collect_with_progress.py --backup-only --run-folder "C:\path\to\four_tasks_YOUR_RUN"
```

Git and your existing credentials must work. If you explicitly pass `--no-github`, the dashboard labels uploading disabled. Watch mode does not change the backup behavior of the original running process.

## Reports, logs and original command

Both HTML and Overleaf reports are still generated at completion. Your full original terminal output is retained under `terminal_logs/` in the result folder. The original direct command `python collect_four_tasks.py` is still available, with its old text output. Use the new progress launcher for recovery and the organized display.

No new root-level Python file changes the collector's source-hash lock; all monitoring code lives under `progress/`. This lets the update monitor or resume compatible existing runs without changing their physics or collection protocol.

`FULL_GUIDE.md` retains the original experiment/data instructions. `PROGRESS_UPDATE_VALIDATION.md` documents the monitoring checks.

`RECOVERY_VALIDATION.md` records recovery, resume and data-integrity checks. Local tests used Linux/OpenSim; the original Windows failure was not reproduced. If a worker still fails, send `WORKER_FAILURES.json` or the failing episode’s `console.log`.
