"""Brief collector HTML and Overleaf reports with task and hand-path evidence."""
from pathlib import Path
import csv,html,io,shutil
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from complex_engine import read,write
from complex_trajectories import reference
from four_trajectories import yaw_reference,load_force_y
from atomic_io import atomic_bytes
from task_plan import TASKS
from report_support import compile_and_zip

def tex(s):
 s=str(s)
 for a,b in [('\\',r'\textbackslash{}'),('_',r'\_'),('%',r'\%'),('&',r'\&')]:s=s.replace(a,b)
 return s

def save(fig,folder,name):
 folder=Path(folder);folder.mkdir(parents=True,exist_ok=True);fig.tight_layout()
 for ext in ('png','pdf'):
  b=io.BytesIO();fig.savefig(b,format=ext,dpi=145,bbox_inches='tight');atomic_bytes(folder/(name+'.'+ext),b.getvalue())
 plt.close(fig)

def preview(out,plan):
 fig,axs=plt.subplots(4,2,figsize=(10,8))
 for i,tid in enumerate(TASKS):
  rr=[c for c in plan if c['task_id']==tid and c['split']=='train']
  if not rr:continue
  c=sorted(rr,key=lambda c:c['episode_id'])[0];ts=np.linspace(0,c['duration_s'],600);axs[i,0].plot(ts,np.degrees([reference(t,c)[0] for t in ts]));axs[i,0].set(ylabel=tid+' elbow (deg)');axs[i,1].plot(ts,np.degrees([yaw_reference(t,c)[0] for t in ts]),label='Yaw (deg)');axs[i,1].plot(ts,[load_force_y(t,c) for t in ts],label='External Fy (N)');axs[i,1].legend(fontsize=7)
 for ax in axs.flat:ax.grid(alpha=.2);ax.set_xlabel('Time (s)')
 save(fig,Path(out)/'plots','reference_preview')

def build_report(out):
 out=Path(out);manifest=read(out/'DATASET_MANIFEST.json') if (out/'DATASET_MANIFEST.json').exists() else {'records':[]};records=manifest['records'];plots=out/'plots';plots.mkdir(exist_ok=True);report=out/'collection_overleaf';report.mkdir(exist_ok=True);figs=report/'figures';figs.mkdir(exist_ok=True)
 summary=[]
 for task in TASKS:
  for sp in ('train','validation','test'):
   rr=[r for r in records if r['task_id']==task and r['split']==sp];summary.append(dict(task=task,split=sp,episodes=len(rr),accepted=sum(r['accepted'] for r in rr),samples=sum(r['samples'] for r in rr if r['accepted'])))
 write(out/'DATA_COUNTS.json',summary)
 with (out/'PID_DATA_QUALITY.csv').open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=['task_id','episode_id','split','accepted','motion_rmse_deg','samples','crossed_body_midline','lateral_hand_range_m'],extrasaction='ignore');w.writeheader();w.writerows(records)
 selected={}
 for task in TASKS:
  candidates=sorted([r for r in records if r['task_id']==task and r['split']=='validation'],key=lambda r:r['episode_id'])
  selected[task]=candidates[0] if candidates else None
 fig=plt.figure(figsize=(10,7));fig2,axs=plt.subplots(4,1,figsize=(10,7),sharex=False)
 for i,task in enumerate(TASKS):
  ax=fig.add_subplot(2,2,i+1,projection='3d');r=selected[task]
  if r:
   with (Path(r['folder'])/'signals.csv').open() as f:trace=list(csv.DictReader(f))
   ax.plot([float(x['hand_x_m']) for x in trace],[float(x['hand_z_m']) for x in trace],[float(x['hand_y_m']) for x in trace]);ax.set(title=task,xlabel='Forward X (m)',ylabel='Lateral Z (m)',zlabel='Height Y (m)');axs[i].plot([float(x['time_s']) for x in trace],[float(x['error_deg']) for x in trace]);axs[i].set(ylabel=task+' error (deg)',xlabel='Time (s)');axs[i].grid(alpha=.2)
  else:ax.set_title(task+' no validation trace yet')
 save(fig,plots,'actual_hand_paths');save(fig2,plots,'pid_tracking_errors')
 for n in ('actual_hand_paths','pid_tracking_errors'):shutil.copy2(plots/(n+'.pdf'),figs/(n+'.pdf'))
 body=r'''\documentclass[10pt]{article}
\usepackage[margin=.75in]{geometry}\usepackage{graphicx,booktabs,hyperref}
\setlength{\parindent}{0pt}\setlength{\parskip}{5pt}\begin{document}
\begin{center}\Large\textbf{Arm26: Four-task PID data collection}\end{center}
\textbf{Design.} A: 90\% strength, fixed-shoulder up/down reaches. B: 60\%, irregular reversals/chirps with varying speed and coordinated shoulder elevation. C: 30\%, cross-body lateral sweeps driven by prescribed shoulder yaw with a nearly fixed bent elbow. D: 45\%, reach-and-hold with smooth external downward force pulses (up to 20 N). D changes the interaction load, not the actual dumbbell mass.

\textbf{Model scope.} The original planar Arm26 is mounted on a prescribed yaw carrier; proximal muscle attachment points follow that carrier so their original relative routing is retained. Actual hand X/Y/Z are recorded. This is a simplified movement-plane extension, not a validated anatomical three-dimensional shoulder or collision model. Shoulder elevation/yaw are prescribed; one exosuit cable supplies learned elbow assistance in the later experiment. Cross-body geometry is not evidence of an NN learning shoulder control. C acceptance requires an actual ground-Z midline crossing and at least 0.25 m lateral range.

\textbf{More data and quality.} The default has 640 full episodes: 160 per task, with 112 training, 16 validation and 32 test episodes. Each task uses four initial elbow angles, two variants, and 14/2/4 independent repetitions per condition. Initial errors of -2/0/+2 degrees and velocities of -15/0/+15 degrees/s supply recovery examples. All timesteps are retained at 0.005 s sampling. Two CPU workers run separate OpenSim episodes; this changes elapsed time, not physics or sample counts. PID pilots choose a feasible speed before the full plan is frozen; failures remain visible. NN results never select the data.

\textbf{Inputs/output handoff.} The collector exports 28 inputs: the previous 24 mechanical/muscle/feedback signals plus yaw angle/velocity/acceleration and known external vertical force. The output target is one cable tension in N (0--650). Each completed episode has CSV, NumPy arrays, state files, settings, force-capacity audit and checksums. The original 70/10/20 split is by whole episode, with pilots excluded. No final test episode is moved into training.

\small\begin{center}\begin{tabular}{llrrr}\toprule Task & Split & Episodes & Accepted & Samples\\\midrule
ROWS
\bottomrule\end{tabular}\end{center}\normalsize
Ready for training: READY. Only accepted completed full episodes qualify. Demonstration quality is not neural tracking accuracy or evidence of EWC benefit. Validation examples below are chosen by identifier, not their error.\newpage
\begin{center}\includegraphics[width=.95\linewidth,height=4.6in,keepaspectratio]{figures/actual_hand_paths.pdf}\end{center}
Actual hand paths: forward X, lateral Z, vertical Y. C moves across the body's Z=0 midline.
\begin{center}\includegraphics[width=.95\linewidth,height=3.7in,keepaspectratio]{figures/pid_tracking_errors.pdf}\end{center}
Measured PID validation error; full diagnostics remain in the saved data.\end{document}
'''
 table='\n'.join(tex(r['task'])+' & '+tex(r['split'])+' & '+str(r['episodes'])+' & '+str(r['accepted'])+' & '+str(r['samples'])+' '+chr(92)*2 for r in summary);body=body.replace('ROWS',table).replace('READY',tex(str(manifest.get('ready_for_training',False))));(report/'main.tex').write_text(body)
 page='<html><meta charset="utf-8"><style>body{max-width:1000px;margin:40px auto;font:17px Georgia}img{max-width:100%}</style><h1>Four-task data collection</h1><p>Readiness: '+str(manifest.get('ready_for_training',False))+'</p><pre>'+html.escape(str(summary))+'</pre>'
 for n in ('reference_preview','actual_hand_paths','pid_tracking_errors'):
  if (plots/(n+'.png')).exists():
   import base64
   page+='<figure><img src="data:image/png;base64,'+base64.b64encode((plots/(n+'.png')).read_bytes()).decode()+'"></figure>'
 (out/'REPORT.html').write_text(page+'</html>');compile_and_zip(report,out,'COLLECTION_OVERLEAF.zip');print('COLLECTOR REPORTS SAVED:',out/'REPORT.html',out/'COLLECTION_OVERLEAF.zip',flush=True)
