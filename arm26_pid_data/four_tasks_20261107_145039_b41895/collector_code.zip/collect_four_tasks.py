"""Four-task accurate PID collection: larger dataset, resumable two-worker batches."""
import runtime_setup
import argparse,copy,json,math,os,shutil,sys,time,uuid
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor,as_completed
from complex_engine import ROOT,read,write,sha
from complex_trajectories import FEATURES,SCALES,configure
from four_trajectories import reference_digest
from task_plan import TASKS,conditions,full_plan,counts,make_episode,pilot_recoveries
from episode_io import execute
REPO='https://github.com/hzolfaghari2022/Continual-Learning-with-human-in-the-loop.git'

def main():
 p=argparse.ArgumentParser(description=__doc__)
 p.add_argument('--output-root',type=Path,default=Path.home()/'Arm26_Four_Task_PID_Data');p.add_argument('--run-folder',type=Path);p.add_argument('--resume',action='store_true');p.add_argument('--plan-only',action='store_true');p.add_argument('--pilot-only',action='store_true');p.add_argument('--report-only',action='store_true');p.add_argument('--backup-only',action='store_true')
 p.add_argument('--tasks',nargs='+',choices=list(TASKS),default=list(TASKS));p.add_argument('--variants',nargs='+',choices=['A','B'],default=['A','B']);p.add_argument('--initial-angles',nargs='+',type=float,default=[50.,60.,70.,80.]);p.add_argument('--train-reps',type=int,default=14);p.add_argument('--validation-reps',type=int,default=2);p.add_argument('--test-reps',type=int,default=4)
 p.add_argument('--initial-errors',nargs='+',type=float,default=[-2.,0.,2.]);p.add_argument('--initial-velocities',nargs='+',type=float,default=[-15.,0.,15.]);p.add_argument('--dt',type=float,default=.005);p.add_argument('--mass-kg',type=float,default=5.);p.add_argument('--muscle-excitation',type=float,default=.1);p.add_argument('--seed',type=int,default=2026110704);p.add_argument('--workers',type=int,default=2);p.add_argument('--batch-episodes',type=int,default=32);p.add_argument('--episode-timeout',type=float,default=600.);p.add_argument('--rmse-limit',type=float,default=.1);p.add_argument('--max-error-limit',type=float,default=2.5)
 p.add_argument('--no-github',action='store_true');p.add_argument('--github-repo',default=REPO);p.add_argument('--github-branch',default='arm26-four-task-data');a=p.parse_args()
 if min(a.train_reps,a.validation_reps,a.test_reps,a.workers,a.batch_episodes)<1:p.error('Counts must be positive.')
 for values in (a.tasks,a.variants,a.initial_angles,a.initial_errors,a.initial_velocities):
  if len(set(values))!=len(values):p.error('Duplicate plan entries.')
 if not all(math.isfinite(v) and 45<=v<=85 for v in a.initial_angles) or not all(math.isfinite(v) and abs(v)<=2 for v in a.initial_errors) or not all(math.isfinite(v) and abs(v)<=15 for v in a.initial_velocities) or not .001<=a.dt<=.02 or not 0<=a.mass_kg<=5 or not 0<a.muscle_excitation<=.15 or a.max_error_limit<max(abs(v) for v in a.initial_errors):p.error('Use reviewed ranges: angles45..85, errors<=2deg, speeds<=15deg/s, dt.001...02, mass<=5kg.')
 pointer=ROOT/'LATEST_COLLECTION.txt';out=(a.run_folder or (Path(pointer.read_text().strip()) if (a.resume or a.report_only or a.backup_only) and pointer.exists() else a.output_root/('four_tasks_'+time.strftime('%Y%m%d_%H%M%S')+'_'+uuid.uuid4().hex[:6]))).resolve()
 if a.report_only:
  from task_report import build_report
  build_report(out);return 0
 if a.backup_only:
  from github_backup import GitBackup
  GitBackup(a.github_repo,out,a.github_branch,Path.home()/'Arm26_FourTask_Collector_Cache'/out.name).sync(ROOT);return 0
 out.mkdir(parents=True,exist_ok=True);excluded={'output_root','run_folder','resume','plan_only','pilot_only','report_only','backup_only','workers','batch_episodes','no_github','github_repo','github_branch'}
 config={k:v for k,v in vars(a).items() if k not in excluded};config['task_definitions']=TASKS;config['source_hashes']={f.name:sha(f) for f in ROOT.glob('*.py')};config['model_sha256']=sha(ROOT/'arm26_exosuit.osim')
 if (out/'COLLECTION.json').exists() and read(out/'COLLECTION.json')['config']!=config:raise ValueError('Collection/source settings changed. Resume with original settings or start a new collection.')
 write(out/'COLLECTION.json',dict(format_version=4,protocol='four_tasks_yaw_load_v1',config=config,features=FEATURES));pointer.write_text(str(out));plan=full_plan(a);write(out/'UNSCALED_PLAN.json',plan);write(out/'WORKLOAD.json',dict(full_episodes=len(plan),counts=counts(plan),minimum_pilots=len(conditions(a))*len(pilot_recoveries(a)),workers=a.workers))
 print('FOUR-TASK DATA FOLDER:',out,'\nFULL EPISODES:',len(plan),'| workers:',a.workers,'| original splits:',counts(plan),flush=True)
 from task_report import preview
 preview(out,plan)
 if a.plan_only:return 0
 snapshot=out/'source';snapshot.mkdir(exist_ok=True)
 for file in list(ROOT.glob('*.py'))+[ROOT/'arm26_exosuit.osim']:
  if not (snapshot/file.name).exists():shutil.copy2(file,snapshot/file.name)
 if not (snapshot/'Geometry').exists():shutil.copytree(ROOT/'Geometry',snapshot/'Geometry')
 backup=None
 def sync(status=None):
  if backup is not None:
   try:backup.sync(ROOT,final_status=status)
   except Exception as exc:print('BACKUP WARNING; collection continues locally. Retry --backup-only:',exc,flush=True)
 if not a.no_github:
  try:
   from github_backup import GitBackup
   backup=GitBackup(a.github_repo,out,a.github_branch,Path.home()/'Arm26_FourTask_Collector_Cache'/out.name);sync()
  except Exception as exc:write(out/'GITHUB_STATUS.json',dict(status='failed',error=str(exc)));print('BACKUP WARNING; collection continues locally:',exc,flush=True)
 cp=out/'PILOT_CALIBRATION.json';cal=read(cp) if cp.exists() else {};recoveries=pilot_recoveries(a)
 def pilot(c):
  if c['key'] in cal and cal[c['key']].get('selected_factor') is not None:
   # Re-run execute's integrity checks on existing attempts before reuse.
   chosen=cal[c['key']]['selected_factor'];ok=True
   for i,rec in enumerate(recoveries):
    cfg=make_episode(a,c,'pilot',i,chosen,pilot=True,recovery=rec);folder=out/'pilot'/c['task_id']/c['key']/('factor_'+format(chosen,'.8g'))/str(i);ok &= execute(cfg,folder,a.episode_timeout)['accepted_for_imitation']
   if ok:return c['key'],cal[c['key']]
  attempts=[]
  for factor in (1.,.8,.64):
   passed=True
   for i,rec in enumerate(recoveries):
    cfg=make_episode(a,c,'pilot',i,factor,pilot=True,recovery=rec);folder=out/'pilot'/c['task_id']/c['key']/('factor_'+format(factor,'.8g'))/str(i);r=execute(cfg,folder,a.episode_timeout);passed &= r['accepted_for_imitation'];attempts.append(dict(factor=factor,recovery=list(rec),folder=str(folder),accepted=r['accepted_for_imitation']))
   if passed:return c['key'],dict(selected_factor=factor,attempts=attempts)
  return c['key'],dict(selected_factor=None,attempts=attempts)
 with ThreadPoolExecutor(max_workers=a.workers) as pool:
  jobs=[pool.submit(pilot,c) for c in conditions(a)]
  for future in as_completed(jobs):
   key,value=future.result();cal[key]=value;write(cp,cal);print('PILOT CONDITIONS COMPLETE:',len(cal),'/',len(jobs),flush=True)
 sync()
 if any(v['selected_factor'] is None for v in cal.values()):write(out/'COLLECTION_STATUS.json',dict(status='pilot_failed',ready_for_training=False));raise RuntimeError('A PID pilot failed. Existing traces are preserved; full collection did not start.')
 if a.pilot_only:print('PILOTS COMPLETE; resume without --pilot-only for full data.');return 0
 final=[]
 for c in plan:
  configure(c,c['requested_speed_scale']*cal[c['condition']]['selected_factor']);c['reference_sha256']=reference_digest(c);final.append(c)
 write(out/'FROZEN_PLAN.json',final);records=[];started=time.monotonic()
 def run(cfg):
  folder=out/'tasks'/cfg['task_id']/('strength_'+str(round(cfg['strength_scale']*100)))/cfg['episode_id'];r=execute(cfg,folder,a.episode_timeout)
  return dict(task_id=cfg['task_id'],task_name=cfg['task_name'],task_order=cfg['task_order'],strength_scale=cfg['strength_scale'],episode_id=cfg['episode_id'],motion_id=cfg['motion_id'],condition=cfg['condition'],split=cfg['split'],variant=cfg['variant'],trajectory=cfg['trajectory'],folder=str(folder),reference_sha256=cfg['reference_sha256'],arrays_sha256=sha(folder/'training_arrays.npz') if (folder/'training_arrays.npz').exists() else None,samples=r['sample_count'],status=r['status'],accepted=r['accepted_for_imitation'],motion_rmse_deg=(r.get('motion_only') or {}).get('rmse_deg'),requested_speed_scale=cfg['requested_speed_scale'],selected_speed_scale=cfg['speed_scale'],crossed_body_midline=r.get('crossed_body_midline'),lateral_hand_range_m=r.get('lateral_hand_range_m'))
 for offset in range(0,len(final),a.batch_episodes):
  batch=final[offset:offset+a.batch_episodes]
  with ThreadPoolExecutor(max_workers=a.workers) as pool:
   jobs=[pool.submit(run,cfg) for cfg in batch]
   for future in as_completed(jobs):
    records.append(future.result());ordered=sorted(records,key=lambda r:(r['task_order'],r['episode_id']));write(out/'DATASET_MANIFEST.json',dict(format_version=4,protocol='four_tasks_yaw_load_v1',features=FEATURES,records=ordered,complete=False,ready_for_training=False))
    elapsed=time.monotonic()-started;print(f'FULL {len(records)}/{len(final)} | accepted {sum(r["accepted"] for r in records)} | ETA {elapsed/max(1,len(records))*(len(final)-len(records))/60:.1f} min',flush=True)
    write(out/'PROGRESS.json',dict(stage='full',completed=len(records),planned=len(final),accepted=sum(r['accepted'] for r in records),elapsed_seconds=elapsed))
  sync()
 records=sorted(records,key=lambda r:(r['task_order'],r['episode_id']));ready=len(records)==len(final) and all(r['accepted'] for r in records)
 write(out/'DATASET_MANIFEST.json',dict(format_version=4,protocol='four_tasks_yaw_load_v1',features=FEATURES,records=records,complete=True,ready_for_training=ready,planned_counts=counts(final)))
 write(out/'TRAINING_HANDOFF.json',dict(protocol='four_tasks_yaw_load_v1',ready_for_training=ready,task_order=list(a.tasks),features=FEATURES,scales=SCALES.tolist(),encoding='four_task_feedback_v1',target='y_force_N',target_scale_N=650.,model_scope='Elbow cable learned; shoulder elevation and added yaw prescribed. Simplified 3D extension, not full anatomical shoulder or collision model.'))
 write(out/'COLLECTION_STATUS.json',dict(status='complete' if ready else 'complete_with_rejections',ready_for_training=ready,full_episodes=len(records),accepted=sum(r['accepted'] for r in records)))
 from task_report import build_report
 build_report(out);sync('complete' if ready else 'complete_with_rejections');print('COLLECTION FINISHED | ready:',ready,'| HTML:',out/'REPORT.html','| Overleaf:',out/'COLLECTION_OVERLEAF.zip',flush=True);return 0 if ready else 2
if __name__=='__main__':
 try:raise SystemExit(main())
 except KeyboardInterrupt:print('Interrupted. Keep results and resume with the same options plus --resume.',flush=True);raise SystemExit(130)
 except Exception as exc:print('COLLECTION STOPPED:',exc,flush=True);raise
