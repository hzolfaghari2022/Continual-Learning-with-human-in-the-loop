@echo off
cd /d "%~dp0"
python ".\progress\collect_with_progress.py" %*
pause
