"""Organized progress for the unchanged four-task collector; --watch never writes data."""
import argparse,datetime,io,json,math,os,signal,subprocess,sys,time,zipfile
from pathlib import Path
from terminal_progress import Dashboard
ROOT=Path(__file__).resolve().parents[1]

def value(args,name,default=None):
 for i,item in enumerate(args):
  if item.startswith(name+'='):return item.split('=',1)[1]
  if item==name and i+1<len(args):return args[i+1]
 return default

def resolve_run(args):
 explicit=value(args,'--run-folder')
 if explicit:return Path(explicit).expanduser().resolve()
 if any(x in args for x in ('--resume','--report-only','--backup-only')):
  pointer=ROOT/'LATEST_COLLECTION.txt'
  if pointer.exists():return Path(pointer.read_text().strip()).resolve()
  parent=Path(value(args,'--output-root',str(Path.home()/'Arm26_Four_Task_PID_Data'))).expanduser()
  for folder in sorted(parent.glob('four_tasks_*'),reverse=True):
   try:
    if json.loads((folder/'COLLECTION.json').read_text()).get('protocol')=='four_tasks_yaw_load_v1':return folder.resolve()
   except (OSError,ValueError):pass
  raise FileNotFoundError('No saved four-task run found. Specify --run-folder "C:\\path\\to\\four_tasks_...".')
 parent=Path(value(args,'--output-root',str(Path.home()/'Arm26_Four_Task_PID_Data'))).expanduser()
 return (parent/('four_tasks_'+datetime.datetime.now().strftime('%Y%m%d_%H%M%S')+'_'+os.urandom(3).hex())).resolve()

def atomic_bytes(path,data):
 import tempfile
 path=Path(path);path.parent.mkdir(parents=True,exist_ok=True);fd,tmp=tempfile.mkstemp(prefix=path.name+'.',suffix='.tmp',dir=path.parent)
 try:
  with os.fdopen(fd,'wb') as stream:stream.write(data);stream.flush();os.fsync(stream.fileno())
  for attempt in range(8):
   try:os.replace(tmp,path);break
   except PermissionError:
    if attempt==7:raise
    time.sleep(min(.025*2**attempt,.4))
 finally:
  try:Path(tmp).unlink(missing_ok=True)
  except OSError:pass

def save_monitor_code(out):
 # The original Git backup copies root ZIP files into collection_metadata.
 # Capture this launcher as well as the original collector, without modifying any core source.
 files=[p for p in ROOT.iterdir() if p.is_file() and p.suffix.lower() in ('.py','.md','.bat','.osim','.json')]
 for directory in ('Geometry','progress'):
  files.extend(p for p in (ROOT/directory).rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix in ('.py','.md','.vtp'))
 buffer=io.BytesIO()
 with zipfile.ZipFile(buffer,'w',zipfile.ZIP_DEFLATED) as z:
  for p in sorted(files):z.write(p,p.relative_to(ROOT))
 atomic_bytes(out/'TERMINAL_PROGRESS_CODE.zip',buffer.getvalue())

def save_status(out,snapshot,log):
 data={k:v for k,v in snapshot.items() if k!='active'};data['active_episodes']=[dict(task=a['cfg'].get('task_id'),episode=a['cfg'].get('episode_id'),percent=100*a['fraction'],simulation_time_s=a['sim'],duration_s=a['length']) for a in snapshot['active']];data['terminal_log']=str(log);data['updated_local']=datetime.datetime.now().astimezone().isoformat()
 try:atomic_bytes(out/'TERMINAL_PROGRESS.json',(json.dumps(data,indent=2)+'\n').encode())
 except OSError:pass  # Display status must not interrupt physics or change acceptance.

def main():
 p=argparse.ArgumentParser(description=__doc__,epilog='All other options are passed unchanged to collect_four_tasks.py, including --resume, --workers and --run-folder.')
 p.add_argument('--watch',type=Path,help='Monitor an already-running result folder, without starting/stopping or modifying collection.')
 p.add_argument('--once',action='store_true',help='Print one read-only --watch snapshot and exit.')
 p.add_argument('--plain',action='store_true',help='Print periodic snapshots instead of refreshing one terminal screen.')
 p.add_argument('--refresh-seconds',type=float,default=2.)
 a,args=p.parse_known_args()
 if not math.isfinite(a.refresh_seconds) or a.refresh_seconds<.2:p.error('--refresh-seconds must be >=0.2')
 if a.once and a.watch is None:p.error('--once requires --watch')
 if a.watch is not None:
  out=a.watch.expanduser().resolve()
  if not (out/'COLLECTION.json').exists():p.error('--watch must be a result folder containing COLLECTION.json')
  dashboard=Dashboard(out,plain=a.plain or a.once,no_github='--no-github' in args,read_only=True)
  try:
   dashboard.open()
   while True:
    dashboard.render(force=a.once)
    if a.once:return 0
    time.sleep(a.refresh_seconds)
  except KeyboardInterrupt:print('\nWatch stopped. The original collector was not stopped or changed.',flush=True);return 0
  finally:dashboard.close()
 out=resolve_run(args);out.mkdir(parents=True,exist_ok=True)
 if value(args,'--run-folder') is None:args+=['--run-folder',str(out)]
 save_monitor_code(out)
 logdir=out/'terminal_logs';logdir.mkdir(exist_ok=True);log=logdir/('collector_'+datetime.datetime.now().strftime('%Y%m%d_%H%M%S')+'_'+str(os.getpid())+'.log')
 workers=int(value(args,'--workers',1));batch=int(value(args,'--batch-episodes',32));no_github='--no-github' in args
 dashboard=Dashboard(out,workers=workers,batch_size=batch,no_github=no_github,plain=a.plain,log=log)
 env=os.environ.copy();env['PYTHONUNBUFFERED']='1';child=None;code=1
 try:
  with log.open('w',encoding='utf-8') as stream:
   options={'creationflags':subprocess.CREATE_NEW_PROCESS_GROUP} if os.name=='nt' else {'start_new_session':True}
   child=subprocess.Popen([sys.executable,'-u',str(ROOT/'progress'/'reliable_collector.py'),*args],stdout=stream,stderr=subprocess.STDOUT,env=env,**options)
   dashboard.open()
   while child.poll() is None:
    snap=dashboard.render();save_status(out,snap,log);time.sleep(a.refresh_seconds)
   code=child.wait();snap=dashboard.snapshot()
   if code==0 and not no_github and snap['github'].get('status')=='failed':code=3
   snap=dashboard.render(returncode=code,force=True);save_status(out,snap,log)
   if code not in (0,3):
    from worker_recovery import tail_text
    print('\nCOLLECTOR ERROR DETAILS:\n'+tail_text(log,10000),flush=True)
   if code==3:print('\nLOCAL RESULTS ARE SAVED. GitHub backup failed; retry --backup-only. See GITHUB_STATUS.json.',flush=True)
 except KeyboardInterrupt:
  if child and child.poll() is None:
   if os.name=='nt':child.send_signal(signal.CTRL_BREAK_EVENT)
   else:os.killpg(child.pid,signal.SIGINT)
   try:child.wait(timeout=15)
   except subprocess.TimeoutExpired:
    if os.name=='nt':subprocess.run(['taskkill','/PID',str(child.pid),'/T','/F'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    else:os.killpg(child.pid,signal.SIGTERM)
    child.wait()
  code=130;dashboard.render(returncode=code,force=True);print('\nInterrupted. Existing data remain saved. Resume with the same options plus --resume.',flush=True)
 finally:dashboard.close()
 print('Data folder:',out,'\nFull log:',log,flush=True)
 return code
if __name__=='__main__':
 try:raise SystemExit(main())
 except Exception as exc:print('PROGRESS LAUNCHER STOPPED:',exc,flush=True);raise
