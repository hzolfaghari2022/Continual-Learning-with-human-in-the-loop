"""Read-only terminal dashboard. Never opens or changes training arrays."""
import collections,datetime,json,math,os,re,shutil,sys,time
from pathlib import Path

def duration(seconds):
 if seconds is None or not math.isfinite(seconds):return 'calibrating'
 seconds=max(0,int(round(seconds)));h,rest=divmod(seconds,3600);m,s=divmod(rest,60)
 return f'{h:02d}:{m:02d}:{s:02d}'

class JsonCache:
 def __init__(self):self.items={}
 def read(self,path,default=None):
  path=Path(path)
  try:
   st=path.stat();key=(st.st_mtime_ns,st.st_size);old=self.items.get(path)
   if old and old[0]==key:return old[1]
   value=json.loads(path.read_text(encoding='utf-8-sig'));self.items[path]=(key,value);return value
  except (OSError,ValueError):return {} if default is None else default

def enable_terminal():
 if not sys.stdout.isatty():return False
 if os.name!='nt':return os.environ.get('TERM','')!='dumb'
 try:
  import ctypes
  from ctypes import wintypes
  k=ctypes.WinDLL('kernel32',use_last_error=True);k.GetStdHandle.argtypes=[wintypes.DWORD];k.GetStdHandle.restype=wintypes.HANDLE;k.GetConsoleMode.argtypes=[wintypes.HANDLE,ctypes.POINTER(wintypes.DWORD)];k.SetConsoleMode.argtypes=[wintypes.HANDLE,wintypes.DWORD]
  handle=k.GetStdHandle(0xfffffff5);mode=wintypes.DWORD()
  return bool(k.GetConsoleMode(handle,ctypes.byref(mode)) and k.SetConsoleMode(handle,mode.value|4))
 except Exception:return False

class Dashboard:
 def __init__(self,out,workers=2,batch_size=32,no_github=False,plain=False,log=None,read_only=False):
  self.out=Path(out).resolve();self.workers=workers;self.batch_size=batch_size;self.no_github=no_github;self.log=Path(log) if log else None;self.read_only=read_only;self.cache=JsonCache();self.started=time.monotonic();self.start_date=datetime.datetime.now().astimezone();self.ansi=False if plain else enable_terminal();self.last_render=-1e9;self.events=collections.deque(maxlen=2);self.offset=0;self.stage_hint='Preparing collection';self.backup_start=None;self.backup_times=[];self.last_error=None
 def read_events(self):
  if not self.log:return
  try:
   with self.log.open(encoding='utf-8',errors='replace') as f:
    f.seek(self.offset);text=f.read();self.offset=f.tell()
   for line in text.splitlines():
    line=line.strip()
    if not line:continue
    if 'GITHUB BACKUP:' in line:self.stage_hint='GitHub backup / verification';self.backup_start=time.monotonic()
    elif 'GITHUB VERIFIED:' in line:
     if self.backup_start is not None:self.backup_times.append(time.monotonic()-self.backup_start);self.backup_start=None
     self.stage_hint='Collection';self.events.append(line)
    elif line.startswith('PID '):self.stage_hint='Pilot calibration' if 'pilot' in line else 'Full data collection'
    elif line.startswith('FULL '):self.stage_hint='Full data collection'
    elif 'COLLECTOR REPORTS SAVED:' in line:self.stage_hint='Reports saved';self.events.append('HTML and Overleaf reports saved')
    elif 'COLLECTION FINISHED' in line:self.stage_hint='Finished';self.events.append(line)
    elif any(x in line for x in ('WARNING','STOPPED','Error:','Traceback','pilot failed','WORKER RETRY','WORKER PROCESS ERROR','RECOVERY MODE')):self.events.append(line);self.last_error=line;self.backup_start=None
  except OSError:pass
 def snapshot(self,now=None,returncode=None):
  self.read_events();now=time.time() if now is None else now;cache=self.cache;out=self.out
  header=cache.read(out/'COLLECTION.json');cfg=header.get('config',{});work=cache.read(out/'WORKLOAD.json');plan=cache.read(out/'FROZEN_PLAN.json',[]) or cache.read(out/'UNSCALED_PLAN.json',[])
  if not isinstance(plan,list):plan=[]
  start_times=[self.start_date.timestamp()]
  try:start_times.append((out/'COLLECTION.json').stat().st_mtime)
  except OSError:pass
  match=re.match(r'four_tasks_(\d{8})_(\d{6})_',out.name)
  if match:
   try:start_times.append(datetime.datetime.strptime(match[1]+match[2],'%Y%m%d%H%M%S').astimezone().timestamp())
   except ValueError:pass
  planned={r['episode_id']:r for r in plan};conditions={r['condition']:r for r in plan};total=work.get('full_episodes',len(plan));workers=work.get('workers',self.workers) or self.workers;cal=cache.read(out/'PILOT_CALIBRATION.json');saved={};active=[];rates=collections.defaultdict(list);pilot_attempts=0;pilot_seen=collections.defaultdict(list)
  for path in out.rglob('status.json'):
   relative=path.relative_to(out)
   if not relative.parts or relative.parts[0] not in ('tasks','pilot') or 'interrupted_attempts' in relative.parts:continue
   st=cache.read(path);ep=cache.read(path.parent/'settings.json')
   if not ep or not st:continue
   pilot=ep.get('split')=='pilot';final=st.get('status') in ('completed','failed');progress=cache.read(path.parent/'episode_progress.json');sim=max(0,float(progress.get('simulation_time_s',0)));length=float(ep.get('duration_s',1));fraction=min(1.,sim/length) if length else 0.
   try:mtime=path.stat().st_mtime;begin=(path.parent/'episode_identity.json').stat().st_mtime;age=now-(path.parent/'episode_progress.json').stat().st_mtime
   except OSError:mtime=now;begin=now;age=0.
   start_times.append(begin)
   if final:
    wall=max(float(st.get('wall_seconds',0)),mtime-begin)
    if wall>.05 and length>0:
     rates[ep.get('task_id','')].append((mtime,wall/length));rates['all'].append((mtime,wall/length))
    if pilot:pilot_attempts+=1;pilot_seen[ep.get('condition')].append((ep,st))
    elif ep.get('episode_id') in planned:saved[ep['episode_id']]={'cfg':ep,'status':st}
   elif st.get('status')=='running':
    item=dict(cfg=ep,sim=sim,length=length,fraction=fraction,age=max(0,age),elapsed=max(0,now-begin));active.append(item)
    if pilot:pilot_seen[ep.get('condition')].append((ep,st))
  def ratio(task):
   values=sorted(rates.get(task) or rates.get('all') or [],reverse=True)[:8]
   return sum(r for _,r in values)/len(values) if values else None
  active_by_id={a['cfg']['episode_id']:a for a in active if a['cfg'].get('split')!='pilot'};pending_cost=[];remaining_sim=0.
  for eid,ep in planned.items():
   if eid in saved:continue
   length=float(ep['duration_s']);a=active_by_id.get(eid);remaining=max(0,length-(a['sim'] if a else 0));remaining_sim+=remaining;r=ratio(ep['task_id'])
   if a and a['sim']>1 and a['age']<60:r=max(r or 0,a['elapsed']/a['sim'])
   if r is not None:pending_cost.append(max(.5 if a else 0,remaining*r))
  known_rate=ratio('all');pilot_cost=0.;pending_conditions=[k for k in conditions if k not in cal]
  errors=cfg.get('initial_errors',[-2,0,2]);vels=cfg.get('initial_velocities',[-15,0,15]);corners=len({(min(errors),min(vels)),(max(errors),max(vels))})
  for condition in pending_conditions:
   ep=conditions[condition];seen=pilot_seen.get(condition,[]);running=[a for a in active if a['cfg'].get('split')=='pilot' and a['cfg'].get('condition')==condition]
   latest_speed=min([float(x[0].get('speed_scale',ep['speed_scale'])) for x in seen]+[a['cfg'].get('speed_scale',ep['speed_scale']) for a in running]+[ep['speed_scale']])
   done=sum(x[1].get('status') in ('completed','failed') and math.isclose(x[0].get('speed_scale',0),latest_speed) for x in seen);estimated_cases=max(0,corners-done)
   for a in running:
    if known_rate is not None:pilot_cost+=max(.5,(a['length']-a['sim'])*known_rate)
    estimated_cases=max(0,estimated_cases-1)
   if known_rate is not None:pilot_cost+=estimated_cases*float(ep['duration_s'])*known_rate
  simulation_eta=None
  if known_rate is not None:
   full_eta=max(sum(pending_cost)/max(1,workers),max(pending_cost,default=0.))
   simulation_eta=full_eta+pilot_cost/max(1,workers)
  if self.backup_start is not None:simulation_eta=None
  if simulation_eta is not None and self.backup_times and not self.no_github:
   simulation_eta+=sum(self.backup_times[-4:])/len(self.backup_times[-4:])*math.ceil(max(0,total-len(saved))/self.batch_size)
  ready=bool(cache.read(out/'DATASET_MANIFEST.json').get('ready_for_training') and cache.read(out/'TRAINING_HANDOFF.json').get('ready_for_training'));github=cache.read(out/'GITHUB_STATUS.json');pilot_failed=any(v.get('selected_factor') is None for v in cal.values())
  if pilot_failed:simulation_eta=None
  stage=self.stage_hint
  if self.read_only or stage in ('Preparing collection','Collection'):
   if any(a['cfg'].get('split')=='pilot' for a in active) or len(cal)<len(conditions):stage='Pilot calibration'
   elif active or len(saved)<total:stage='Full data collection'
   elif ready:stage='Data ready; final reports / backup'
  if len(saved)==total and total and not active and returncode is None:simulation_eta=None
  if self.read_only and ready and not active and (out/'REPORT.html').exists():
   try:reports_time=max((out/'REPORT.html').stat().st_mtime,(out/'COLLECTION_STATUS.json').stat().st_mtime);backed_up=github.get('status')=='verified' and (out/'GITHUB_STATUS.json').stat().st_mtime>=reports_time
   except OSError:backed_up=False
   if backed_up or self.no_github:stage='COMPLETE (saved data and reports)';simulation_eta=0.;now=max(reports_time,(out/'GITHUB_STATUS.json').stat().st_mtime if backed_up else reports_time)
  if returncode is not None:stage=('FINISHED' if returncode==0 else 'STOPPED / ACTION NEEDED');simulation_eta=0 if returncode==0 else None
  taskrows={}
  for task in cfg.get('tasks',['A_90','B_60','C_30','D_45']):
   rr=[x for x in saved.values() if x['cfg']['task_id']==task];target=sum(x['task_id']==task for x in plan);taskrows[task]=dict(done=len(rr),total=target,train=sum(x['cfg']['split']=='train' for x in rr),validation=sum(x['cfg']['split']=='validation' for x in rr),test=sum(x['cfg']['split']=='test' for x in rr),accepted=sum(bool(x['status'].get('accepted_for_imitation')) for x in rr))
  return dict(run_started_epoch=min(start_times),run_elapsed_seconds=max(0,now-min(start_times)),stage=stage,full_done=len(saved),full_total=total,full_remaining=max(0,total-len(saved)),accepted=sum(bool(x['status'].get('accepted_for_imitation')) for x in saved.values()),samples=sum(x['status'].get('sample_count',0) for x in saved.values()),pilot_conditions_done=len(cal),pilot_conditions_total=len(conditions),pilot_attempts=pilot_attempts,pilot_failed=pilot_failed,workers=workers,active=active,tasks=taskrows,eta_seconds=simulation_eta,ready=ready,github=github,elapsed=time.monotonic()-self.started,returncode=returncode)
 def lines(self,s):
  now=datetime.datetime.now().astimezone();eta=s['eta_seconds'];end=(now+datetime.timedelta(seconds=eta)).strftime('%a %b %d %Y %I:%M:%S %p %Z') if eta is not None and s['returncode'] is None and not s['stage'].startswith('COMPLETE') else ('Completed' if s['returncode']==0 or s['stage'].startswith('COMPLETE') else 'calibrating / final stage duration unknown')
  gh='DISABLED by --no-github' if self.no_github else str(s['github'].get('status','pending')).upper();gh+=(' | commit '+s['github'].get('commit','')[:10]) if s['github'].get('commit') else ''
  lines=['ARM26 FOUR-TASK DATA COLLECTION',f"Stage: {s['stage']}  |  Updated: {now.strftime('%I:%M:%S %p %Z')}",f"Run elapsed: {duration(s['run_elapsed_seconds'])}  |  Remaining estimate: {duration(eta)}",'Started: '+datetime.datetime.fromtimestamp(s['run_started_epoch']).astimezone().strftime('%a %b %d %I:%M:%S %p %Z'), 'Estimated finish: '+end,f"Episodes / iterations saved: {s['full_done']}/{s['full_total']}  |  {100*s['full_done']/max(1,s['full_total']):.1f}%  |  Remaining: {s['full_remaining']}  |  Accepted: {s['accepted']}",f"Pilot conditions: {s['pilot_conditions_done']}/{s['pilot_conditions_total']}  |  Attempts finished: {s['pilot_attempts']}  |  Saved full samples: {s['samples']:,}",'',f"{'Task':<9}{'Saved / planned':<20}{'Train':>7}{'Val':>7}{'Test':>7}{'Accepted':>11}"]
  for t,r in s['tasks'].items():lines.append(f"{t:<9}{str(r['done'])+' / '+str(r['total']):<20}{r['train']:>7}{r['validation']:>7}{r['test']:>7}{r['accepted']:>11}")
  lines+=['',f"Workers active: {len(s['active'])}/{s['workers']}"]
  for a in s['active'][:max(1,s['workers'])]:
   ep=a['cfg'];phase='PILOT' if ep.get('split')=='pilot' else ep.get('split','').upper();extra=' | no recent progress' if a['age']>90 else ''
   lines.append(f"  {ep.get('task_id','?')} {phase:<10} {100*a['fraction']:5.1f}% | sim {a['sim']:.1f}/{a['length']:.1f}s | {ep.get('episode_id','')}{extra}")
  if not s['active']:lines.append('  Waiting for worker startup, verification, reports or GitHub')
  lines+=['GitHub backup: '+gh,'Training data ready: '+('YES' if s['ready'] else 'NOT YET'),'Data folder: '+str(self.out)]
  if self.log:lines.append('Full terminal log: '+str(self.log))
  if self.events:lines.append('Latest event: '+self.events[-1])
  lines.append('ETA is approximate: pilot retries, reports and network delays can extend it.')
  if s['pilot_failed']:lines.append('PID pilot failed; full collection cannot proceed. Read the saved worker log.')
  return lines
 def render(self,returncode=None,force=False):
  s=self.snapshot(returncode=returncode);interval=2 if self.ansi else 15
  if not force and time.monotonic()-self.last_render<interval:return s
  self.last_render=time.monotonic();lines=self.lines(s)
  try:
   if self.ansi:
    width=max(50,shutil.get_terminal_size((110,35)).columns-1);sys.stdout.write('\x1b[H'+'\n'.join(line[:width].ljust(width) for line in lines)+'\x1b[J');sys.stdout.flush()
   else:print('\n'+'\n'.join(lines),flush=True)
  except (OSError,UnicodeError):self.ansi=False
  return s
 def open(self):
  if self.ansi:sys.stdout.write('\x1b[2J\x1b[H\x1b[?25l');sys.stdout.flush()
 def close(self):
  if self.ansi:sys.stdout.write('\x1b[?25h\n');sys.stdout.flush()
