import unittest,tempfile,sys,json,os
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from worker_recovery import WorkerProcessError,run_logged,execute_with_recovery
from reliable_collector import StopPendingExecutor
class Checks(unittest.TestCase):
 def test_unexpected_exit_includes_log_and_code(self):
  with tempfile.TemporaryDirectory() as tmp:
   f=Path(tmp)/'console.log'
   with self.assertRaises(WorkerProcessError) as c:run_logged([sys.executable,'-c',"import sys;print('specific native/startup diagnostic',flush=True);sys.exit(17)"],f)
   self.assertEqual(c.exception.returncode,17);self.assertIn('specific native/startup diagnostic',str(c.exception));self.assertIn(str(f),str(c.exception))
 def test_crash_retries_same_episode_without_tuning(self):
  with tempfile.TemporaryDirectory() as tmp:
   p=Path(tmp);cfg={'episode_id':'B_60_A_e50_train_13','task_id':'B_60','speed_scale':1.2};before=cfg.copy();calls=[]
   def original(config,folder,timeout):
    calls.append((config.copy(),folder,timeout))
    if len(calls)<3:raise WorkerProcessError([],p/'console.log',-11,'native crash')
    return {'accepted_for_imitation':True}
   with patch('worker_recovery.log_failure'):r=execute_with_recovery(original,cfg,p,20,pause=lambda _:None)
   self.assertTrue(r['accepted_for_imitation']);self.assertEqual(len(calls),3);self.assertEqual(before,cfg);self.assertTrue(all(x==calls[0] for x in calls))
 def test_deterministic_import_failure_is_not_retried(self):
  with tempfile.TemporaryDirectory() as tmp:
   p=Path(tmp);calls=[]
   def original(*a):calls.append(1);raise WorkerProcessError([],p/'console.log',1,'ModuleNotFoundError: missing dependency')
   with patch('worker_recovery.log_failure'),self.assertRaises(RuntimeError):execute_with_recovery(original,{},p,1,pause=lambda _:None)
   self.assertEqual(len(calls),1)
 def test_validation_failure_not_suppressed(self):
  def original(*a):raise ValueError('Saved episode file changed')
  with self.assertRaises(ValueError):execute_with_recovery(original,{},Path('.'),1,pause=lambda _:None)
 def test_bounded_failure(self):
  with tempfile.TemporaryDirectory() as tmp:
   p=Path(tmp);calls=[]
   def original(*a):calls.append(1);raise WorkerProcessError([],p/'console.log',99,'unexpected process termination')
   with patch('worker_recovery.log_failure'),self.assertRaises(RuntimeError):execute_with_recovery(original,{},p,1,pause=lambda _:None)
   self.assertEqual(len(calls),3)
 def test_allowed_quality_exit_does_not_become_crash(self):
  with tempfile.TemporaryDirectory() as tmp:self.assertEqual(run_logged([sys.executable,'-c','raise SystemExit(2)'],Path(tmp)/'console.log',allowed=(0,2)),2)
if __name__=='__main__':unittest.main()
