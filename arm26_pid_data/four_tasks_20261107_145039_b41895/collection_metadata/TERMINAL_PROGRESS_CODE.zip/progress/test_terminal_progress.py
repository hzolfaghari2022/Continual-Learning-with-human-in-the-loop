import unittest,tempfile,json,sys,hashlib,zipfile,importlib.util,time
from pathlib import Path
from unittest.mock import patch
from terminal_progress import Dashboard,duration
from collect_with_progress import save_monitor_code,resolve_run

def write(path,data):path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(data))
class Checks(unittest.TestCase):
 def fixture(self,root):
  config=dict(tasks=['A_90'],initial_errors=[0],initial_velocities=[0]);write(root/'COLLECTION.json',dict(config=config,protocol='four_tasks_yaw_load_v1'))
  plan=[dict(episode_id='a'+str(i),condition='c',task_id='A_90',duration_s=20.,speed_scale=1.) for i in range(4)]
  write(root/'WORKLOAD.json',dict(full_episodes=4,workers=2));write(root/'UNSCALED_PLAN.json',plan);write(root/'PILOT_CALIBRATION.json',{'c':dict(selected_factor=1.)})
  for i in range(2):
   f=root/'tasks'/'A_90'/str(i);write(f/'settings.json',dict(plan[i],split='train'));write(f/'status.json',dict(status='completed',wall_seconds=10.,accepted_for_imitation=True,sample_count=2001));write(f/'episode_identity.json',{})
 def test_eta_counts_and_no_data_access(self):
  with tempfile.TemporaryDirectory() as tmp:
   root=Path(tmp);self.fixture(root);d=Dashboard(root,plain=True,read_only=True);before={str(p.relative_to(root)):p.read_bytes() for p in root.rglob('*') if p.is_file()};s=d.snapshot()
   self.assertEqual(s['full_done'],2);self.assertEqual(s['samples'],4002);self.assertAlmostEqual(s['eta_seconds'],10.,places=1)
   after={str(p.relative_to(root)):p.read_bytes() for p in root.rglob('*') if p.is_file()};self.assertEqual(before,after)
   self.assertIn('Estimated finish:', '\n'.join(d.lines(s)))
 def test_initial_eta_and_final_backup_status(self):
  with tempfile.TemporaryDirectory() as tmp:
   root=Path(tmp);d=Dashboard(root,plain=True);self.assertIsNone(d.snapshot()['eta_seconds'])
   self.fixture(root);write(root/'GITHUB_STATUS.json',dict(status='failed'));s=d.snapshot(returncode=3);self.assertEqual(s['stage'],'STOPPED / ACTION NEEDED');self.assertFalse(s['ready']);self.assertIn('FAILED','\n'.join(d.lines(s)))
 def test_code_is_captured_for_github_metadata(self):
  with tempfile.TemporaryDirectory() as tmp:
   root=Path(tmp);save_monitor_code(root)
   with zipfile.ZipFile(root/'TERMINAL_PROGRESS_CODE.zip') as z:
    self.assertIn('progress/collect_with_progress.py',z.namelist());self.assertIn('collect_four_tasks.py',z.namelist());self.assertIn('arm26_exosuit.osim',z.namelist());self.assertIsNone(z.testzip())
 def test_original_source_hashes_are_unchanged(self):
  root=Path(__file__).resolve().parents[1]
  manifest=json.loads((root/'PACKAGE_SHA256.json').read_text())
  for n,h in manifest.items():
   if n.endswith('.py') and '/' not in n or n=='arm26_exosuit.osim':self.assertEqual(hashlib.sha256((root/n).read_bytes()).hexdigest(),h)
 def test_duration(self):self.assertEqual(duration(3661),'01:01:01');self.assertEqual(duration(-1),'00:00:00')
if __name__=='__main__':unittest.main()
