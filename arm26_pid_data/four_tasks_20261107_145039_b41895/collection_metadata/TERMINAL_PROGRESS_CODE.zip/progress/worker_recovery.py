"""Operational worker recovery; never changes trajectories, PID gains or acceptance."""
import datetime,json,os,subprocess,sys,threading,time
from pathlib import Path

class WorkerProcessError(RuntimeError):
 def __init__(self,command,log,returncode,tail,timed_out=False):
  self.command=command;self.log=Path(log);self.returncode=returncode;self.tail=tail;self.timed_out=timed_out
  if timed_out:code='worker timeout'
  elif os.name=='nt' and returncode is not None:code=f'exit {returncode} (Windows 0x{returncode & 0xffffffff:08X})'
  elif returncode is not None and returncode<0:code=f'exit {returncode} (signal {-returncode})'
  else:code=f'exit {returncode}'
  super().__init__('WORKER PROCESS ERROR: '+code+'\nEpisode folder: '+str(self.log.parent)+'\nLog: '+str(self.log)+'\nLast worker output:\n'+(tail or '[No worker output was produced before exit.]'))

def tail_text(path,limit=16000):
 try:
  with Path(path).open('rb') as stream:
   stream.seek(0,2);stream.seek(max(0,stream.tell()-limit));return stream.read().decode('utf-8',errors='replace')
 except OSError:return '[Could not read worker log.]'

def run_logged(command,log,allowed=(0,),timeout=None,heartbeat=None):
 log=Path(log);log.parent.mkdir(parents=True,exist_ok=True);print('RUN:',subprocess.list2cmdline([str(v) for v in command]),flush=True)
 env=os.environ.copy();env['PYTHONUNBUFFERED']='1'
 for name in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS'):env[name]='1'
 timed_out=False
 with log.open('w',encoding='utf-8') as stream:
  try:proc=subprocess.Popen([str(v) for v in command],stdout=stream,stderr=subprocess.STDOUT,env=env)
  except OSError as exc:raise WorkerProcessError(command,log,None,type(exc).__name__+': '+str(exc)) from exc
  start=time.monotonic();offset=0
  try:
   while proc.poll() is None:
    if timeout is not None and time.monotonic()-start>timeout:timed_out=True;break
    if heartbeat is not None:heartbeat()
    time.sleep(.2)
    with log.open(encoding='utf-8',errors='replace') as reader:reader.seek(offset);chunk=reader.read();offset=reader.tell()
    if chunk:print(chunk,end='',flush=True)
   if timed_out:
    proc.terminate()
    try:proc.wait(timeout=10)
    except subprocess.TimeoutExpired:proc.kill();proc.wait()
   else:proc.wait()
   with log.open(encoding='utf-8',errors='replace') as reader:reader.seek(offset);chunk=reader.read()
   if chunk:print(chunk,end='',flush=True)
  except BaseException:
   if proc.poll() is None:
    proc.terminate()
    try:proc.wait(timeout=10)
    except subprocess.TimeoutExpired:proc.kill();proc.wait()
   raise
 if timed_out or proc.returncode not in allowed:raise WorkerProcessError(command,log,proc.returncode,tail_text(log),timed_out)
 return proc.returncode

_FATAL=('ModuleNotFoundError:','ImportError:','SyntaxError:','DLL load failed','OMP: Error #15','unrecognized arguments:','FileNotFoundError:')
_lock=threading.Lock()

def log_failure(cfg,folder,exc,attempt):
 folder=Path(folder).resolve();out=folder
 while out.parent!=out and not (out/'COLLECTION.json').exists():out=out.parent
 if not (out/'COLLECTION.json').exists():out=folder.parent
 record=dict(time_local=datetime.datetime.now().astimezone().isoformat(),episode_id=cfg.get('episode_id'),task_id=cfg.get('task_id'),attempt=attempt,folder=str(folder),returncode=getattr(exc,'returncode',None),timed_out=getattr(exc,'timed_out',False),worker_tail=getattr(exc,'tail',str(exc)),log=str(folder/'console.log'))
 try:
  from atomic_io import atomic_json
  with _lock:
   file=out/'WORKER_FAILURES.json'
   try:data=json.loads(file.read_text())
   except (OSError,ValueError):data={'failures':[]}
   data['failures'].append(record);atomic_json(file,data)
 except OSError as error:print('RECOVERY LOG WARNING:',error,flush=True)

def execute_with_recovery(original,cfg,folder,timeout,attempts=3,pause=time.sleep):
 for attempt in range(1,attempts+1):
  try:return original(cfg,folder,timeout)
  except WorkerProcessError as exc:
   log_failure(cfg,folder,exc,attempt)
   fatal=any(token in exc.tail for token in _FATAL)
   if fatal or attempt==attempts:
    print(str(exc),flush=True)
    raise RuntimeError(str(exc)+'\nRecovery stopped after '+str(attempt)+' attempt(s). Completed episodes remain saved. Supply this log if the failure persists; no PID/speed/quality setting was changed.') from exc
   print(f"WORKER RETRY {attempt}/{attempts-1}: {cfg.get('episode_id')} | exit {exc.returncode} | same episode/settings; completed data are retained",flush=True)
   pause(min(2.,.5*attempt))
  except RuntimeError as exc:
   # Retry an explicitly reported transient export/OS sharing failure, never a checksum/quality failure.
   text=str(exc)
   if not text.startswith('Export failed:'):raise
   try:details=json.loads((Path(folder)/'status.json').read_text()).get('export_error','')
   except (OSError,ValueError):raise exc
   transient=any(word in details for word in ('PermissionError','WinError 32','WinError 33','BlockingIOError','temporarily unavailable'))
   if not transient or attempt==attempts:raise
   log_failure(cfg,folder,exc,attempt);print(f"WORKER RETRY {attempt}/{attempts-1}: transient export failure for {cfg.get('episode_id')}; original partial files retained",flush=True);pause(min(2.,.5*attempt))
