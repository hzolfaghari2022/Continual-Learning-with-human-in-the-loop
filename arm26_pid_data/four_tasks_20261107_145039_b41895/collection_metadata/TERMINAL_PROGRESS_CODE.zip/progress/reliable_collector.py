"""Run the original collector with bounded worker retries and explicit recovery provenance."""
from pathlib import Path
import concurrent.futures,datetime,hashlib,json,sys
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
import runtime_setup
import process_helpers,episode_io
import worker_recovery
process_helpers.run_logged=worker_recovery.run_logged
episode_io.run_logged=worker_recovery.run_logged
_original=episode_io.execute

def execute(cfg,folder,timeout):return worker_recovery.execute_with_recovery(_original,cfg,folder,timeout)
episode_io.execute=execute
import collect_four_tasks

class StopPendingExecutor(concurrent.futures.ThreadPoolExecutor):
 def __exit__(self,exc_type,exc_value,traceback):
  self.shutdown(wait=True,cancel_futures=exc_type is not None)
  return False
collect_four_tasks.ThreadPoolExecutor=StopPendingExecutor

def main():
 # Worker count is operational and excluded by the existing collection lock.
 if not any(x=='--workers' or x.startswith('--workers=') for x in sys.argv):sys.argv+=['--workers','1']
 out=None
 for i,arg in enumerate(sys.argv):
  if arg=='--run-folder' and i+1<len(sys.argv):out=Path(sys.argv[i+1])
  elif arg.startswith('--run-folder='):out=Path(arg.split('=',1)[1])
 if out:
  from atomic_io import atomic_json
  out.mkdir(parents=True,exist_ok=True)
  files=[Path(__file__),Path(worker_recovery.__file__)]
  atomic_json(out/'RUNTIME_RECOVERY.json',dict(time_local=datetime.datetime.now().astimezone().isoformat(),operational_patch='bounded worker retries + detailed exit diagnostics + cancel pending work on fatal error',maximum_attempts=3,native_worker_threads=1,physics_changed=False,acceptance_changed=False,patch_sha256={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in files},core_sha256={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in ROOT.glob('*.py')}))
 if out:
  from atomic_io import atomic_json
  try:ready=json.loads((out/'DATASET_MANIFEST.json').read_text()).get('ready_for_training',False)
  except (OSError,ValueError):ready=False
  if not ready and not any(flag in sys.argv for flag in ('--backup-only','--report-only','--plan-only')):atomic_json(out/'COLLECTION_STATUS.json',dict(status='collecting_or_resuming',ready_for_training=False))
 print('RECOVERY MODE: bounded retries; one worker by default; original physics and quality checks retained.',flush=True)
 try:return collect_four_tasks.main()
 except KeyboardInterrupt:print('Interrupted. Completed data remain saved. Resume the same run.',flush=True);return 130
 except Exception as exc:
  if out:
   from atomic_io import atomic_json
   try:
    ready=json.loads((out/'DATASET_MANIFEST.json').read_text()).get('ready_for_training',False)
   except (OSError,ValueError):ready=False
   atomic_json(out/'RECOVERY_STOPPED.json',dict(error=str(exc),data_ready=ready,completed_data_retained=True))
   if not ready:atomic_json(out/'COLLECTION_STATUS.json',dict(status='failed',ready_for_training=False,error=str(exc)))
   if '--no-github' not in sys.argv and '--backup-only' not in sys.argv and (out/'COLLECTION.json').exists():
    try:
     from github_backup import GitBackup
     def option(name,default):
      for i,a in enumerate(sys.argv):
       if a==name and i+1<len(sys.argv):return sys.argv[i+1]
       if a.startswith(name+'='):return a.split('=',1)[1]
      return default
     repo=option('--github-repo',collect_four_tasks.REPO);branch=option('--github-branch','arm26-four-task-data')
     print('RECOVERY BACKUP: saving completed work before stopping.',flush=True)
     GitBackup(repo,out,branch,Path.home()/'Arm26_FourTask_Collector_Cache'/out.name).sync(ROOT)
    except Exception as backup_error:print('BACKUP WARNING: local data remain saved:',backup_error,flush=True)
  raise
if __name__=='__main__':
 try:raise SystemExit(main())
 except Exception as exc:print('COLLECTION STOPPED:',exc,flush=True);raise
