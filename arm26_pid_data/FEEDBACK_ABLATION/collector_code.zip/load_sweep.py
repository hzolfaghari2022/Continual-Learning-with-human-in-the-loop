"""Separate post-scenario frozen-model load sensitivity experiment; no training."""
import argparse,datetime,hashlib,json,math,sys,time
from pathlib import Path
from types import SimpleNamespace
from complex_engine import ROOT,read,write,sha
from study_data import DataAccess
from evaluate_study import rollout,inference_hashes
from scenario_support import require_space

def checkpoint_for(study,seed,branch,task,stage):
    base=Path(study)/f'seed_{seed}';catalog=read(base/'SAVED_MODELS.json')
    target=task if stage=='after_task' else catalog['training_order'][-1]
    entry=next(r for r in catalog['models'] if r['branch']==branch and r['task']==target)
    checkpoint=Path(entry['checkpoint']);source=Path(entry['source'])
    for name,h in entry['sha256'].items():
        if sha(checkpoint.parent/name)!=h or sha(source.parent/name)!=h:raise ValueError('Saved deployment model differs from its sealed source: '+str(checkpoint))
    return checkpoint

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--no-github',action='store_true');p.add_argument('--github-repo',default='https://github.com/hzolfaghari2022/Continual-Learning-with-human-in-the-loop.git');p.add_argument('--backup-only',action='store_true');p.add_argument('--study',type=Path);p.add_argument('--out',type=Path);p.add_argument('--report-only',action='store_true')
    p.add_argument('--tasks',nargs='+',choices=['A_90','B_60','C_30','D_45'],default=['C_30','D_45','B_60','A_90'])
    p.add_argument('--masses',type=float,nargs='+',help='Absolute kg, strictly increasing. Default: nominal mass times 1,1.5,2,3,4,6,8.')
    p.add_argument('--seed',type=int,default=42);p.add_argument('--branches',nargs='+',choices=['noEWC','EWC'],default=['noEWC','EWC'])
    p.add_argument('--checkpoint-stage',choices=['final','after_task'],default='final',help='Final after-A model, or each task\'s saved stage model.')
    p.add_argument('--episodes-per-task',type=int,default=1,help='Fixed metadata-selected subset; increase before the first run for broader coverage.')
    p.add_argument('--tracking-rmse-deg',type=float,default=2.);p.add_argument('--tracking-max-deg',type=float,default=5.)
    p.add_argument('--episode-timeout',type=float,default=600.);p.add_argument('--min-free-gb',type=float,default=2.);p.add_argument('--no-test-viewer',action='store_true')
    a=p.parse_args()
    if a.backup_only:
        if a.out is None:p.error('--backup-only requires --out')
        from publish_study import publish
        publish(a.out,a.github_repo);return 0
    if a.report_only:
        if a.out is None:p.error('--report-only requires --out')
        from load_report import build_report
        build_report(a.out);return 0
    if a.episodes_per_task<1 or len(set(a.tasks))!=len(a.tasks) or len(set(a.branches))!=len(a.branches) or any(not math.isfinite(v) or v<=0 for v in (a.tracking_rmse_deg,a.tracking_max_deg,a.episode_timeout)) or not math.isfinite(a.min_free_gb) or a.min_free_gb<0:p.error('Invalid test settings')
    if a.study is None:
        pointer=ROOT/'LATEST_CDBA_STUDY.txt'
        if not pointer.exists():p.error('Run run_cdba.py first, then supply --study')
        a.study=Path(pointer.read_text(encoding='utf-8').strip())
    a.study=a.study.resolve()
    if not read(a.study/'STUDY_STATUS.json').get('status')=='complete' or not read(a.study/'TEST_RESULTS.json').get('complete'):raise ValueError('Finish the CDBA scenario and review its report before this separate load experiment.')
    manifest=read(a.study/'SPLIT_LOCK.json');access=DataAccess(a.study,manifest);access.verify_test_seal()
    nominal=float(read(Path(manifest['records'][0]['folder'])/'settings.json')['mass_kg'])
    masses=a.masses or [nominal*f for f in (1,1.5,2,3,4,6,8)]
    if nominal<=0 and not a.masses:p.error('Zero nominal load: specify --masses explicitly.')
    if not masses or any(not math.isfinite(m) or m<0 for m in masses) or any(y<=x for x,y in zip(masses,masses[1:])):p.error('Masses must be finite, nonnegative and strictly increasing.')
    a.out=(a.out or a.study/('load_sweep_'+datetime.datetime.now().strftime('%Y%m%d_%H%M%S'))).resolve()
    if a.out==a.study:raise ValueError('Load-sweep output must be separate from the training-study root.')
    a.out.mkdir(parents=True,exist_ok=True);require_space(a.out,a.min_free_gb)
    spec=dict(source_study=str(a.study),frozen_seal_sha256=sha(a.study/'FINAL_MODELS_FROZEN.json'),seed=a.seed,tasks=a.tasks,branches=a.branches,masses_kg=masses,nominal_mass_kg=nominal,checkpoint_stage=a.checkpoint_stage,episodes_per_task=a.episodes_per_task,rmse_limit_deg=a.tracking_rmse_deg,max_error_limit_deg=a.tracking_max_deg,force_cap_N=650.,mass_input='True changed mass is supplied to the existing mass input. The controller remains frozen.',interpretation='Performance envelope of these frozen controllers; not proof of anatomical capacity or infeasibility under all controllers.',source_hashes={f.name:sha(f) for f in ROOT.glob('*.py')})
    lock=a.out/'LOAD_PROTOCOL.json'
    if lock.exists() and read(lock)!=spec:raise ValueError('Load protocol changed. Use a new --out or repeat the original options.')
    write(lock,spec);rows=[];total=len(a.tasks)*len(a.branches)*len(masses)*a.episodes_per_task;started=time.monotonic()
    args=SimpleNamespace(architecture='mlp',no_test_viewer=a.no_test_viewer,tracking_rmse_deg=a.tracking_rmse_deg,tracking_max_deg=a.tracking_max_deg,episode_timeout=a.episode_timeout)
    for task in a.tasks:
        selected=access.physics_rows(task)[:a.episodes_per_task]
        if len(selected)!=a.episodes_per_task:raise ValueError('Not enough preselected physical test episodes. Use a smaller --episodes-per-task.')
        for branch in a.branches:
            checkpoint=checkpoint_for(a.study,a.seed,branch,task,a.checkpoint_stage)
            for mass in masses:
                for record in selected:
                    require_space(a.out,a.min_free_gb);tag=format(mass,'.10g').replace('.','p');name=f'{task}_{branch}_{tag}kg'
                    probe=a.out/'probe_settings'/name/record['motion_id'];probe.mkdir(parents=True,exist_ok=True)
                    cfg=read(Path(record['folder'])/'settings.json');cfg['mass_kg']=mass;cfg.pop('muscle_strength_audit',None);write(probe/'settings.json',cfg)
                    modified=dict(record,folder=str(probe));print(f'FROZEN LOAD TEST {len(rows)+1}/{total}: {task} | {branch} | {mass:g} kg',flush=True)
                    row=rollout(access,modified,checkpoint,a.out/'evaluations'/name/record['motion_id'],task,name,a.seed,args)
                    error=row.get('error') or '';kind=None if row['completed'] else 'numerical_failure' if any(t in error for t in ('FloatingPointError','Nonfinite','SimTK','Simbody','integrator','Integrator')) else 'envelope_or_simulation_failure'
                    row.update(mass_kg=mass,branch=branch,checkpoint_stage=a.checkpoint_stage,source_teacher_folder=record['folder'],teacher_folder=None,comparison_to_teacher='No teacher target at changed mass; only reference tracking is scored.',failure_kind=kind)
                    rows.append(row);write(a.out/'LOAD_RESULTS.json',dict(complete=False,rows=rows));print(f'LOAD TEST SAVED | elapsed {(time.monotonic()-started)/60:.1f} min | complete {row["completed"]} | tracking passed {row["tracking_passed"]}',flush=True)
    access.verify_test_seal();write(a.out/'LOAD_RESULTS.json',dict(complete=True,rows=rows))
    from load_report import build_report
    build_report(a.out)
    if not a.no_github:
        try:
            from publish_study import publish
            publish(a.out,a.github_repo)
        except Exception as exc:
            write(a.out/'GITHUB_STATUS.json',dict(status='failed',error=str(exc)));print('LOAD BACKUP FAILED; local results/report are saved. Retry --backup-only --out:',a.out,exc,flush=True);return 3
    print('LOAD SWEEP COMPLETE:',a.out,'| Original scenario and trained weights unchanged.',flush=True)
    return 0

if __name__=='__main__':
    try:raise SystemExit(main())
    except Exception as exc:print('LOAD SWEEP STOPPED:',exc,'| Saved models are retained; repeat the same command with --out to reuse completed tests.',flush=True);raise
