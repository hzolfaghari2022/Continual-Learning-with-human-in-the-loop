"""Read the four-task collection, preserve original splits, and seal tests."""
import json,time
from pathlib import Path
import numpy as np
from complex_engine import read,write,sha
from complex_trajectories import FEATURES,SCALES,encode,reference_digest
from task_plan import TASKS
TASK_ORDER=list(TASKS)

def resolve_collection(path=None):
 if path is not None:
  p=Path(path).expanduser().resolve()
  if not (p/'COLLECTION.json').exists():raise FileNotFoundError('Select the result folder containing COLLECTION.json: '+str(p))
  return p
 root=Path.home()/'Arm26_Four_Task_PID_Data'
 for p in sorted(root.glob('four_tasks_*'),key=lambda p:p.name,reverse=True):
  if (p/'COLLECTION.json').exists() and read(p/'COLLECTION.json').get('protocol')=='four_tasks_yaw_load_v1' and (p/'DATASET_MANIFEST.json').exists() and read(p/'DATASET_MANIFEST.json').get('complete') and read(p/'DATASET_MANIFEST.json').get('ready_for_training'):return p.resolve()
 raise FileNotFoundError('No second (four-task) collection found under '+str(root)+'. Supply --collection "C:\\path\\to\\four_tasks_...".')

def wait_until_ready(collection,wait=True):
 collection=Path(collection);last=-1e9
 while True:
  cfg=read(collection/'COLLECTION.json')
  if cfg.get('protocol')!='four_tasks_yaw_load_v1':raise ValueError('This trainer requires the four-task dataset, not the first 90/30 collection.')
  file=collection/'DATASET_MANIFEST.json';d=read(file) if file.exists() else {}
  if d.get('complete'):
   if not d.get('ready_for_training'):raise ValueError('Collection completed with rejected episodes; inspect COLLECTION_STATUS.json. Training did not start.')
   handoff=collection/'TRAINING_HANDOFF.json'
   if handoff.exists() and read(handoff).get('ready_for_training'):return
  status=read(collection/'COLLECTION_STATUS.json') if (collection/'COLLECTION_STATUS.json').exists() else {}
  if status.get('status') in ('pilot_failed','failed','complete_with_rejections'):raise ValueError('Collection is not ready: '+str(status))
  if not wait:raise RuntimeError('Collection is not complete yet. Run again later or omit --no-wait to wait automatically.')
  if time.monotonic()-last>=30:
   print('WAITING FOR FOUR-TASK COLLECTION:',collection,'| saved full episodes:',len(d.get('records',[])),'| no training/test data opened',flush=True);last=time.monotonic()
  time.sleep(5)

def make_split(collection,out,physics_limit=4):
 collection=Path(collection).resolve();out=Path(out);source=read(collection/'DATASET_MANIFEST.json');header=read(collection/'COLLECTION.json');handoff=read(collection/'TRAINING_HANDOFF.json')
 if header.get('protocol')!='four_tasks_yaw_load_v1' or source.get('protocol')!='four_tasks_yaw_load_v1' or not source.get('complete') or not source.get('ready_for_training'):raise ValueError('Expected a completed ready four-task collection.')
 if source.get('features')!=FEATURES or handoff.get('features')!=FEATURES or not np.allclose(handoff['scales'],SCALES):raise ValueError('Feature/encoding contract differs.')
 if handoff.get('task_order')!=TASK_ORDER:raise ValueError('Expected task order '+str(TASK_ORDER)+'; detected '+str(handoff.get('task_order')))
 records=[];seen=set()
 for r in source['records']:
  task=r['task_id']
  if task not in TASKS or r['status']!='completed' or not r['accepted']:raise ValueError('Unknown task or unaccepted teacher episode.')
  if not np.isclose(r['strength_scale'],TASKS[task]['strength_scale']):raise ValueError('Task/strength mismatch.')
  if r['split'] not in ('train','validation','test'):raise ValueError('Unexpected original split.')
  key=(task,r['motion_id'])
  if key in seen:raise ValueError('Duplicate task/motion record.')
  seen.add(key)
  local=collection/'tasks'/task/('strength_'+str(round(100*r['strength_scale'])))/r['episode_id']
  folder=local if local.is_dir() else Path(r['folder'])
  cfg=read(folder/'settings.json')
  if cfg.get('task_id')!=task or cfg['split']!=r['split'] or reference_digest(cfg)!=r['reference_sha256']:raise ValueError('Saved episode settings/reference differ from manifest.')
  records.append(dict(r,role=task,original_split=r['split'],folder=str(folder.resolve()),initial_reference_deg=cfg['profile']['start_deg'],shoulder_mode=cfg['profile']['shoulder_mode']))
 counts={};accounting={}
 for task in TASK_ORDER:
  counts[task]={s:dict(episodes=sum(r['role']==task and r['split']==s for r in records),samples=sum(r['samples'] for r in records if r['role']==task and r['split']==s)) for s in ('train','validation','test')}
  if any(v['episodes']==0 for v in counts[task].values()):raise ValueError('Empty split in '+task)
  actual={s:v['episodes'] for s,v in counts[task].items()}
  if actual!=source['planned_counts'][task]:raise ValueError('Episode counts differ from declared collector plan.')
  total=sum(actual.values());accounting[task]=dict(episodes=total,percent={s:100*n/total for s,n in actual.items()})
  refs={s:{r['reference_sha256'] for r in records if r['role']==task and r['split']==s} for s in actual}
  if any(refs[a]&refs[b] for a,b in [('train','validation'),('train','test'),('validation','test')]):raise ValueError('Reference leakage across original splits.')
 physics_ids={}
 for task in TASK_ORDER:
  rr=sorted([r for r in records if r['role']==task and r['split']=='test'],key=lambda r:r['episode_id'])
  if physics_limit==0 or physics_limit>=len(rr):chosen=rr
  else:
   angles=sorted({r['initial_reference_deg'] for r in rr});variants=sorted({r['variant'] for r in rr});ordered=[]
   for offset in range(len(variants)):
    for i,angle in enumerate(angles):
     variant=variants[(i+offset)%len(variants)];ordered.append([r for r in rr if r['initial_reference_deg']==angle and r['variant']==variant])
   chosen=[];index=0
   while len(chosen)<min(physics_limit,len(rr)):
    added=False
    for bucket in ordered:
     if index<len(bucket):chosen.append(bucket[index]);added=True
     if len(chosen)>=min(physics_limit,len(rr)):break
    if not added:break
    index+=1
  physics_ids[task]=[r['motion_id'] for r in chosen]
 manifest=dict(physics_test_ids=physics_ids,physics_test_limit=physics_limit,physics_selection='Metadata-only balanced angle/variant order, fixed before fitting; all held-out force arrays still evaluated',format_version=4,collection=str(collection),source_manifest_sha256=sha(collection/'DATASET_MANIFEST.json'),handoff_sha256=sha(collection/'TRAINING_HANDOFF.json'),task_order=TASK_ORDER,counts=counts,split_accounting=accounting,records=records,split_policy='All accepted full episodes, original splits unchanged; no pilot data, no resplitting',default_collector_ratios=[.7,.1,.2])
 target=out/'SPLIT_LOCK.json'
 if target.exists() and read(target)!=manifest:raise ValueError('Locked dataset changed; preserve this study and start a new one.')
 write(target,manifest);return manifest

class DataAccess:
 def __init__(self,out,manifest):self.out=Path(out);self.manifest=manifest
 def rows(self,role,split):return sorted([r for r in self.manifest['records'] if r['role']==role and r['split']==split],key=lambda r:r['motion_id'])
 def physics_rows(self,role):
  ids=set(self.manifest['physics_test_ids'][role]);return [r for r in self.rows(role,'test') if r['motion_id'] in ids]
 def verify_test_seal(self):
  p=self.out/'FINAL_MODELS_FROZEN.json'
  if not p.exists():raise PermissionError('Test data are sealed until ALL models and lambda selection finish.')
  seal=read(p)
  if seal['split_sha256']!=sha(self.out/'SPLIT_LOCK.json') or seal['protocol_sha256']!=sha(self.out/'PROTOCOL.json'):raise ValueError('Frozen split/protocol changed.')
  for path,h in seal['checkpoints'].items():
   if sha(self.out/path)!=h:raise ValueError('Frozen model/selection changed: '+path)
 def load(self,role,split,phase='development'):
  if split=='test':
   if phase!='final_test':raise PermissionError('Test arrays cannot be opened during training or validation.')
   self.verify_test_seal()
  elif split not in ('train','validation') or phase=='ewc' and split!='train':raise PermissionError('Importance uses training rows only.')
  records=self.rows(role,split)
  if not records:raise ValueError('No rows for '+role+'/'+split)
  xs=[];ys=[];ids=[]
  for r in records:
   file=Path(r['folder'])/'training_arrays.npz'
   if sha(file)!=r['arrays_sha256']:raise ValueError('Episode array checksum changed: '+str(file))
   with np.load(file,allow_pickle=False) as z:
    x=z['X_raw'];y=z['y_force_N'];t=z['time_s']
    if list(z['feature_names'])!=FEATURES or x.shape!=(len(t),28) or y.shape!=(len(t),1) or len(t)!=r['samples']:raise ValueError('Episode shape/schema mismatch.')
    if not np.isfinite(x).all() or not np.isfinite(y).all() or not np.all(np.diff(t)>0) or not np.allclose(x[:,21],r['strength_scale']) or y.min()<0 or y.max()>650.0001:raise ValueError('Invalid physical samples.')
    xs.append(encode(x));ys.append(y.astype(np.float32)/650.);ids.append(np.repeat(r['motion_id'],len(t)))
  with (self.out/'DATA_ACCESS.jsonl').open('a',encoding='utf-8') as f:f.write(json.dumps(dict(time=time.time(),phase=phase,task=role,split=split,motion_ids=[r['motion_id'] for r in records]))+'\n')
  return np.concatenate(xs),np.concatenate(ys),np.concatenate(ids)
