"""Reports are independent of training completion; PDF failures never lose results."""
from pathlib import Path
import subprocess, shutil, zipfile, json
from atomic_io import atomic_json

def compile_and_zip(folder, out, zip_name, pdf_name='REPORT.pdf'):
    folder = Path(folder)
    out = Path(out)
    log_name = 'REPORT_COMPILE.log' if pdf_name == 'REPORT.pdf' else Path(pdf_name).stem + '_COMPILE.log'
    status_name = 'REPORT_STATUS.json' if pdf_name == 'REPORT.pdf' else Path(pdf_name).stem + '_STATUS.json'
    status = dict(overleaf_source_saved=True, pdf_status='not_requested_or_pdflatex_unavailable')
    if shutil.which('pdflatex'):
        try:
            with (out / log_name).open('w') as log:
                for _ in range(2):
                    r = subprocess.run(['pdflatex', '-interaction=nonstopmode', '-halt-on-error', 'main.tex'], cwd=folder, stdout=log, stderr=subprocess.STDOUT, timeout=120)
                    if r.returncode:
                        raise RuntimeError('pdflatex failed; source and HTML remain saved. See REPORT_COMPILE.log.')
            shutil.copy2(folder / 'main.pdf', out / pdf_name)
            status['pdf_status'] = 'compiled'
        except Exception as exc:
            status.update(pdf_status='failed', error=str(exc))
            print('PDF WARNING:', exc, flush=True)
    with zipfile.ZipFile(out / zip_name, 'w', zipfile.ZIP_DEFLATED) as z:
        for f in sorted(folder.rglob('*')):
            if f.is_file() and f.suffix not in ('.aux', '.log', '.out', '.toc') and (not (f.name == 'main.pdf' and status['pdf_status'] != 'compiled')):
                z.write(f, f.relative_to(folder))
    atomic_json(out / status_name, status)
    return status

def tex(text):
    mapping = {'\\': '\\textbackslash{}', '_': '\\_', '%': '\\%', '&': '\\&', '#': '\\#', '$': '\\$', '{': '\\{', '}': '\\}', '^': '\\textasciicircum{}', '~': '\\textasciitilde{}'}
    return ''.join((mapping.get(c, c) for c in str(text)))

def recover_saved_reports(out, reason=None):
    """Export saved results only. Never import PyTorch/OpenSim or change weights."""
    import html, math
    out = Path(out)
    result = out / 'TEST_RESULTS.json'
    if not result.exists():
        raise FileNotFoundError('No TEST_RESULTS.json exists. Preserve the folder and provide the error/traceback; this utility does not invent missing tests.')
    data = json.loads(result.read_text())
    rows = data['rows']
    groups = {}
    for r in rows:
        groups.setdefault((r.get('stage', r.get('evaluation', 'unknown')), r.get('task', 'unknown')), []).append(r)
    table = []
    for (stage, task), rr in sorted(groups.items()):
        good = [r['rmse_deg'] for r in rr if r.get('completed') and r.get('rmse_deg') is not None]
        table.append([stage, task, len(rr), len(rr) - len(good), format(sum(good) / len(good), '.4f') if good else 'NA'])
    meta = {}
    candidates = list(out.glob('seed_*/**/policy_inference.json'))
    if candidates:
        meta = json.loads(min(candidates, key=lambda p: len(p.parts)).read_text())
    inputs = meta.get('features', [])
    topology = meta.get('topology', 'See saved checkpoint metadata')
    message = 'Complete saved test matrix' if data.get('complete') else 'PARTIAL saved test results; missing tests are not reconstructed'
    report = out / 'recovered_overleaf'
    report.mkdir(exist_ok=True)
    body = '\\documentclass[10pt]{article}\\usepackage[margin=.7in]{geometry}\\usepackage{longtable,booktabs,hyperref}\\setlength{\\parindent}{0pt}\\begin{document}\\section*{Recovered neural-controller results}' + tex(message) + '\\par Network: ' + tex(topology) + '\\par Output: recorded cable tension. The table reports mean angle RMSE only over completed episodes; failures are separate. NA means no completed episode, never zero error. These exports read saved results only; weights and test results are unchanged.'
    body += '\\small\\begin{longtable}{p{.34\\linewidth}p{.12\\linewidth}rrr}\\toprule Checkpoint & Task & Attempts & Failed & RMSE (deg)\\\\\\midrule'
    body += '\n' + '\n'.join((' & '.join((tex(x) for x in row)) + ' ' + chr(92) * 2 for row in table)) + '\\bottomrule\\end{longtable}'
    if inputs:
        body += '\\textbf{Recorded NN inputs in order:} ' + ', '.join((tex(x) for x in inputs)) + '.\\par '
    body += 'No claim of significant EWC improvement is made without checking retention, adaptation, failures and training-seed variation. Full traces and original source/settings remain adjacent.'
    if reason:
        body += '\\par Export recovery reason: ' + tex(reason)
    body += '\\end{document}'
    (report / 'main.tex').write_text(body, encoding='utf-8')
    page = '<html><meta charset="utf-8"><style>body{max-width:1100px;margin:40px auto;font:17px Georgia}td,th{padding:8px;border:1px solid #aaa}table{border-collapse:collapse}</style><h1>Recovered controller results</h1><p>' + html.escape(message) + '</p><p>' + html.escape(topology) + '</p><table><tr><th>Checkpoint</th><th>Task</th><th>Attempts</th><th>Failed</th><th>Completed RMSE (deg)</th></tr>'
    page += ''.join(('<tr>' + ''.join(('<td>' + html.escape(str(x)) + '</td>' for x in row)) + '</tr>' for row in table)) + '</table><p>Inputs: ' + html.escape(', '.join(inputs)) + '</p><p>Weights and saved test results were not modified. NA is no completed episode.</p></html>'
    (out / 'RECOVERED_REPORT.html').write_text(page, encoding='utf-8')
    compile_and_zip(report, out, 'RECOVERED_OVERLEAF.zip', 'RECOVERED_REPORT.pdf')
    print('RECOVERED WITHOUT RETRAINING:', out / 'RECOVERED_REPORT.html', out / 'RECOVERED_OVERLEAF.zip', flush=True)

def safe_build_report(out, builder):
    try:
        return builder(out)
    except Exception as exc:
        import traceback
        out = Path(out)
        (out / 'REPORT_ERROR.txt').write_text(traceback.format_exc(), encoding='utf-8')
        print('REPORT WARNING: results and weights are saved. Creating compact recovery exports:', exc, flush=True)
        recover_saved_reports(out, str(exc))
