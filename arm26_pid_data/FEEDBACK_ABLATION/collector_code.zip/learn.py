"""CUDA-capable feedforward MLP imitation and selected-parameter Gaussian EWC."""
import runtime_setup
import copy,math,time,io
from pathlib import Path
import numpy as np
import torch
from torch import nn
from atomic_io import atomic_json as write,atomic_bytes
from complex_engine import sha,read
from complex_trajectories import FEATURES,SCALES

class ForceMLP(nn.Module):
    architecture='mlp'
    def __init__(self):
        super().__init__();self.layers=nn.Sequential(nn.Linear(28,64),nn.Tanh(),nn.Linear(64,64),nn.Tanh(),nn.Linear(64,3))
        nn.init.zeros_(self.layers[-1].weight);nn.init.zeros_(self.layers[-1].bias)
        with torch.no_grad():self.layers[-1].bias[0]=math.log(.15/.85)
    def forward(self,x):
        context=x.clone();context[...,2]=0.;context[...,3]=0.
        h=self.layers(context);nominal=torch.sigmoid(h[...,0:1]);kp=.05*torch.nn.functional.softplus(h[...,1:2]);kd=.05*torch.nn.functional.softplus(h[...,2:3])
        return nominal+kp*x[...,2:3]+kd*x[...,3:4]

def new_model(name):
    if name!='mlp':raise ValueError('This study uses the feedforward MLP only.')
    return ForceMLP()

def seed_all(seed):
    torch.manual_seed(seed);np.random.seed(seed)
    if torch.cuda.is_available():torch.cuda.manual_seed_all(seed)
    torch.use_deterministic_algorithms(True)

def choose_device(request):
    if request=='cuda' and not torch.cuda.is_available():raise RuntimeError('CUDA was requested but is unavailable. Activate your CUDA-enabled lstm-py312 environment.')
    return torch.device('cuda:0' if request!='cpu' and torch.cuda.is_available() else 'cpu')

def flatten(model):return torch.cat([p.reshape(-1) for p in model.parameters()])
def ewc_term(model,memory):
    if memory is None:return next(model.parameters()).sum()*0.
    if isinstance(memory,list):return sum(ewc_term(model,m) for m in memory)
    d=flatten(model)[memory['indices']]-memory['anchor']
    return (memory['importance']*d.square()).sum()/(2*memory['parameter_count'])

def memory_digest(memory):
    if memory is None:return None
    import hashlib
    h=hashlib.sha256()
    for m in (memory if isinstance(memory,list) else [memory]):
        h.update(str(m['parameter_count']).encode())
        for k in ('indices','anchor','importance'):h.update(m[k].detach().cpu().numpy().tobytes())
    return h.hexdigest()

def move_memory(memory,device):
    if isinstance(memory,list):return [move_memory(m,device) for m in memory]
    return {k:v.to(device) if torch.is_tensor(v) else v for k,v in memory.items()}

def save_policy(model,folder,meta):
    folder=Path(folder);folder.mkdir(parents=True,exist_ok=True)
    state={k:v.detach().cpu().clone() for k,v in model.state_dict().items()}
    buffer=io.BytesIO();torch.save(dict(state_dict=state,metadata=meta),buffer);atomic_bytes(folder/'policy.pt',buffer.getvalue())
    arrays={}
    for i,l in enumerate(m for m in model.layers if isinstance(m,nn.Linear)):
        arrays['W'+str(i)]=l.weight.detach().cpu().numpy();arrays['b'+str(i)]=l.bias.detach().cpu().numpy()
    buffer=io.BytesIO();np.savez_compressed(buffer,**arrays);atomic_bytes(folder/'policy_inference.npz',buffer.getvalue())
    write(folder/'policy_inference.json',dict(meta,features=FEATURES,encoding='four_task_feedback_v1',scales=SCALES.tolist(),force_cap_N=650,architecture=model.architecture,topology='28 ->64 tanh ->64 tanh ->3 internal heads ->1 cable force',controller_form='sigmoid(nominal)+0.05*softplus(gq)*encoded_error+0.05*softplus(gv)*encoded_velocity_error',output='linear force/650; clipped to 0..650 N only in deployment'))
    return folder/'policy.pt'

def read_policy(path,device):
    checkpoint=torch.load(path,map_location='cpu',weights_only=True);m=new_model(checkpoint['metadata']['identity']['architecture']).to(device);m.load_state_dict(checkpoint['state_dict']);return m

def fit(folder,train,val,args,seed,device,initial=None,memory=None,lam=0.,stage='A_initial'):
    folder=Path(folder);folder.mkdir(parents=True,exist_ok=True)
    identity=dict(architecture=args.architecture,stage=stage,seed=seed,epochs=args.epochs_a if stage.endswith('_initial') else args.epochs_b,lr=args.lr,batch=args.batch_size,lambda_ewc=lam,initial_sha256=sha(initial) if initial else None,split_sha256=sha(args.study/'SPLIT_LOCK.json'),memory_sha256=memory_digest(memory))
    done=folder/'COMPLETE.json'
    if done.exists():
        saved=read(done)
        if saved['identity']!=identity or any(sha(folder/name)!=h for name,h in saved['hashes'].items()):raise ValueError('Completed training artifact changed: '+str(folder))
        print('REUSING COMPLETED TRAINING:',folder,flush=True);return folder/'policy.pt'
    seed_all(seed);model=read_policy(initial,device) if initial else new_model(args.architecture).to(device)
    if initial:write(folder/'INITIALIZATION.json',dict(parent_sha256=sha(initial),start_vector_sha256=__import__('hashlib').sha256(flatten(model).detach().cpu().numpy().tobytes()).hexdigest()))
    # Identical parent weights, optimizer reset, batch permutations and epoch budget
    # are used in both adaptation branches. All training rows are visited each epoch.
    tx=torch.from_numpy(train[0]);ty=torch.from_numpy(train[1]);vx=torch.from_numpy(val[0]);vy=torch.from_numpy(val[1])
    resident=False
    if device.type=='cuda':
        need=sum(t.numel()*t.element_size() for t in (tx,ty,vx,vy));free,_=torch.cuda.mem_get_info(device)
        if need<.35*free:tx=tx.to(device);ty=ty.to(device);vx=vx.to(device);vy=vy.to(device);resident=True
    print('TRAINING DEVICE:',device,'| CUDA-resident:',resident,'| rows per epoch:',len(tx),'| validation rows:',len(vx),flush=True)
    optimizer=torch.optim.Adam(model.parameters(),lr=args.lr,weight_decay=0.);generator=torch.Generator().manual_seed(seed+101)
    history=[];best=float('inf');best_state=None;started=time.monotonic();epochs=identity['epochs']
    if memory is not None:memory=move_memory(memory,device)
    def validation_mse():
        model.eval();total=0.
        with torch.no_grad():
            for offset in range(0,len(vx),8192):
                xb=vx[offset:offset+8192].to(device);yb=vy[offset:offset+8192].to(device);total+=float((model(xb).clamp(0,1)-yb).square().sum())
        return total/len(vx)
    epoch_start=1;training_state=folder/'TRAINING_STATE.pt'
    if training_state.exists():
        resume=torch.load(training_state,map_location=device,weights_only=True)
        if resume['identity']!=identity:raise ValueError('Partial-training protocol changed')
        model.load_state_dict(resume['model']);optimizer.load_state_dict(resume['optimizer']);generator.set_state(resume['generator'].cpu());history=resume['history'];best=resume['best'];best_state=resume['best_state'];best_epoch=resume['best_epoch'];epoch_start=resume['epoch']+1
        print('RESUMING TRAINING AT EPOCH:',epoch_start,flush=True)
    for epoch in range(epoch_start,epochs+1):
        if hasattr(args,"min_free_gb"):
            from scenario_support import require_space
            if epoch==epoch_start or epoch%10==0:require_space(folder,args.min_free_gb)
        model.train();order=torch.randperm(len(tx),generator=generator);mse_total=pen_total=obj_total=0.
        for offset in range(0,len(order),args.batch_size):
            index=order[offset:offset+args.batch_size].to(tx.device);xb=tx[index].to(device);yb=ty[index].to(device);optimizer.zero_grad(set_to_none=True)
            mse=(model(xb).clamp(0,1)-yb).square().mean();pen=ewc_term(model,memory);objective=mse+lam*pen
            if not torch.isfinite(objective):raise FloatingPointError('Nonfinite training objective; no test was accessed.')
            objective.backward();torch.nn.utils.clip_grad_norm_(model.parameters(),5.);optimizer.step()
            mse_total+=float(mse.detach())*len(xb);pen_total+=float(pen.detach())*len(xb);obj_total+=float(objective.detach())*len(xb)
        vmse=validation_mse();row=dict(epoch=epoch,training_force_rmse_N=650*math.sqrt(mse_total/len(tx)),validation_force_rmse_N=650*math.sqrt(vmse),training_mse_normalized=mse_total/len(tx),ewc_unweighted=pen_total/len(tx),ewc_weighted=lam*pen_total/len(tx),objective=obj_total/len(tx),elapsed_s=time.monotonic()-started)
        history.append(row)
        if vmse<best:best=vmse;best_state=copy.deepcopy({k:v.detach().cpu() for k,v in model.state_dict().items()});best_epoch=epoch
        write(folder/'HISTORY.json',history)
        # Resume exactly at completed-epoch boundaries; no hidden state spans epochs.
        import os,tempfile
        fd,temp_name=tempfile.mkstemp(prefix='training_',suffix='.pt',dir=folder);os.close(fd)
        try:
            torch.save(dict(identity=identity,epoch=epoch,model=model.state_dict(),optimizer=optimizer.state_dict(),generator=generator.get_state(),history=history,best=best,best_state=best_state,best_epoch=best_epoch),temp_name)
            for attempt in range(8):
                try:os.replace(temp_name,training_state);break
                except PermissionError:
                    if attempt==7:raise
                    time.sleep(min(.025*2**attempt,.4))
        finally:
            Path(temp_name).unlink(missing_ok=True)
        print(f"{stage} | seed{seed} | epoch {epoch}/{epochs} | train {row['training_force_rmse_N']:.4f}N | val {row['validation_force_rmse_N']:.4f}N | lambda {lam:g} | ETA {(time.monotonic()-started)/epoch*(epochs-epoch)/60:.1f} min",flush=True)
    model.load_state_dict(best_state);meta=dict(identity=identity,best_epoch=best_epoch,validation_selection='lowest current-task validation force MSE; no test access',parameter_count=sum(p.numel() for p in model.parameters()),training_samples=len(tx),validation_samples=len(vx),all_training_rows_each_epoch=True)
    def final_mse(x,y,ids):
        model.eval();total=0.
        with torch.no_grad():
            for j in range(0,len(x),8192):total+=float((model(x[j:j+8192].to(device)).clamp(0,1)-y[j:j+8192].to(device)).square().sum())
        return total/len(x)
    write(folder/'BEST_CHECKPOINT_METRICS.json',dict(best_epoch=best_epoch,train_force_rmse_N=650*math.sqrt(final_mse(tx,ty,train[2])),validation_force_rmse_N=650*math.sqrt(final_mse(vx,vy,val[2])),test_accessed=False))
    save_policy(model,folder,meta)
    if memory is not None:
        groups=memory if isinstance(memory,list) else [memory]
        write(folder/'PROTECTED_DRIFT.json',[dict(rms_selected_parameter_change=float(torch.sqrt(torch.mean((flatten(model)[m['indices']]-m['anchor']).square())).detach()),selected_count=len(m['indices'])) for m in groups])
    write(done,dict(identity=identity,hashes={name:sha(folder/name) for name in ('policy.pt','policy_inference.npz','policy_inference.json','HISTORY.json','BEST_CHECKPOINT_METRICS.json')}));return folder/'policy.pt'

def importance_memory(model,training_x,folder,args,seed,device,parent,training_ids=None):
    folder=Path(folder);mp=folder/'ewc_memory.npz';jp=folder/'EWC_MEMORY.json'
    if mp.exists() and jp.exists():
        saved=read(jp)
        if saved['parent_sha256']!=sha(parent) or saved['memory_sha256']!=sha(mp) or saved['fraction']!=args.protect_fraction or saved['requested_samples']!=args.fisher_samples:raise ValueError('EWC memory identity changed.')
        with np.load(mp,allow_pickle=False) as z:return dict(indices=torch.from_numpy(z['indices'].copy()),anchor=torch.from_numpy(z['anchor'].copy()),importance=torch.from_numpy(z['importance'].copy()),parameter_count=int(z['parameter_count']))
    previous_cudnn=torch.backends.cudnn.enabled
    torch.backends.cudnn.enabled=False  # recurrent Jacobians require differentiable training backend
    model.eval();rng=np.random.default_rng(seed+301);n=min(args.fisher_samples,len(training_x));rows=np.sort(rng.choice(len(training_x),n,replace=False));params=list(model.parameters());accum=torch.zeros(sum(p.numel() for p in params),dtype=torch.float64,device=device)
    # Per-example output Jacobian, not squared gradient of a whole minibatch loss.
    for i,index in enumerate(rows):
        example=training_x[index:index+1]
        value=model(torch.from_numpy(example).to(device)).sum();grads=torch.autograd.grad(value,params);g=torch.cat([x.reshape(-1) for x in grads]);accum+=g.detach().double().square()
        if (i+1)%128==0:print('EWC importance samples:',i+1,'/',n,flush=True)
    torch.backends.cudnn.enabled=previous_cudnn
    raw=(accum/n).cpu().numpy();mean=float(raw.mean())
    if not np.isfinite(mean) or mean<=0:raise ValueError('No finite positive Fisher sensitivity.')
    count=max(1,int(math.ceil(args.protect_fraction*len(raw))));selected=np.sort(np.argsort(-raw,kind='stable')[:count]);anchor=flatten(model).detach().cpu().numpy()[selected].copy();weights=(raw[selected]/mean).astype(np.float32)
    buffer=io.BytesIO();np.savez_compressed(buffer,indices=selected.astype(np.int64),anchor=anchor,importance=weights,parameter_count=np.array(len(raw)));atomic_bytes(mp,buffer.getvalue())
    write(jp,dict(parent_sha256=sha(parent),memory_sha256=sha(mp),fraction=args.protect_fraction,selected_count=count,parameter_count=len(raw),requested_samples=args.fisher_samples,used_samples=n,training_sample_indices=rows.tolist(),raw_fisher_mean=mean,estimator='expected Gaussian output Fisher, unit variance in normalized force; per-example squared output Jacobian, global-mean normalization',formula='lambda/(2P) sum_i_in_selected_subset (F_i/mean(F))*(theta_i-theta_task_i)^2',recurrent_importance_context_steps=0, no_replay_examples_stored=True,anchor_values_stored=count))
    return dict(indices=torch.from_numpy(selected.astype(np.int64)),anchor=torch.from_numpy(anchor),importance=torch.from_numpy(weights),parameter_count=len(raw))

