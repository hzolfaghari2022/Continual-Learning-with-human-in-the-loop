"""Reconstruct hash-matched test references and run sealed saved models. No training."""
import argparse,json,sys,shutil,time
from pathlib import Path
from types import SimpleNamespace
from complex_engine import read,write,sha,ROOT
from task_plan import make_episode
from four_trajectories import reference_digest
from scenario_support import evaluation_specs,require_space
from evaluate_study import rollout

def specs(order):
 return [("initial","C_30")]+[(label,task) for label in ["after_D_noEWC","after_D_EWC","after_A_noEWC","after_A_EWC"] for task in ["C_30","D_45"]]

def main():
 p=argparse.ArgumentParser(description=__doc__)
 p.add_argument('--study',type=Path,required=True);p.add_argument('--out',type=Path)
 p.add_argument('--report-only',action='store_true');p.add_argument('--no-github',action='store_true')
 p.add_argument('--plan-only',action='store_true');p.add_argument('--no-test-viewer',action='store_true')
 p.add_argument('--min-free-gb',type=float,default=2);p.add_argument('--episode-timeout',type=float,default=600)
 a=p.parse_args();study=a.study.resolve();out=(a.out or study/'FEEDBACK_ABLATION').resolve()
 if out==study:raise ValueError('Recovery must have a separate output folder.')
 
 if a.report_only:
  from ablation_report import build_report
  build_report(out);return
 protocol=read(study/'PROTOCOL.json');split=read(study/'SPLIT_LOCK.json');seal=read(study/'FINAL_MODELS_FROZEN.json')
 def verify():
  if sha(study/'PROTOCOL.json')!=seal['protocol_sha256'] or sha(study/'SPLIT_LOCK.json')!=seal['split_sha256']:raise ValueError('Original study metadata changed.')
  for name,digest in seal['checkpoints'].items():
   if sha(study/name)!=digest:raise ValueError('Saved model/selection changed: '+name)
 verify()
 if sha(ROOT/'arm26_exosuit.osim')!=protocol['model_sha256']:raise ValueError('OpenSim model differs.')
 for name in ['complex_engine.py','complex_trajectories.py','four_trajectories.py','policy_numpy.py','add_dumbbell.py','strength_scaling.py']:
  if sha(ROOT/('BASE_'+name if name in ['complex_engine.py','policy_numpy.py'] else name))!=protocol['code_hashes'][name]:raise ValueError('Physics/inference source differs: '+name)
 defaults=SimpleNamespace(seed=2026110704,initial_errors=[-2.,0.,2.],initial_velocities=[-15.,0.,15.],mass_kg=5.,dt=.005,muscle_excitation=.1,rmse_limit=.1,max_error_limit=2.5)
 configs={}
 for r in split['records']:
  if r['split']!='test':continue
  condition=dict(task_id=r['task_id'],variant=r['variant'],start_deg=r['initial_reference_deg'],key=r['condition'])
  cfg=make_episode(defaults,condition,'test',int(r['episode_id'].rsplit('_',1)[1]),r['selected_speed_scale']/r['requested_speed_scale'])
  if reference_digest(cfg)!=r['reference_sha256']:raise ValueError('Cannot reproduce reference: '+r['episode_id'])
  configs[r['episode_id']]=cfg
 print('VERIFIED: original model seal; 128/128 test references reconstructed. NO TRAINING.',flush=True)
 out.mkdir(parents=True,exist_ok=True)
 identity=dict(source_study=str(study),seal_sha256=sha(study/'FINAL_MODELS_FROZEN.json'),feedback_scales=[1.,.5,0.],code_hashes={p.name:sha(p) for p in ROOT.glob('*.py')})
 marker=out/'RECOVERY_IDENTITY.json'
 if marker.exists() and read(marker)!=identity:raise ValueError('Output belongs to another recovery.')
 write(marker,identity)
 note='DIAGNOSTIC DEPLOYMENT ABLATION. Scales 1,0.5,0 multiply only explicit learned kp/kd error correction. Nominal head retains actual-state, integrated-error and previous-tension inputs; scale0 is NOT open-loop control. Both branches use identical scales, references, physical limits and frozen models. Original lambda selection failed its adaptation constraint. No statistical significance from one seed. Recovery evaluation: all 128 test reference digests were reproduced from collector defaults and saved speed settings. Physical tests use the original preselected 16 references and sealed models. Deleted original teacher force arrays were not recovered; original offline force accuracy is unavailable. No retraining, reselection of lambda, or weight updates were performed.'
 write(out/'ABLATION_NOTE.json',dict(note=note,reference_matches=len(configs),offline_force_evaluation='unavailable'))
 write(out/'PROTOCOL.json',protocol)
 if a.plan_only:print('Preflight passed; remove --plan-only to execute 108 rollouts per seed.');return
 a.architecture=protocol['architecture'];a.tracking_rmse_deg=protocol['tracking_rmse_deg'];a.tracking_max_deg=protocol['tracking_max_deg']
 access=SimpleNamespace(verify_test_seal=verify);rows=[]
 total=len(specs(protocol['training_order']))*protocol['test_episodes_per_task']*len(protocol['seeds'])*3;i=0;started=time.monotonic()
 for seed in protocol['seeds']:
  base=study/f'seed_{seed}';sel=read(base/'SELECTED_CL.json')
  dst=out/f'seed_{seed}';dst.mkdir(exist_ok=True);write(dst/'SELECTED_CL.json',sel)
  for original_label,task in specs(protocol['training_order']):
   for scale in [1.,.5,0.]:
    label=original_label
    branch='EWC' if label.endswith('_EWC') else 'noEWC'
    letter='C' if label=='initial' else label.split('_')[1]
    checkpoint=base/'saved_models'/branch/f'after_{letter}'/'policy.pt'
    if checkpoint.relative_to(study).as_posix() not in seal['checkpoints']:raise ValueError('Exported model not sealed.')
    ids=split['physics_test_ids'][task]
    records=sorted([r for r in split['records'] if r['motion_id'] in ids and r['task_id']==task],key=lambda r:r['motion_id'])
    if len(records)!=protocol['test_episodes_per_task']:raise ValueError('Wrong physical subset size.')
    for original in records:
     require_space(out,a.min_free_gb);r=dict(original);folder=out/'references'/r['motion_id'];folder.mkdir(parents=True,exist_ok=True)
     cfg=dict(configs[r['motion_id']]);cfg['feedback_scale']=scale;folder=folder/('scale_'+str(scale));folder.mkdir(exist_ok=True);write(folder/'settings.json',cfg);r['folder']=str(folder)
     i+=1;print(f'FROZEN RECOVERY TEST {i}/{total} | {label} | {task} | feedback={scale:g} | elapsed {(time.monotonic()-started)/60:.1f} min',flush=True)
     row=rollout(access,r,checkpoint,out/'evaluations'/f'seed_{seed}'/('scale_'+str(scale))/(label+'__'+task)/r['motion_id'],task,label,seed,a)
     row.update(stage=label,feedback_scale=scale,recovery_reference=True);rows.append(row);write(out/'TEST_RESULTS.json',dict(complete=False,rows=rows,recovery_note=note))
 verify();write(out/'TEST_RESULTS.json',dict(complete=True,rows=rows,recovery_note=note))
 from ablation_report import build_report
 build_report(out)
 print('COMPLETE:',out/'REPORT.html','|',out/'OVERLEAF_REPORT.zip',flush=True)
 if not a.no_github:
  try:
   from github_backup import GitBackup
   GitBackup('https://github.com/hzolfaghari2022/Continual-Learning-with-human-in-the-loop.git',out,'arm26-feedback-ablation',Path.home()/'Arm26_Ablation_Backup_Cache').sync(ROOT,final_status='complete')
  except Exception as exc:print('BACKUP FAILED; local results saved:',exc,flush=True)
if __name__=='__main__':main()
