Run START_ABLATION.bat from activated lstm-py312, or run_ablation.py --study PATH.
NO TRAINING OR COLLECTION. Original study is read-only; new FEEDBACK_ABLATION subfolder.
108 OpenSim rollouts:3 multipliers x4 references x9 checkpoint/task groups.
Initial C(shared), afterD noEWC/EWC onC,D, finalafterA noEWC/EWC onC,D. Same4original references each task. Final returns frozen. Fullfeedback re-run to match ablation implementation. Multipliers1,.5,0 applied ONLY to explicit kp/kd correction. Nominal head keeps state/integratederror/previousforce. Not openloop and not trained feedforward. Otherphysics unchanged.
Expect roughly an hour or longer depending PC; no guaranteed runtime or EWC advantage. Viewer on; --no-test-viewer optional.
--plan-only verifies metadata, ALLsealed files, model/sourcebase hashes and128reference digests without physics. Same command resumes completed cases. --out "D:\Ablation" optional; retain same out forresume. --min-free-gb default2 reserve, not total space prediction. --report-only regenerates reports without physics. Report HTML+Overleaf,2figures,metrics table withfailures/maxerror/saturation. Single seed, lambda1 adaptationconstraintFAILED disclosed.
GitHub backup attempted after reports; --no-github skips. Failure printed, localresults preserved. No guaranteed remote backup. Original model weights are not included; point to your saved study.
This is a diagnostic experiment, not proof continual learning is necessary. Retain ALL results. Do not retune heldout tests to force baselinefailure.
Future directforce training and physically changed tasks require separate validation experiments; not performed by this runner.
