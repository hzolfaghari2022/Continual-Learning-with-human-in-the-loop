"""CDBA ordering, explicit stage exports, and operational storage checks."""
from pathlib import Path
import hashlib,json,shutil

def require_space(folder,minimum_gb):
    free=shutil.disk_usage(Path(folder)).free/2**30
    print(f'STORAGE: {free:.2f} GiB free | reserve {minimum_gb:g} GiB',flush=True)
    if free < minimum_gb:
        raise OSError(f'Low disk space: {free:.2f} GiB free. Free space, then resume the same study; saved models/tests are retained.')

def evaluation_specs(order):
    # At the final checkpoint, perform the current task A, then return to C,D,
    # then test B. No fitting or importance update occurs during these visits.
    specs=[('initial',order[0])]
    for stage,task in enumerate(order[1:],2):
        for branch in ('noEWC','EWC'):
            tasks=order[:stage] if stage<len(order) else [task,order[0],order[1],order[2]]
            specs += [(f'after_{task[0]}_{branch}',t) for t in tasks]
    return specs

def export_models(base,paths,order):
    from atomic_io import atomic_json
    base=Path(base);entries=[]
    for i,task in enumerate(order):
        for branch in ('noEWC','EWC'):
            key='initial' if i==0 else f'after_{task[0]}_{branch}'
            source=Path(paths[key]).parent;dest=base/'saved_models'/branch/f'after_{task[0]}'
            dest.mkdir(parents=True,exist_ok=True);hashes={}
            for name in ('policy.pt','policy_inference.npz','policy_inference.json'):
                data=(source/name).read_bytes();digest=hashlib.sha256(data).hexdigest()
                if (dest/name).exists() and hashlib.sha256((dest/name).read_bytes()).hexdigest()!=digest:
                    raise ValueError('Exported model changed: '+str(dest/name))
                if not (dest/name).exists():shutil.copy2(source/name,dest/name)
                hashes[name]=digest
            entries.append(dict(task=task,branch=branch,learned_tasks=order[:i+1],checkpoint=str(dest/'policy.pt'),source=str(source/'policy.pt'),sha256=hashes))
    atomic_json(base/'SAVED_MODELS.json',dict(training_order=order,meaning='Sequential stage snapshots, not independently trained task specialists. Initial C is shared by both branches.',models=entries))
