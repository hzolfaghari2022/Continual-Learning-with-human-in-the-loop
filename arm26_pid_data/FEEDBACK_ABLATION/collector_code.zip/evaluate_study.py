"""Final-test-only offline forces and actual frozen-policy OpenSim rollouts."""
import csv,hashlib,time
from pathlib import Path
import numpy as np
from complex_engine import read,write,sha,load_network,ROOT
from complex_trajectories import reference_digest
from process_helpers import run_logged

def inference_hashes(folder):return {n:sha(Path(folder)/n) for n in ('policy.pt','policy_inference.npz','policy_inference.json')}
def offline(access,model_folder,role,label,out,split='test'):
    # Guard first; offline force prediction is still test access.
    x,y,ids=access.load(role,split,phase='final_test')
    from policy_numpy import NumpyPolicy
    policy=NumpyPolicy(Path(model_folder)/'policy_inference.npz')
    prediction=policy.predict(x,ids);target=y[:,0]*650;clipped=np.clip(prediction,0,650);error=clipped-target
    rows=[]
    for mid in sorted(set(ids)):
        mask=ids==mid;rows.append(dict(motion_id=str(mid),samples=int(mask.sum()),rmse_N=float(np.sqrt(np.mean(error[mask]**2))),mae_N=float(np.mean(abs(error[mask])))))
    file=Path(out)/(label+('_supplementary_test' if split=='supplementary_test' else '')+'_offline.npz');np.savez_compressed(file,target_N=target,prediction_N=clipped,raw_prediction_N=prediction,motion_id=ids)
    write(file.with_suffix('.json'),dict(role=role,label=label,evaluation_set=split,rows=rows,rmse_N=float(np.sqrt(np.mean(error**2))),note='PID-state teacher-forced force prediction. This does not establish closed-loop tracking.'))
    return file

def rollout(access,record,checkpoint,out,role,label,seed,args):
    access.verify_test_seal();out=Path(out);out.mkdir(parents=True,exist_ok=True);settings=read(Path(record['folder'])/'settings.json')
    if reference_digest(settings)!=record['reference_sha256']:raise ValueError('Reference digest mismatch.')
    settings.update(neural_checkpoint=str(Path(checkpoint).resolve()),live_viewer=not args.no_test_viewer,save_plots=True,split=record['split'],original_collection_split=record['original_split'],controller='frozen_'+args.architecture+'_'+label,accept_rmse_deg=args.tracking_rmse_deg,accept_max_error_deg=args.tracking_max_deg)
    settings.pop('muscle_strength_audit',None);identity=dict(checkpoint_sha256=sha(checkpoint),inference_hashes=inference_hashes(Path(checkpoint).parent),reference_sha256=record['reference_sha256'],settings_sha256=hashlib.sha256(__import__('json').dumps({k:v for k,v in settings.items() if k!='live_viewer'},sort_keys=True).encode()).hexdigest())
    marker=out/'EVALUATION_COMPLETE.json'
    if marker.exists():
        old=read(marker)
        if old['identity']!=identity or any(sha(out/n)!=h for n,h in old['hashes'].items()):raise ValueError('Existing evaluation changed: '+str(out))
        status=read(out/'status.json');print('REUSING VERIFIED FROZEN TEST:',out.name,flush=True)
    else:
        # Keep any partial interrupted attempt; never silently discard it.
        if any(out.iterdir()):
            archive=out.parent/'interrupted';archive.mkdir(exist_ok=True);out.rename(archive/(out.name+'_'+str(time.time_ns())));out.mkdir()
        write(out/'settings.json',settings)
        run_logged([__import__('sys').executable,ROOT/'complex_engine.py','--worker',out],out/'console.log',allowed=(0,2),timeout=args.episode_timeout)
        status=read(out/'status.json')
        if status['status']=='failed' and 'live_viewer.py' in status.get('error',''):raise RuntimeError('Visualization failed. Completed training is preserved. Fix the viewer or resume with --no-test-viewer. Details: '+str(out/'error.txt'))
        if status.get('export_error'):raise RuntimeError('Test export failed: '+str(out/'status.json')+'\n'+status['export_error'])
        if status['status']=='failed' and any(t in status.get('error','') for t in ('OSError:', 'PermissionError:', 'No space left', 'MemoryError:')):raise RuntimeError('Test storage/infrastructure failed; resume after fixing it:\n'+status['error'])
        if status['status']=='failed' and any(t in status.get('error','') for t in ('ImportError','ModuleNotFoundError','AttributeError','TypeError')):raise RuntimeError('Test infrastructure failed, not a controller result:\n'+status['error'])
        if not status.get('frozen_weights_verified'):raise ValueError('Worker did not verify frozen model identity.')
        files=['settings.json','status.json']+[n for n in ('signals.csv','training_arrays.npz','states.sto','tracking.pdf') if (out/n).exists()]
        write(marker,dict(identity=identity,hashes={n:sha(out/n) for n in files}))
    if inference_hashes(Path(checkpoint).parent)!=identity['inference_hashes']:raise ValueError('Controller weights changed during test.')
    complete=status['status']=='completed';motion=status.get('motion_only') or {};all_samples=status.get('all_samples') or {}
    return dict(seed=seed,evaluation=label,evaluation_set=record['split'],task=role,motion_id=record['motion_id'],trajectory=record['trajectory'],initial_reference_deg=record['initial_reference_deg'],shoulder_mode=record['shoulder_mode'],status=status['status'],completed=complete,tracking_passed=status['tracking_passed'],rmse_deg=motion.get('rmse_deg') if complete else None,partial_rmse_deg=motion.get('rmse_deg') if not complete else None,max_error_deg=all_samples.get('max_abs_error_deg'),saturation_percent=motion.get('saturation_percent'),samples=status['sample_count'],expected_samples=record['samples'],folder=str(out),teacher_folder=record['folder'],error=status.get('error'),frozen_verified=True,cartesian_rmse_m=status.get('cartesian_motion_rmse_m'))
