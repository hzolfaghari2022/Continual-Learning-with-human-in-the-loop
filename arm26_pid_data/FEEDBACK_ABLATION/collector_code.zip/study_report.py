"""Three-page article with exactly two figures; detailed diagnostics stay separate."""
import csv,html,io,json,shutil,subprocess,zipfile
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from atomic_io import atomic_bytes
from complex_engine import read,write
from complex_trajectories import FEATURES,SCALES,MUSCLES
from study_data import TASK_ORDER
STAGES=['initial']+[f'after_{letter}_{branch}' for letter in 'BCD' for branch in ('noEWC','EWC')]
NAMES={'initial':'Initial A (no adaptation)'}|{f'after_{letter}_{branch}':f'After {letter}: '+('no EWC' if branch=='noEWC' else 'EWC') for letter in 'BCD' for branch in ('noEWC','EWC')}
MEANINGS=['Actual elbow angle','Actual elbow velocity','Elbow reference angle','Elbow reference velocity','Elbow reference acceleration','Dumbbell mass','Actual shoulder angle','Previous applied cable tension','Bounded integrated tracking error']+[m+' activation' for m in MUSCLES]+[m+' normalized fiber length' for m in MUSCLES]+['Known muscle strength ratio','Prescribed shoulder velocity','Prescribed shoulder acceleration','Yaw carrier angle','Yaw carrier velocity','Yaw carrier acceleration','Known external vertical force']
UNITS=['rad','rad/s','rad','rad/s','rad/s2','kg','rad','N','rad s']+['unitless']*12+['ratio','rad/s','rad/s2','rad','rad/s','rad/s2','N']

def tex(value):
 value=str(value)
 for a,b in [('\\',r'\textbackslash{}'),('_',r'\_'),('%',r'\%'),('&',r'\&'),('#',r'\#')]:value=value.replace(a,b)
 return value

def csv_rows(path):
 if not Path(path).exists():return []
 with Path(path).open() as f:return list(csv.DictReader(f))

def build_report(out):
 out=Path(out);protocol=read(out/'PROTOCOL.json');split=read(out/'SPLIT_LOCK.json');results=read(out/'TEST_RESULTS.json')
 if not results.get('complete'):raise ValueError('Final tests must finish before generating the final report.')
 rows=results['rows'];report=out/'overleaf';report.mkdir(exist_ok=True);plots=out/'plots';plots.mkdir(exist_ok=True);figures=[]
 plt.rcParams.update({'font.family':'serif','font.size':10,'pdf.fonttype':42})
 def save(fig,name,caption):
  fig.tight_layout()
  for ext in ('png','pdf'):
   buf=io.BytesIO();fig.savefig(buf,format=ext,dpi=150,bbox_inches='tight');atomic_bytes(plots/(name+'.'+ext),buf.getvalue())
  plt.close(fig);figures.append((name,caption))
 summary=[]
 for stage in STAGES:
  for task in TASK_ORDER:
   rr=[r for r in rows if r['stage']==stage and r['task']==task]
   if not rr:continue
   vals=[r['rmse_deg'] for r in rr if r['completed'] and r['rmse_deg'] is not None]
   summary.append(dict(stage=stage,task=task,attempted=len(rr),completed=len(vals),failed=len(rr)-len(vals),tracking_passed=sum(bool(r['tracking_passed']) for r in rr),mean_rmse_deg=float(np.mean(vals)) if vals else None,std_rmse_deg=float(np.std(vals)) if vals else None))
 write(out/'SUMMARY.json',dict(rows=summary,note='RMSE across completed episodes only; all attempted failures counted. Frozen initial A on B/C/D is zero-update transfer, not learned-task retention.'))
 for name,data in [('TRACKING_STATISTICS.csv',summary),('TEST_EPISODES.csv',rows)]:
  with (out/name).open('w',newline='') as f:w=csv.DictWriter(f,fieldnames=list(data[0]));w.writeheader();w.writerows(data)
 contract=[dict(index=i+1,name=FEATURES[i],meaning=MEANINGS[i],unit=UNITS[i],divisor=float(SCALES[i]),override=('(reference-actual)/0.02 rad' if i==2 else '(reference velocity-actual velocity)/0.2 rad/s' if i==3 else None)) for i in range(28)]
 write(out/'NETWORK_INPUT_OUTPUT.json',dict(topology='28 ->64 tanh ->64 tanh ->3 internal feedback heads ->1 force',parameter_count=6211,inputs=contract,outputs=[dict(name='exo_flexor',unit='N',range=[0,650],training_target='force/650')],recurrent_hidden_state=False,feedback_states=['previous NN-applied tension','bounded integrated tracking error'],shoulder='prescribed, not learned'))
 selections={str(seed):read(out/f'seed_{seed}/SELECTED_CL.json') for seed in protocol['seeds']};write(out/'LAMBDA_SELECTION.json',selections)
 lookup={(r['stage'],r['task']):r for r in summary};matrix=np.full((len(STAGES),4),np.nan)
 for i,stage in enumerate(STAGES):
  for j,task in enumerate(TASK_ORDER):
   r=lookup.get((stage,task))
   if r and r['mean_rmse_deg'] is not None:matrix[i,j]=r['mean_rmse_deg']
 fig,ax=plt.subplots(figsize=(10,4.5));cmap=plt.get_cmap('YlOrRd').copy();cmap.set_bad('#eeeeee');finite=matrix[np.isfinite(matrix)];vmax=max(1e-3,float(finite.max())) if len(finite) else 1.
 im=ax.imshow(np.ma.masked_invalid(matrix),cmap=cmap,vmin=0,vmax=vmax,aspect='auto');ax.set_xticks(range(4),TASK_ORDER);ax.set_yticks(range(len(STAGES)),[NAMES[s] for s in STAGES]);ax.set_title('Held-out angle tracking and simulation completion')
 for i,stage in enumerate(STAGES):
  for j,task in enumerate(TASK_ORDER):
   r=lookup.get((stage,task))
   text=('Not evaluated' if not r else ('RMSE N/A' if r['mean_rmse_deg'] is None else f"{r['mean_rmse_deg']:.3f} deg")+f"\n{r['failed']}/{r['attempted']} failed")
   ax.text(j,i,text,ha='center',va='center',fontsize=9,color='white' if np.isfinite(matrix[i,j]) and matrix[i,j]>.65*vmax else 'black')
 if len(finite):fig.colorbar(im,ax=ax,label='Completed-episode RMSE (deg)')
 save(fig,'tracking_matrix','Angle RMSE is shown only for completed episodes; each cell also counts failed attempts. Initial A tested on B/C/D is a frozen no-adaptation baseline.')
 # Compact examples selected by identifiers, without consulting performance.
 examples=[];fig,axs=plt.subplots(4,2,figsize=(10,8.8));short={'initial':'Frozen A','after_D_noEWC':'Final no EWC','after_D_EWC':'Final EWC'}
 for i,task in enumerate(TASK_ORDER):
  rr=[r for r in rows if r['task']==task and r['stage'] in short];key=min((r['seed'],r['motion_id']) for r in rr);rr=[r for r in rr if (r['seed'],r['motion_id'])==key];examples.append(dict(task=task,seed=key[0],motion_id=key[1]))
  tr=csv_rows(Path(rr[0]['teacher_folder'])/'signals.csv')
  if tr:axs[i,0].plot([float(x['time_s']) for x in tr],[float(x['reference_deg']) for x in tr],'k--',label='Reference')
  for r in rr:
   trace=csv_rows(Path(r['folder'])/'signals.csv')
   if not trace:continue
   t=[float(x['time_s']) for x in trace];label=short[r['stage']]+(' [partial]' if not r['completed'] else '')
   axs[i,0].plot(t,[float(x['angle_deg']) for x in trace],label=label);axs[i,1].plot(t,[float(x['error_deg']) for x in trace],label=label)
  for j,ax in enumerate(axs[i]):ax.set(title=task+(' angle' if j==0 else ' error'),xlabel='Time (s)',ylabel='Angle (deg)' if j==0 else 'Reference - actual (deg)');ax.grid(alpha=.2);ax.legend(fontsize=7)
 save(fig,'compact_tracking','One fixed identifier-first test per task, not selected for a favorable result. Final no-EWC and EWC networks are compared with the frozen A network. Partial failed traces are labeled.');write(out/'REPORT_EXAMPLES.json',examples)
 # Detailed plots never embedded in the brief Overleaf article.
 development=[]
 for seed in protocol['seeds']:
  base=out/f'seed_{seed}';paths=read(base/'MODEL_PATHS.json');fig,axs=plt.subplots(1,len(STAGES),figsize=(23,3))
  for ax,stage in zip(axs,STAGES):
   folder=Path(paths[stage]).parent;h=read(folder/'HISTORY.json');ax.plot([r['epoch'] for r in h],[r['training_force_rmse_N'] for r in h],label='Train');ax.plot([r['epoch'] for r in h],[r['validation_force_rmse_N'] for r in h],label='Validation');ax.set(title=NAMES[stage],xlabel='Epoch',ylabel='Force RMSE (N)');ax.legend(fontsize=7)
   development.append(dict(seed=seed,stage=stage,**read(folder/'BEST_CHECKPOINT_METRICS.json')))
  save(fig,f'learning_seed_{seed}','Force imitation losses for selected checkpoints. These are not autonomous angle-tracking errors.')
  sel=selections[str(seed)];fig,ax=plt.subplots(figsize=(7,3));ax.plot([r['lambda_ewc'] for r in sel['candidates']],[r['score'] for r in sel['candidates']],'o-');ax.axvline(sel['selected_lambda'],color='green',ls='--');ax.set(xscale='log',xlabel='Lambda',ylabel='Joint validation score',title='Whole-sequence validation-only lambda choice');save(fig,f'lambda_seed_{seed}','Predeclared positive candidates evaluated without test access.')
  for stage in ('after_B_EWC','after_C_EWC','after_D_EWC'):
   h=read(Path(paths[stage]).parent/'HISTORY.json');fig,ax=plt.subplots(figsize=(7,3));ax.plot([r['epoch'] for r in h],[r['training_mse_normalized'] for r in h],label='Imitation MSE');ax.plot([r['epoch'] for r in h],[r['ewc_weighted'] for r in h],label='Weighted EWC');ax.set(xlabel='Epoch',ylabel='Loss',title=NAMES[stage]);ax.legend();save(fig,f'penalty_{seed}_{stage}','Measured penalty contribution reveals whether EWC materially affects the objective.')
 write(out/'DEVELOPMENT_METRICS.json',development)
 # Complete per-motion diagnostics remain separate, with equal comparisons.
 grouped={}
 for r in rows:grouped.setdefault((r['seed'],r['task'],r['motion_id']),[]).append(r)
 paired=[]
 for index,((seed,task,mid),rr) in enumerate(sorted(grouped.items())):
  fig,axs=plt.subplots(3,1,figsize=(9,7),sharex=True)
  for r in rr:
   trace=csv_rows(Path(r['folder'])/'signals.csv')
   if not trace:continue
   t=[float(x['time_s']) for x in trace];label=NAMES[r['stage']]+(' [partial]' if not r['completed'] else '')
   for ax,column in zip(axs,['angle_deg','error_deg','tension_N']):ax.plot(t,[float(x[column]) for x in trace],label=label)
  tr=csv_rows(Path(rr[0]['teacher_folder'])/'signals.csv')
  if tr:axs[0].plot([float(x['time_s']) for x in tr],[float(x['reference_deg']) for x in tr],'k--',label='Reference')
  for ax,y in zip(axs,['Elbow (deg)','Tracking error (deg)','Cable force (N)']):ax.set_ylabel(y);ax.grid(alpha=.2);ax.legend(fontsize=6)
  axs[-1].set_xlabel('Time (s)');fig.suptitle(f'{task} | seed {seed} | {mid}',fontsize=10);save(fig,f'motion_{index:03d}','Full per-motion stage comparison; failed partial traces remain visible.')
  d={r['stage']:r for r in rr}
  for stage in range(2,5):
   letter=TASK_ORDER[stage-1][0];n=d.get(f'after_{letter}_noEWC');c=d.get(f'after_{letter}_EWC')
   if n and c and n['completed'] and c['completed']:
    item=dict(seed=seed,task=task,motion_id=mid,after_stage=stage,noEWC_rmse_deg=n['rmse_deg'],EWC_rmse_deg=c['rmse_deg'],EWC_improvement_deg=n['rmse_deg']-c['rmse_deg'])
    baseline_stage=TASK_ORDER.index(task)+1
    if baseline_stage<stage:
     for branch,current in [('noEWC',n),('EWC',c)]:
      old=d.get('initial' if baseline_stage==1 else f'after_{task[0]}_{branch}')
      if old and old['completed']:item['forgetting_'+branch]=current['rmse_deg']-old['rmse_deg']
    paired.append(item)
 write(out/'PAIRED_RETENTION.json',dict(rows=paired,note='Only paired completed episodes; interpret together with all failure counts. Positive EWC_improvement is lower EWC angle error.'))
 for file in sorted((out/'evaluations').glob('seed_*/*/*_offline.npz')):
  with np.load(file,allow_pickle=False) as z:target=z['target_N'];pred=z['prediction_N']
  fig,axs=plt.subplots(1,2,figsize=(9,3));ix=np.linspace(0,len(target)-1,min(3000,len(target))).astype(int);axs[0].scatter(target[ix],pred[ix],s=3,alpha=.3);axs[0].plot([0,650],[0,650],'k--');axs[0].set(xlabel='PID force (N)',ylabel='NN force (N)');axs[1].hist(pred-target,bins=50);axs[1].set(xlabel='Force error (N)',ylabel='Samples');save(fig,'force_'+file.parent.parent.name+'_'+file.stem,'Teacher-forced held-out force prediction, separate from closed-loop tracking.')
 # Brief article: design/28-input contract; EWC/results; exactly two figures.
 inputlines=[]
 for i in list(range(9))+[21,22,23]:
  if i==21:inputlines += [r'10--15 & Activations: TRIlong, TRIlat, TRImed, BIClong, BICshort, BRA & unitless \\',r'16--21 & Normalized fiber lengths, same six muscles and order & unitless \\']
  inputlines.append(f'{i+1} & {tex(MEANINGS[i])} & '+tex(UNITS[i]).replace('rad/s2',r'rad/s$^2$')+' '+chr(92)*2)
 inputlines += [r'25--27 & Prescribed yaw angle, velocity, acceleration & rad; rad/s; rad/s$^2$ \\',r'28 & Known external vertical force (D load pulses) & N \\']
 countlines='\n'.join(tex(task)+' & '+' & '.join(str(split['counts'][task][sp]['episodes']) for sp in ('train','validation','test'))+' & '+str(len(split['physics_test_ids'][task]))+' '+chr(92)*2 for task in TASK_ORDER)
 table=[]
 for stage in STAGES:
  cells=[]
  for task in TASK_ORDER:
   r=lookup.get((stage,task));cells.append('--' if r is None else ('NA' if r['mean_rmse_deg'] is None else f"{r['mean_rmse_deg']:.3f}")+f" ({r['failed']}/{r['attempted']})")
  table.append(tex(NAMES[stage])+' & '+' & '.join(cells)+' '+chr(92)*2)
 selected='; '.join(f"seed {seed}: {r['selected_lambda']:g}"+(' (constraint failed)' if not r['adaptation_constraint_met'] else '') for seed,r in selections.items())
 body=BRIEF_TEMPLATE
 replacements={'COUNTS':countlines,'INPUTS':'\n'.join(inputlines),'FRACTION':str(100*protocol['protect_fraction']),'GRID':tex(str(protocol['lambda_grid'])),'TOL':str(protocol['validation_tolerance']),'SELECTED':tex(selected),'LR':str(protocol['lr']),'BATCH':str(protocol['batch_size']),'EPOCHA':str(protocol['epochs_a']),'EPOCHB':str(protocol['epochs_b']),'RESULTS':'\n'.join(table),'SEEDNOTE':('One seed was run; no across-seed uncertainty is claimed.' if len(protocol['seeds'])==1 else 'Episode variation is distinct from training-seed variation.')}
 for a,b in replacements.items():body=body.replace(a,b)
 (report/'main.tex').write_text(body);dest=report/'figures';dest.mkdir(exist_ok=True)
 for name in ('tracking_matrix','compact_tracking'):shutil.copy2(plots/(name+'.pdf'),dest/(name+'.pdf'))
 for name in ('NETWORK_INPUT_OUTPUT.json','TRACKING_STATISTICS.csv','LAMBDA_SELECTION.json'):shutil.copy2(out/name,report/name)
 page='<html><meta charset="utf-8"><title>Arm26 four-task results</title><style>body{max-width:1100px;margin:40px auto;font:17px Georgia}img{max-width:100%}pre{white-space:pre-wrap}</style><h1>Four-task adaptation and retention</h1><p>The Overleaf article contains only two figures. All diagnostics are available below.</p><pre>'+html.escape(json.dumps(summary,indent=2))+'</pre>'
 for name,caption in figures:page+='<figure><img src="plots/'+name+'.png"><figcaption>'+html.escape(caption)+'</figcaption></figure>'
 (out/'DETAILED_REPORT.html').write_text(page+'</html>')
 import base64
 brief='<html><meta charset="utf-8"><title>Four-task NN and EWC</title><style>body{max-width:1050px;margin:35px auto;font:17px Georgia;line-height:1.4}img{max-width:100%}table{border-collapse:collapse}td,th{padding:7px;border:1px solid #aaa}code{font-size:14px}</style><h1>Four-task neural control and retention</h1>'
 brief+='<p><b>Tasks:</b> A: 90% up/down reaches; B: 60% irregular variable-speed motions; C: 30% cross-body yaw sweeps; D: 45% reach-and-hold under external load pulses. The yaw carrier is prescribed and has co-moving muscle origins; it is a simplified movement-plane extension, not a validated anatomical shoulder or collision model. The NN learns elbow cable assistance.</p>'
 brief+='<p><b>Network:</b> 28 inputs, two 64-unit tanh layers, three internal heads (nominal force and positive learned error/velocity gains), one cable-force output, 6,211 parameters. No recurrent hidden state. The bounded force computation is shared by all branches; no PID fallback is used in NN tests.</p>'
 brief+='<p><b>Continual learning:</b> identical A initialization; ordinary fine-tuning versus selective EWC through B, C and D. EWC protects the top '+str(100*protocol['protect_fraction'])+'% of parameters per previous task using training-only squared output Jacobians and selected anchors, with no replay. Loss adds λ/(2P) Σ importance × (weight − anchor)². D protects A+B+C.</p>'
 brief+='<p><b>Lambda:</b> '+html.escape(str({seed:r['selected_lambda'] for seed,r in selections.items()}))+'. Grid '+html.escape(str(protocol['lambda_grid']))+'; choose from whole-sequence validation force errors before test access, subject to current-task adaptation constraints. Ten has no universal special status. A lower force-validation score does not guarantee better closed-loop tracking.</p>'
 brief+='<p><b>Validation checks:</b> adaptation constraint met: '+html.escape(str({seed:r['adaptation_constraint_met'] for seed,r in selections.items()}))+'; selected joint score improves on no-EWC: '+html.escape(str({seed:r['selected_improves_validation_score'] for seed,r in selections.items()}))+'. A failed constraint is a reported fallback, not a successful constraint check.</p>'
 brief+='<p><b>Scope:</b> all original held-out force samples are evaluated; physical tests use the metadata-selected subset '+html.escape(str({t:len(split['physics_test_ids'][t]) for t in TASK_ORDER}))+'. Results below show completed-episode mean angle RMSE in degrees and failed/attempted counts. NA means no completed episode, never zero error. Strong EWC benefit is measured, not imposed.</p><table><tr><th>Checkpoint</th>'+''.join('<th>'+t+'</th>' for t in TASK_ORDER)+'</tr>'
 for stage in STAGES:
  brief+='<tr><td>'+html.escape(NAMES[stage])+'</td>'
  for task in TASK_ORDER:
   r=lookup.get((stage,task));cell='—' if r is None else ('NA' if r['mean_rmse_deg'] is None else f"{r['mean_rmse_deg']:.3f}°")+f" ({r['failed']}/{r['attempted']} failed)";brief+='<td>'+html.escape(cell)+'</td>'
  brief+='</tr>'
 brief+='</table><details><summary>All 28 inputs and physical output</summary><table><tr><th>Index</th><th>Input</th><th>Unit</th></tr>'
 for r in contract:brief+='<tr><td>'+str(r['index'])+'</td><td>'+html.escape(r['meaning'])+'</td><td>'+html.escape(r['unit'])+'</td></tr>'
 brief+='</table><p>Angle/velocity reference channels are encoded as (reference − actual)/0.02 rad and /0.2 rad/s. Other fixed scales are exported in NETWORK_INPUT_OUTPUT.json. Output: exo_flexor tension, 0–650 N. Previous tension is the NN’s own previous applied force; shoulder motion remains prescribed.</p></details>'
 for name in ('tracking_matrix','compact_tracking'):
  encoded=base64.b64encode((plots/(name+'.png')).read_bytes()).decode();brief+='<figure><img src="data:image/png;base64,'+encoded+'"><figcaption>'+('All attempted physical tests, with failures.' if name=='tracking_matrix' else 'One identifier-selected example per task; partial traces are labeled.')+'</figcaption></figure>'
 brief+='<p>One seed is not a training-seed uncertainty estimate. Native Windows visualization and GPU execution require local verification. <a href="DETAILED_REPORT.html">Detailed plots and trajectories</a> remain separate.</p></html>'
 (out/'REPORT.html').write_text(brief)
 from report_support import compile_and_zip
 compile_and_zip(report,out,'OVERLEAF_REPORT.zip');print('HTML AND BRIEF OVERLEAF SAVED:',out/'OVERLEAF_REPORT.zip',flush=True)

BRIEF_TEMPLATE="\\documentclass[10pt]{article}\n\\usepackage[margin=.7in]{geometry}\\usepackage{graphicx,booktabs,array,amsmath,hyperref}\n\\setlength{\\parindent}{0pt}\\setlength{\\parskip}{4pt}\\begin{document}\n\\begin{center}\\Large\\textbf{Four-task neural exosuit control: adaptation and retention}\\end{center}\n\\textbf{Tasks.} A: 90\\%, vertical up/down reaches. B: 60\\%, variable-speed irregular reversals/chirps with moving shoulder elevation. C: 30\\%, cross-body lateral sweeps. D: 45\\%, reach-and-hold under smooth external downward force pulses up to 20 N. These are distinct motion/load regimes on the same arm; task diversity does not itself prove forgetting.\n\n\\textbf{Physical scope.} The planar Arm26 is mounted on a prescribed yaw carrier with co-moving proximal muscle attachments. Actual hand X/Y/Z are recorded; C must cross the body's ground-Z midline. This is a simplified movement-plane extension, not a validated anatomical shoulder or collision model. Shoulder elevation and yaw are prescribed. The NN learns elbow cable assistance under these motions, not independent 3D shoulder control. D applies an external force; dumbbell mass is not changed by the pulse.\n\n\\textbf{Data and test scope.} Preserve all original whole-episode splits; exclude pilots. The default collection has 640 full episodes. All held-out force samples are tested. To limit long physics runs, the default uses four held-out trajectories per task, selected by angle/variant metadata before training; option 0 uses all. The final column below is the number of distinct physical-test episodes per task, reused across checkpoint comparisons.\n\\begin{center}\\small\\begin{tabular}{lrrrr}\\toprule Task & Train & Validation & Test & Physics subset\\\\\\midrule\nCOUNTS\n\\bottomrule\\end{tabular}\\end{center}\n\\textbf{NN architecture.} A 28-input context MLP has two 64-unit tanh layers and three internal heads: nominal force and two nonnegative learned feedback gains. There is one physical force output and 6,211 parameters; no recurrent hidden state. The current angle/velocity error channels are zeroed in the context branch and enter the learned feedback computation explicitly. All branches use this same controller.\n\\begin{center}\\small\\begin{tabular}{p{.07\\linewidth}p{.68\\linewidth}p{.17\\linewidth}}\\toprule Index & Input & Unit\\\\\\midrule\nINPUTS\n\\bottomrule\\end{tabular}\\end{center}\nErrors are encoded as $e=(q_r-q)/0.02$, $v=(\\dot q_r-\\dot q)/0.2$; other fixed divisors are exported in \\texttt{NETWORK\\_INPUT\\_OUTPUT.json}. Inputs 8/9 are shared causal feedback states; muscle states and external force would require sensing/estimation on hardware. Task IDs are metadata.\n\\newpage\n\\textbf{One learned force output.} For MLP heads $(h_0,h_q,h_v)$,\n\\[F=650\\,\\operatorname{clip}_{[0,1]}\\{\\sigma(h_0)+0.05\\operatorname{softplus}(h_q)e+0.05\\operatorname{softplus}(h_v)v\\}.\\]\nThe nominal and feedback terms are learned from PID force demonstrations; gains are not fixed to the teacher's PID gains. Positive feedback sensitivities help structure recovery learning but do not constitute a closed-loop stability proof. Output is the single recorded \\texttt{exo\\_flexor} tension. Previous force in NN tests is its own last applied value. No PID force fallback or weight update occurs in held-out testing.\n\n\\textbf{Sequential comparison.} Train A once; clone its weights into ordinary fine-tuning and EWC branches. Each then learns B, C, D in order, using equal schedules and optimizer resets. EWC protects A during B, A+B during C, and A+B+C during D. Both branches continue from their own preceding solutions. Frozen A tested on later tasks is the separate no-adaptation baseline.\n\n\\textbf{Loss and memory.} Imitation uses deployment-clipped normalized force MSE. EWC adds\n\\[\\mathcal L_{t,EWC}=\\mathcal L_t+\\frac{\\lambda}{2P}\\sum_{k<t}\\sum_{i\\in S_k}\\widetilde I_{k,i}(\\theta_i-\\theta_i^k)^2,\\qquad \\widetilde I_{k,i}=I_{k,i}/\\operatorname{mean}_j I_{k,j}.\\]\nEach $S_k$ contains the top FRACTION\\% of scalar parameters. Importance is estimated using squared per-example raw normalized-output Jacobians on that task's training rows (unit-variance Gaussian expected Fisher). Each memory stores selected indices, anchors and importance, not replay examples or a full extra anchor vector. Normal checkpoints are stored separately for resume. This is a selective approximation to EWC (Kirkpatrick et al., PNAS 2017, doi:10.1073/pnas.1611835114).\n\n\\textbf{Lambda and settings.} GRID spans weaker to stronger penalties under this normalization; 10 is not privileged. Choose one lambda for the whole sequence using mean squared relative validation force error over the nine seen-task/stage combinations after B, C and D. Each task's reference scale is its no-EWC validation error just after learning it (A uses initial A), floored at 0.1 N. Require each newly learned task's error to be at most TOL times that reference; otherwise choose the lowest new-task relative error and report failed constraints. Selected: SELECTED. Tests stay sealed until all model/lambda choices finish. Adam LR; batch BATCH; clip 5; A EPOCHA epochs, later tasks EPOCHB each per branch/candidate. All training rows are used each epoch.\n\n\\textbf{Held-out physical results.} Cells show completed-episode mean elbow RMSE (deg), then failed/attempted counts. NA is no completed episode; -- is not evaluated. Cartesian error and full diagnostics are saved separately.\n\\begin{center}\\small\\begin{tabular}{lrrrr}\\toprule Checkpoint & A & B & C & D\\\\\\midrule\nRESULTS\n\\bottomrule\\end{tabular}\\end{center}\nReturning to earlier tasks measures retention; interpret paired errors with failures and current-task adaptation. Strong EWC improvement is measured, not imposed. SEEDNOTE Detailed plots stay in HTML. Native Windows visualization/CUDA require local verification.\n\\newpage\n\\begin{center}\\textbf{Two key tracking comparisons}\\end{center}\n\\begin{center}\\includegraphics[width=.97\\linewidth,height=2.8in,keepaspectratio]{figures/tracking_matrix.pdf}\\end{center}\n\\small RMSE across completed physical tests; every cell includes failure counts. Missing RMSE never means zero error.\\normalsize\n\\begin{center}\\includegraphics[width=.98\\linewidth,height=5.6in,keepaspectratio]{figures/compact_tracking.pdf}\\end{center}\n\\small One identifier-selected trajectory per task, never chosen by error; partial runs are labeled. The matrix includes every attempted rollout in the predeclared physical test subset.\\normalsize\n\\end{document}\n"
