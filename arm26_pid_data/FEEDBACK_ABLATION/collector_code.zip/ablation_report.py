"""Two-figure report; incomplete simulations remain explicit."""
from pathlib import Path
import csv,html,base64
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from complex_engine import read,write
from report_support import compile_and_zip,tex

def build_report(out):
 out=Path(out);result=read(out/'TEST_RESULTS.json')
 if not result['complete']:raise ValueError('Tests incomplete.')
 rows=result['rows'];groups=[]
 for stage,task,scale in sorted({(r['stage'],r['task'],r['feedback_scale']) for r in rows}):
  g=[r for r in rows if (r['stage'],r['task'],r['feedback_scale'])==(stage,task,scale)]
  v=[r['rmse_deg'] for r in g if r['completed'] and r['rmse_deg'] is not None]
  sat=[r['saturation_percent'] for r in g if r.get('saturation_percent') is not None]
  groups.append(dict(stage=stage,task=task,scale=scale,mean_rmse_deg=float(np.mean(v)) if v else None,failed=sum(not r['completed'] for r in g),attempted=len(g),passed=sum(bool(r['tracking_passed']) for r in g),max_error_deg=max((r['max_error_deg'] for r in g if r.get('max_error_deg') is not None),default=None),mean_saturation_percent=float(np.mean(sat)) if sat else None))
 write(out/'SUMMARY.json',dict(rows=groups,note=result['recovery_note']))
 with (out/'SUMMARY.csv').open('w',encoding='utf-8',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(groups[0]));w.writeheader();w.writerows(groups)
 plots=out/'plots';plots.mkdir(exist_ok=True);texdir=out/'overleaf';texdir.mkdir(exist_ok=True)
 plt.rcParams.update({'font.family':'serif','font.size':11});figs=[]
 for metric,name,ylabel in [('mean_rmse_deg','tracking','Completed-run motion RMSE (deg)'),('mean_saturation_percent','saturation','Cable saturation (%)')]:
  fig,axes=plt.subplots(1,2,figsize=(10,3.8))
  for ax,task in zip(axes,['C_30','D_45']):
   for stage in ['initial','after_D_noEWC','after_D_EWC','after_A_noEWC','after_A_EWC']:
    vals=[next((g for g in groups if (g['task'],g['stage'],g['scale'])==(task,stage,s)),None) for s in [1.,.5,0.]]
    if not any(vals):continue
    ax.plot([1,.5,0],[g[metric] if g and g[metric] is not None else np.nan for g in vals],'o-',label=stage.replace('_',' '))
   ax.set(title=task,xlabel='Explicit feedback multiplier',ylabel=ylabel,xticks=[0,.5,1]);ax.grid(alpha=.25);ax.legend(fontsize=7)
  fig.tight_layout()
  fig.savefig(plots/(name+'.png'),dpi=170);fig.savefig(texdir/(name+'.pdf'));plt.close(fig);figs.append(name)
 note=result['recovery_note']+' Results are descriptive, not confirmation of a need for EWC. Lower feedback can degrade both models. Scale0 is not a separately trained direct force-output policy. Mean RMSE excludes failed runs; failure/pass counts and partial results in TEST_RESULTS.json must be reviewed alongside means. Existing full-feedback results were rerun with matched settings. No settings are selected using these tests.'
 table='<table><tr>'+''.join('<th>'+k+'</th>' for k in groups[0])+'</tr>'
 texrows=[]
 for g in groups:
  cells=[str(round(v,4)) if isinstance(v,float) else str(v) for v in g.values()];table+='<tr>'+''.join('<td>'+html.escape(c)+'</td>' for c in cells)+'</tr>'
  texrows.append(' & '.join(tex(str(g[k])) for k in ['stage','task','scale'])+' & '+('NA' if g['mean_rmse_deg'] is None else f"{g['mean_rmse_deg']:.3f}")+f" & {g['failed']}/{g['attempted']} & {g['passed']}"+r' \\')
 table+='</table>'
 images=''.join('<img style="width:100%" src="data:image/png;base64,'+base64.b64encode((plots/(n+'.png')).read_bytes()).decode()+'">' for n in figs)
 (out/'REPORT.html').write_text('<meta charset="utf-8"><style>body{max-width:1100px;margin:35px auto;font:16px Georgia}table{border-collapse:collapse;font-size:12px}td,th{border:1px solid #aaa;padding:5px}</style><h1>Saved-model feedback ablation</h1><p>'+html.escape(note)+'</p>'+images+table,encoding='utf-8')
 body=r'\documentclass[10pt]{article}\usepackage[margin=.65in]{geometry}\usepackage{graphicx,longtable}\begin{document}\section*{Saved-model feedback ablation}'+tex(note)+r'\par $F=\mathrm{clip}(F_{nominal}+\alpha\,650(k_p x_2+k_d x_3),0,650)$, with $\alpha\in\{1,0.5,0\}$. Nominal computation and all other inputs remain present.\par'+''.join(r'\includegraphics[width=\linewidth]{'+n+'.pdf}' for n in figs)+r'\newpage\small\begin{longtable}{lllrrr}Stage & Task & Scale & RMSE(deg) & Failed/total & Passed\\\hline'+'\n'+'\n'.join(texrows)+r'\end{longtable}\end{document}'
 (texdir/'main.tex').write_text(body,encoding='utf-8');compile_and_zip(texdir,out,'OVERLEAF_REPORT.zip')
