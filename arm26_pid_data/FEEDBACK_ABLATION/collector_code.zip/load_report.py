"""Compact frozen-load sensitivity report, with numerical failures explicit."""
from pathlib import Path
import base64,csv,html,shutil
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from complex_engine import read,write
from report_support import compile_and_zip,tex

def build_report(out):
    out=Path(out);data=read(out/'LOAD_RESULTS.json');protocol=read(out/'LOAD_PROTOCOL.json')
    if not data['complete']:raise ValueError('Finish the declared load sweep before generating a final load report.')
    summary=[]
    for task in protocol['tasks']:
        for branch in protocol['branches']:
            for mass in protocol['masses_kg']:
                group=[r for r in data['rows'] if r['task']==task and r['branch']==branch and r['mass_kg']==mass]
                good=[r for r in group if r['completed']];numeric=sum(r.get('failure_kind')=='numerical_failure' for r in group)
                summary.append(dict(task=task,branch=branch,mass_kg=mass,attempted=len(group),failed=len(group)-len(good),numerical_failures=numeric,tracking_passed=sum(bool(r['tracking_passed']) for r in group),mean_rmse_deg=float(np.mean([r['rmse_deg'] for r in good])) if good else None,saturation_percent=float(np.mean([r['saturation_percent'] for r in good])) if good else None))
    limits=[]
    for task in protocol['tasks']:
        for branch in protocol['branches']:
            group=[r for r in summary if r['task']==task and r['branch']==branch]
            bad=next((r for r in group if r['tracking_passed']<r['attempted']),None)
            limits.append(dict(task=task,branch=branch,first_sampled_mass_not_all_tracking_passed_kg=bad['mass_kg'] if bad else None,reason='At least one numerical failure; capacity is not established' if bad and bad['numerical_failures'] else 'At least one tracking/envelope failure' if bad else 'No failure observed in the tested range'))
    write(out/'LOAD_SUMMARY.json',dict(rows=summary,limits=limits,note='Sampled frozen-controller operating envelope; no claim of maximum physical arm capacity. Failure thresholds are fixed before the sweep.'))
    with (out/'LOAD_SUMMARY.csv').open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=list(summary[0]));w.writeheader();w.writerows(summary)
    plots=out/'plots';plots.mkdir(exist_ok=True);overleaf=out/'load_overleaf';overleaf.mkdir(exist_ok=True)
    fig,axes=plt.subplots(1,2,figsize=(10,3.8));colors=plt.cm.tab10.colors
    for i,task in enumerate(protocol['tasks']):
        for branch in protocol['branches']:
            group=[r for r in summary if r['task']==task and r['branch']==branch];label=f'{task[0]} '+('No EWC' if branch=='noEWC' else 'EWC')
            for ax,key in zip(axes,('mean_rmse_deg','saturation_percent')):
                ax.plot([r['mass_kg'] for r in group],[r[key] if r[key] is not None else np.nan for r in group],marker='o',ls='--' if branch=='noEWC' else '-',color=colors[i],label=label)
    axes[0].axhline(protocol['rmse_limit_deg'],color='grey',ls=':',label='RMSE limit');axes[0].set_ylabel('Completed-episode motion RMSE (deg)');axes[1].set_ylabel('Completed-episode saturation (%)')
    for ax in axes:ax.set_xlabel('Dumbbell mass (kg)');ax.grid(alpha=.25);ax.legend(fontsize=7,ncol=2)
    fig.tight_layout()
    for ext in ('png','pdf'):fig.savefig(plots/f'load_sensitivity.{ext}',dpi=150,bbox_inches='tight')
    plt.close(fig);shutil.copy2(plots/'load_sensitivity.pdf',overleaf/'load_sensitivity.pdf')
    text=(f"Frozen-model load sensitivity after the completed CDBA study. Checkpoint mode: {protocol['checkpoint_stage']}. Nominal dataset load: {protocol['nominal_mass_kg']:g} kg. The true changed mass is supplied to the existing mass input; reference, strength, force cap (650 N), excitation and timing stay fixed. No learning or lambda selection occurs. Tracking thresholds: motion RMSE <= {protocol['rmse_limit_deg']:g} deg and all-sample max error <= {protocol['max_error_limit_deg']:g} deg, with completed simulation required. Each paired branch uses the same identifier-selected trajectories at every mass. Numerical failures are counted separately. The first sampled mass failing a criterion is an observed controller/trajectory limit, not a measured maximum arm strength. If no failure occurs, extend the grid in a new output folder; no failure is manufactured. Closed-loop controller weakness and physical actuator infeasibility are distinct explanations. No PID feasibility test is included.")
    heads=['Task','Branch','kg','RMSE (deg)','Failed/attempted','Numerical failures','Tracking passed'];table='<table><tr>'+''.join('<th>'+h+'</th>' for h in heads)+'</tr>';texrows=[]
    for r in summary:
        cells=[r['task'],r['branch'],f"{r['mass_kg']:g}",'NA' if r['mean_rmse_deg'] is None else f"{r['mean_rmse_deg']:.3f}",f"{r['failed']}/{r['attempted']}",str(r['numerical_failures']),str(r['tracking_passed'])]
        table+='<tr>'+''.join('<td>'+html.escape(v)+'</td>' for v in cells)+'</tr>';texrows.append(' & '.join(tex(v) for v in cells)+r' \\')
    table+='</table>'
    encoded=base64.b64encode((plots/'load_sensitivity.png').read_bytes()).decode()
    page='<html><meta charset="utf-8"><style>body{max-width:1050px;margin:35px auto;font:16px Georgia}table{border-collapse:collapse}td,th{border:1px solid #aaa;padding:4px}img{max-width:100%}</style><h1>Frozen controller under increasing dumbbell load</h1><p>'+html.escape(text)+'</p><img src="data:image/png;base64,'+encoded+'">'+table+'<pre>'+html.escape(str(limits))+'</pre></html>'
    (out/'LOAD_REPORT.html').write_text(page,encoding='utf-8')
    body=r'\documentclass[10pt]{article}\usepackage[margin=.65in]{geometry}\usepackage{graphicx,booktabs,longtable}\begin{document}\section*{Frozen-controller load sensitivity}'+tex(text)+r'\par\includegraphics[width=\linewidth]{load_sensitivity.pdf}\small\begin{longtable}{llrrrrr}\toprule Task & Branch & kg & RMSE & Failed/n & Numerical & Passed\\\midrule'+'\n'+'\n'.join(texrows)+r'\bottomrule\end{longtable}\end{document}'
    (overleaf/'main.tex').write_text(body,encoding='utf-8');compile_and_zip(overleaf,out,'LOAD_OVERLEAF.zip','LOAD_REPORT.pdf')
    print('LOAD REPORT SAVED:',out/'LOAD_REPORT.html',flush=True)
