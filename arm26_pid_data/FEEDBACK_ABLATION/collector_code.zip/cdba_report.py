"""Brief UTF-8 report with two interpretable retention figures."""
from pathlib import Path
import base64,csv,html,io,shutil
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from complex_engine import read,write
from complex_trajectories import FEATURES,SCALES
from study_report import MEANINGS,UNITS
from report_support import compile_and_zip,tex

ORDER=['C_30','D_45','B_60','A_90']
COLORS={'noEWC':'#D55E00','EWC':'#0072B2'}

def build_report(out):
    out=Path(out);result=read(out/'TEST_RESULTS.json');protocol=read(out/'PROTOCOL.json')
    if not result.get('complete'):raise ValueError('All scheduled tests must finish before the final report.')
    rows=result['rows'];plots=out/'plots';plots.mkdir(exist_ok=True);overleaf=out/'cdba_overleaf';overleaf.mkdir(exist_ok=True)
    stages=['initial']+[f'after_{t[0]}_{b}' for t in ORDER[1:] for b in COLORS]
    summary=[]
    for stage in stages:
        for task in ORDER:
            group=[r for r in rows if r['stage']==stage and r['task']==task]
            if not group:continue
            values=[r['rmse_deg'] for r in group if r['completed'] and r['rmse_deg'] is not None]
            summary.append(dict(stage=stage,task=task,attempted=len(group),failed=sum(not r['completed'] for r in group),tracking_passed=sum(bool(r['tracking_passed']) for r in group),mean_rmse_deg=float(np.mean(values)) if values else None))
    write(out/'SUMMARY.json',dict(rows=summary,note='Episode RMSE averaged only over completed runs; failures are explicit. Return to C/D does not update weights.'))
    with (out/'TRACKING_STATISTICS.csv').open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=list(summary[0]));w.writeheader();w.writerows(summary)
    contract=[dict(index=i+1,name=n,meaning=MEANINGS[i],unit=UNITS[i],divisor=float(SCALES[i])) for i,n in enumerate(FEATURES)]
    write(out/'NETWORK_INPUT_OUTPUT.json',dict(inputs=contract,encoded_error_overrides={2:'(reference-angle)/0.02',3:'(reference_velocity-velocity)/0.2'},output='exo_flexor tension, N, clipped 0..650',topology='28 -> 64 tanh -> 64 tanh -> 3 learned heads -> 1 force',recurrent_state=False))
    plt.rcParams.update({'font.family':'serif','font.size':11,'pdf.fonttype':42})
    figures=[]
    def save(fig,name,caption):
        fig.tight_layout()
        for ext in ('png','pdf'):fig.savefig(plots/f'{name}.{ext}',dpi=160,bbox_inches='tight')
        plt.close(fig);figures.append((name,caption));shutil.copy2(plots/f'{name}.pdf',overleaf/f'{name}.pdf')
    fig,axes=plt.subplots(1,2,figsize=(10,3.3),sharex=True)
    for ax,task in zip(axes,ORDER[:2]):
        for branch,color in COLORS.items():
            ys=[]
            for i in range(4):
                stage='initial' if i==0 else f'after_{ORDER[i][0]}_{branch}'
                item=next((r for r in summary if r['stage']==stage and r['task']==task),None)
                ys.append(item['mean_rmse_deg'] if item and item['mean_rmse_deg'] is not None else np.nan)
                if item and item['failed']:ax.annotate(f"{item['failed']}/{item['attempted']} failed",(i,ys[-1] if np.isfinite(ys[-1]) else 0),fontsize=8,xytext=(0,8),textcoords='offset points')
            ax.plot(range(4),ys,'o-',color=color,label='No EWC' if branch=='noEWC' else 'EWC')
        ax.set(title=f'Retention on task {task[0]}',ylabel='Motion RMSE (deg)',xticks=range(4),xticklabels=['After C','After D','After B','After A']);ax.grid(alpha=.25);ax.legend()
    save(fig,'retention','How earlier-task error changes as later tasks are learned. D has no value before D is learned. Missing results are not zero. See failure counts in the table.')
    fig,axes=plt.subplots(2,1,figsize=(10,5.0))
    for ax,task in zip(axes,ORDER[:2]):
        final=[r for r in rows if r['task']==task and r['stage']=='after_A_noEWC']
        if not final:continue
        representative=min(final,key=lambda r:(r['seed'],r['motion_id']))
        for branch,color in COLORS.items():
            item=next((r for r in rows if r['task']==task and r['stage']==f'after_A_{branch}' and r['seed']==representative['seed'] and r['motion_id']==representative['motion_id']),None)
            if item is None:continue
            file=Path(item['folder'])/'signals.csv'
            if not file.exists():continue
            with file.open(encoding='utf-8-sig',newline='') as f:data=list(csv.DictReader(f))
            t=[float(r['time_s']) for r in data]
            if branch=='noEWC':ax.plot(t,[float(r['reference_deg']) for r in data],'k--',lw=1.6,label='Reference')
            ax.plot(t,[float(r['angle_deg']) for r in data],color=color,label=('No EWC' if branch=='noEWC' else 'EWC')+(' (partial)' if not item['completed'] else ''))
        ax.set(title=f'Return to {task[0]} after learning C, D, B, A',xlabel='Time (s)',ylabel='Elbow angle (deg)');ax.grid(alpha=.25);ax.legend(ncol=3)
    save(fig,'return_tracking','One paired held-out trajectory for C and D, selected by smallest seed and motion identifier before inspecting error. Partial runs are labeled; these curves do not replace the full summary.')
    selections={str(seed):read(out/f'seed_{seed}/SELECTED_CL.json') for seed in protocol['seeds']};write(out/'LAMBDA_SELECTION.json',selections)
    selected='; '.join(f"seed {s}: lambda {v['selected_lambda']:g}, adaptation constraint {'met' if v['adaptation_constraint_met'] else 'FAILED'}" for s,v in selections.items())
    methods=("RECOVERY EVALUATION: Reference hashes reconstructed from defaults match all 128 original test references. The original preselected physical subset is used. Deleted teacher force arrays are unavailable; offline force accuracy was not evaluated. Saved sealed weights were reused without retraining. " + f"Train C (30% strength), D (45%), B (60%), A (90%); then return to C and D with the final weights frozen. The two branches share initial C weights and use matched epoch budgets and optimizer resets. EWC protects C during D, C+D during B, and C+D+B during A. There is no training during test visits. Original episode splits and all accepted training rows are retained. No test is used to choose lambda. Initial budget {protocol['epochs_a']} epochs; adaptation {protocol['epochs_b']} epochs per task/candidate; Adam lr {protocol['lr']}; batch {protocol['batch_size']}. "
        f"MLP: 28 inputs, 64/64 tanh hidden layers, three internal heads combined into one elbow cable tension. The learned nominal force and positive learned position/velocity feedback gains produce the force; deployment clips at 650 N. Shoulder elevation/yaw are prescribed. There is no recurrent hidden state; previous tension and integrated error remain explicit feedback inputs. Normalized error features replace reference angle/velocity: (reference-actual)/0.02 rad and (reference velocity-actual velocity)/0.2 rad/s. "
        f"EWC protects the top {100*protocol['protect_fraction']:g}% of scalar parameters using selected indices, prior values and expected-Gaussian-Fisher sensitivities, without replay. Checkpoints separately store all network parameters for deployment/resume. Lambda grid {protocol['lambda_grid']}; 10 has no special status. Selection minimizes mean relative validation force error across nine seen-task/stage combinations, subject to new-task error <= {protocol['validation_tolerance']:g} times its no-EWC reference (floor 0.1 N). Failed constraints are disclosed; fallback minimizes new-task relative error. {selected}. "
        "Mean tracking RMSE excludes incomplete runs; failed/attempted counts and tracking-pass counts are reported. A single seed does not establish statistical significance, and success without EWC is retained honestly. Frozen-controller failure does not prove that the physical arm is incapable under every controller.")
    table='<table><tr><th>Checkpoint</th><th>Task</th><th>Mean RMSE (deg)</th><th>Failed/attempted</th><th>Tracking passed</th></tr>'
    texrows=[]
    for r in summary:
        value='NA' if r['mean_rmse_deg'] is None else f"{r['mean_rmse_deg']:.3f}"
        cells=[r['stage'],r['task'],value,f"{r['failed']}/{r['attempted']}",str(r['tracking_passed'])]
        table+='<tr>'+''.join('<td>'+html.escape(v)+'</td>' for v in cells)+'</tr>'
        texrows.append(' & '.join(tex(v) for v in cells)+r' \\')
    table+='</table>'
    page='<html><meta charset="utf-8"><title>CDBA retention experiment</title><style>body{max-width:1050px;margin:36px auto;font:17px Georgia;line-height:1.45}table{border-collapse:collapse;font-size:14px}td,th{border:1px solid #bbb;padding:5px}img{max-width:100%}</style><h1>C → D → B → A; return to C and D</h1><p>'+html.escape(methods)+'</p>'+table
    for name,caption in figures:page+='<figure><img src="data:image/png;base64,'+base64.b64encode((plots/f'{name}.png').read_bytes()).decode()+'"><figcaption>'+html.escape(caption)+'</figcaption></figure>'
    page+='<details><summary>All 28 inputs and units</summary><ul>'+''.join('<li>'+html.escape(f"{r['index']}. {r['name']} — {r['meaning']} [{r['unit']}]")+'</li>' for r in contract)+'</ul></details><p>Deployable stage snapshots: seed_SEED/saved_models/BRANCH/after_C, after_D, after_B, after_A. They are sequential snapshots, not four independent specialists.</p></html>'
    (out/'REPORT.html').write_text(page,encoding='utf-8')
    # Condense muscle groups while listing every input's identity in the JSON/HTML.
    inputlines=[]
    for i in list(range(9))+list(range(21,28)):inputlines.append(f'{i+1} & {tex(MEANINGS[i])} & {tex(UNITS[i])}'+r' \\')
    inputlines[9:9]=[r'10--15 & TRIlong, TRIlat, TRImed, BIClong, BICshort, BRA activations & unitless \\',r'16--21 & Normalized fiber lengths, same six muscles/order & unitless \\']
    body=r'\documentclass[10pt]{article}\usepackage[margin=.65in]{geometry}\usepackage{graphicx,booktabs,longtable}\setlength{\parindent}{0pt}\begin{document}\section*{CDBA sequential learning and retention}'+'\n'+tex(methods)+r'\par\medskip\textbf{Loss:} '+r'$L=L_{force}+\frac{\lambda}{2P}\sum_{k<t}\sum_{i\in S_k}\widetilde I_{k,i}(\theta_i-\theta_i^k)^2$, where $L_{force}$ is normalized clipped-force MSE and $\widetilde I=I/\mathrm{mean}(I)$.'+r'\par\small\begin{longtable}{rp{.72\linewidth}l}\toprule Input & Meaning & Unit\\\midrule'+'\n'+'\n'.join(inputlines)+r'\bottomrule\end{longtable}\textbf{Output:} one exo\_flexor tension, 0--650 N. Saved stage models are sequential snapshots after C/D/B/A, separately for each branch.\newpage\section*{Measured tracking and retention}\small\begin{longtable}{llrrr}\toprule Checkpoint & Task & RMSE (deg) & Failed/attempted & Passed\\\midrule'+'\n'+'\n'.join(texrows)+r'\bottomrule\end{longtable}\includegraphics[width=\linewidth,height=2.6in,keepaspectratio]{retention.pdf}\par '+tex(figures[0][1])+r'\newpage\section*{Return to C, then D; no weight updates}\includegraphics[width=\linewidth,height=6in,keepaspectratio]{return_tracking.pdf}\par '+tex(figures[1][1])+r'\end{document}'
    (overleaf/'main.tex').write_text(body,encoding='utf-8');compile_and_zip(overleaf,out,'OVERLEAF_REPORT.zip')
    print('CDBA REPORTS SAVED:',out/'REPORT.html',out/'OVERLEAF_REPORT.zip',flush=True)
