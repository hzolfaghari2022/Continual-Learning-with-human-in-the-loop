"""Validation-only EWC selection over the entire A->B->C->D sequence."""
from pathlib import Path
import math
import numpy as np,torch
from learn import fit,read_policy,importance_memory
from complex_engine import write
from study_data import TASK_ORDER

def validation_rmse(path,data,device):
 m=read_policy(path,device);m.eval();total=0.
 with torch.no_grad():
  for i in range(0,len(data[0]),8192):
   x=torch.from_numpy(data[0][i:i+8192]).to(device);y=torch.from_numpy(data[1][i:i+8192]).to(device);total+=float((m(x).clamp(0,1)-y).square().sum())
 return 650*math.sqrt(total/len(data[0]))

def choose(base,first,no_models,train,val,args,seed,device,memory1):
 TASK_ORDER=getattr(args,'training_order',['A_90','B_60','C_30','D_45'])
 base=Path(base);scales={t:max(.1,validation_rmse(({1:first}|no_models)[i],val[t],device)) for i,t in enumerate(TASK_ORDER,1)}
 def metrics(paths):
  return [dict(after_stage=s,task=t,force_rmse_N=(r:=validation_rmse(paths[s],val[t],device)),relative_squared_error=(r/scales[t])**2) for s in range(2,5) for t in TASK_ORDER[:s]]
 def score(rows):return float(np.mean([r['relative_squared_error'] for r in rows]))
 baseline=metrics(no_models);candidates=[];paths_by_lambda={}
 for lam in args.lambda_grid:
  folder=base/('candidate_lambda_'+format(lam,'.8g').replace('.','p'));folder.mkdir(exist_ok=True);paths={};memories=[memory1];parent=first
  for stage,task in enumerate(TASK_ORDER[1:],2):
   letter=task[0];checkpoint=fit(folder/f'after_{letter}_EWC',train[task],val[task],args,seed+1000*(stage-1),device,initial=parent,memory=memories,lam=lam,stage=letter+'_EWC');paths[stage]=checkpoint
   if stage<4:
    mf=folder/('memory_'+letter);mf.mkdir(exist_ok=True);mem=importance_memory(read_policy(checkpoint,device),train[task][0],mf,args,seed+1000*(stage-1),device,checkpoint,train[task][2]);memories=memories+[mem]
   parent=checkpoint
  rows=metrics(paths);new=[r for r in rows if r['task']==TASK_ORDER[r['after_stage']-1]];item=dict(lambda_ewc=lam,score=score(rows),validation_rows=rows,adaptation_constraint_met=all(r['force_rmse_N']<=args.validation_tolerance*scales[r['task']] for r in new),new_task_relative_error=float(np.mean([r['relative_squared_error'] for r in new])),checkpoints={str(k):str(v) for k,v in paths.items()});candidates.append(item);paths_by_lambda[lam]=paths;print('SEQUENCE LAMBDA:',lam,'| validation score:',item['score'],'| constraint:',item['adaptation_constraint_met'],flush=True)
 feasible=[r for r in candidates if r['adaptation_constraint_met']];best=min(feasible,key=lambda r:(r['score'],r['lambda_ewc'])) if feasible else min(candidates,key=lambda r:(r['new_task_relative_error'],r['score'],r['lambda_ewc']))
 write(base/'SELECTED_CL.json',dict(selected_lambda=best['lambda_ewc'],grid=args.lambda_grid,scales_N=scales,candidates=candidates,noEWC_validation_rows=baseline,noEWC_joint_score=score(baseline),selected_joint_score=best['score'],selected_improves_validation_score=best['score']<score(baseline),adaptation_constraint_met=best['adaptation_constraint_met'],tolerance=args.validation_tolerance,test_accessed=False,criterion='Mean squared relative validation force error over 2+3+4=9 stage/task combinations. Current-task validation must be <= tolerance times the no-EWC reference (floored at 0.1N). Fallback minimizes current-task relative error and reports failed constraint.',EWC_memory='Protects all preceding tasks in training_order; selected anchors/importance only, no replay.',training_order=TASK_ORDER))
 print('SELECTED LAMBDA:',best['lambda_ewc'],flush=True);return paths_by_lambda[best['lambda_ewc']]
