@echo off
cd /d "%~dp0"
python -X utf8 run_ablation.py --study "%USERPROFILE%\Arm26_CDBA_Results\cdba_20261107_230345_85bb20"
pause
