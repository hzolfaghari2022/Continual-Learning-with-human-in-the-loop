"""Visible, durable collection progress; estimates are measured, never promised."""
import json,time
from datetime import datetime,timedelta
from pathlib import Path
from complex_engine import write,read

def clock(seconds):
    seconds=max(0,int(seconds));h,r=divmod(seconds,3600);m,s=divmod(r,60)
    return f'{h:02d}:{m:02d}:{s:02d}'

class Progress:
    def __init__(self,out,pilot_min,pilot_max,full_total,nominal_full_seconds):
        self.out=Path(out);self.started=time.monotonic();self.pilot_min=pilot_min;self.pilot_max=pilot_max;self.full_total=full_total;self.full_seconds=nominal_full_seconds
        self.done={'pilot':0,'full':0};self.extra=0;self.wall=0.;self.sim=0.;self.active=None;self.last_print=-1e9;self.phase='pilot';self.condition_done=0;self.conditions=0
    def start(self,cfg,folder,phase):
        self.phase=phase;self.active=(cfg,Path(folder),time.monotonic());self.refresh(force=True)
        return f"{phase.upper()} {self.done[phase]+1} / {self.pilot_min+self.extra if phase=='pilot' else self.full_total}"
    def finish(self,reused=False):
        cfg,folder,start=self.active
        if not reused:self.wall+=time.monotonic()-start;self.sim+=cfg['duration_s']
        self.done[self.phase]+=1
        if self.phase=='full':self.full_seconds=max(0,self.full_seconds-cfg['duration_s'])
        self.active=None;self.refresh(force=True)
    def add_pilot_batch(self,n):self.extra+=n;self.refresh(force=True)
    def refresh(self,force=False):
        now=time.monotonic()
        if not force and now-self.last_print<5:return
        self.last_print=now;elapsed=now-self.started;known=self.pilot_min+self.extra+self.full_total;done=sum(self.done.values())
        active_sim=0.;duration=0.;label='';pct=None
        if self.active:
            cfg,folder,start=self.active;duration=cfg['duration_s'];label=cfg['episode_id']
            f=folder/'episode_progress.json'
            if f.exists():
                try:active_sim=read(f).get('simulation_time_s',0.)
                except (OSError,ValueError):pass
            pct=min(100,100*active_sim/duration)
        # During pilot calibration the number/duration of retries is unknown.
        # Use observed wall time per simulated second for a provisional forecast.
        ratio=self.wall/self.sim if self.sim>0 else None
        if self.phase=='pilot':
            remaining_sim=max(0,self.pilot_min+self.extra-self.done['pilot'])*(self.sim/max(1,self.done['pilot']) if self.sim else duration)+self.full_seconds
        else:remaining_sim=self.full_seconds if self.phase=='full' else 0.
        eta=max(0,remaining_sim-active_sim)*ratio if ratio is not None else None
        finish=(datetime.now().astimezone()+timedelta(seconds=eta)).isoformat(timespec='seconds') if eta is not None else None
        data=dict(status=self.phase,completed_attempts=done,planned_attempts_known=known,minimum_attempts=self.pilot_min+self.full_total,maximum_attempts=self.pilot_max+self.full_total,pilot_completed=self.done['pilot'],pilot_planned_known=self.pilot_min+self.extra,full_completed=self.done['full'],full_total=self.full_total,elapsed_seconds=elapsed,estimated_remaining_seconds=eta,estimated_finish_local=finish,github_and_report_time_included=False,active_episode=label,active_simulation_seconds=active_sim,active_duration_seconds=duration,active_percent=pct,note='Provisional measured estimate; pilot retries, future durations, GUI and GitHub time may change it. Final report/upload time is excluded.')
        write(self.out/'PROGRESS.json',data)
        msg=f"[{self.phase.upper()}] {done}/{known} attempts | pilots {self.done['pilot']}/{self.pilot_min+self.extra} | full {self.done['full']}/{self.full_total} | elapsed {clock(elapsed)}"
        if self.active:msg+=f" | episode {pct:.0f}% ({active_sim:.1f}/{duration:.1f} simulated s)"
        msg+=' | ETA '+(clock(eta)+'; finish ~'+finish if eta is not None else 'calibrating from completed runs')
        print(msg,flush=True)
        import html
        (self.out/'PROGRESS.html').write_text('<html><meta charset="utf-8"><meta http-equiv="refresh" content="5"><body style="font:20px system-ui;margin:3em"><h1>Arm26 collection progress</h1><p>'+html.escape(msg)+'</p><p>'+html.escape(label)+'</p><p>'+html.escape(data['note'])+'</p></body></html>',encoding='utf-8')
    def stage(self,name):self.phase=name;self.active=None;self.refresh(force=True)
