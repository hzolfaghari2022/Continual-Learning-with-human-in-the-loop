@echo off
setlocal
rem Always locate the script relative to THIS launcher, regardless of terminal folder.
if exist "%USERPROFILE%\miniconda3\condabin\conda.bat" (
    call "%USERPROFILE%\miniconda3\condabin\conda.bat" activate lstm-py312
    if errorlevel 1 goto :activation_failed
)
set "ARM26_PYTHON=%USERPROFILE%\miniconda3\envs\lstm-py312\python.exe"
if not exist "%ARM26_PYTHON%" set "ARM26_PYTHON=python"
echo Running data collection without live windows; GitHub destination is preconfigured.
"%ARM26_PYTHON%" "%~dp0collect_complex_pid.py" %*
set "ARM26_EXIT=%ERRORLEVEL%"
if not "%ARM26_EXIT%"=="0" echo Collection stopped. Read the worker traceback printed above; saved files remain intact.
pause
exit /b %ARM26_EXIT%
:activation_failed
echo Could not activate lstm-py312. Open Anaconda Prompt and activate that environment.
pause
exit /b 1
