@echo off
cd /d "%~dp0"
python collect_complex_pid.py --plan-only %*
pause
