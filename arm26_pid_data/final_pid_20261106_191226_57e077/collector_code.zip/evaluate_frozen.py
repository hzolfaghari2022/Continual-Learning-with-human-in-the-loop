"""Diagnostic only: deploy an existing frozen NN on newly collected motions."""
import argparse,csv,time,uuid
from pathlib import Path
import sys
from complex_engine import read,write,load_network,sha
from collect_complex_pid import ROOT
from process_helpers import run_logged


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--collection',type=Path,required=True);p.add_argument('--checkpoint',type=Path,required=True);p.add_argument('--role',choices=['DIAGNOSTIC_COMPLEX_90','TASK_A_90','TASK_B_60','CONTROL_A_60'],default='DIAGNOSTIC_COMPLEX_90');p.add_argument('--split',choices=['validation','test'],default='test');p.add_argument('--no-live',action='store_true');a=p.parse_args()
    _,features,before=load_network(a.checkpoint);records=read(a.collection/(a.role+'.json'))['records'];records=[r for r in records if r['split']==a.split]
    if not records:raise ValueError('No PID-accepted episodes in selected role/split.')
    ident=before['weights_sha256'][:12];out=a.collection/'frozen_diagnostics'/(a.role+'_'+a.split+'_'+ident+'_'+time.strftime('%Y%m%d_%H%M%S')+'_'+uuid.uuid4().hex[:5]);out.mkdir(parents=True,exist_ok=True)
    notes='Generalization diagnostic if NN90 is tested on new complex motions. Not evidence of forgetting or CL benefit by itself.'
    if len(features)==22:notes+=' Legacy NN sees actual shoulder angle but lacks shoulder speed/acceleration; moving-shoulder tests also change observability.'
    write(out/'DIAGNOSTIC.json',dict(role=a.role,split=a.split,model=before,note=notes));results=[]
    for record in records:
        folder=out/record['episode_id'];folder.mkdir(exist_ok=True);cfg=read(Path(record['folder'])/'settings.json');cfg['neural_checkpoint']=str(a.checkpoint.resolve());cfg['live_viewer']=not a.no_live;cfg['controller']='frozen_neural_diagnostic';cfg.pop('muscle_strength_audit',None)
        write(folder/'settings.json',cfg)
        run_logged([sys.executable,ROOT/'complex_engine.py','--worker',folder],folder/'console.log',allowed=(0,2),timeout=600)
        status=read(folder/'status.json')
        if status.get('export_error'):raise RuntimeError('Diagnostic export failed: '+str(folder/'status.json'))
        results.append(dict(episode_id=record['episode_id'],trajectory=record['trajectory'],status=status['status'],tracking_passed=status['tracking_passed'],rmse_deg=(status.get('motion_only') or {}).get('rmse_deg') if status['status']=='completed' else None,partial_motion_rmse_deg=(status.get('motion_only') or {}).get('rmse_deg') if status['status']!='completed' else None,frozen=status.get('frozen_weights_verified',False),folder=str(folder)))
        write(out/'RESULTS.json',dict(note=notes,rows=results,complete=False))
    _,_,after=load_network(a.checkpoint)
    if before!=after:raise RuntimeError('Frozen model identity changed.')
    write(out/'RESULTS.json',dict(note=notes,rows=results,complete=True,frozen_model_unchanged=True))
    with (out/'RESULTS.csv').open('w',newline='') as f:w=csv.DictWriter(f,fieldnames=list(results[0]));w.writeheader();w.writerows(results)
    print(notes);print('DIAGNOSTIC RESULTS:',out);return 0
if __name__=='__main__':raise SystemExit(main())
