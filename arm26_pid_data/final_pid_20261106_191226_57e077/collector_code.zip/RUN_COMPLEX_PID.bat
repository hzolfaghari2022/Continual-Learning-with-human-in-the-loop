@echo off
call "%~dp0START_COLLECTION.bat" %*
