"""PID-only complex data collection, paired strengths, independent pilot calibration."""
import argparse,hashlib,itertools,json,math,sys,time,uuid
import numpy as np
from pathlib import Path
from complex_trajectories import FAMILIES,FEATURES,make_profile,configure,reference_digest,speed_statistics
from complex_engine import read,write,sha
from process_helpers import run_logged
DEFAULT_GITHUB_REPO='https://github.com/hzolfaghari2022/Continual-Learning-with-human-in-the-loop.git'
ROOT=Path(__file__).resolve().parent
PROGRESS=None


def seed_for(seed,key):return int(hashlib.sha256((str(seed)+'/'+key).encode()).hexdigest()[:8],16)
def condition_key(family,mode,start,mass):return f'{family}_sh-{mode}_e{start:g}_m{mass:g}'.replace('.','p')


def recovery_for(args,key,split,rep):
    errors=getattr(args,'initial_errors',[-.5,0.,.5]);speeds=getattr(args,'initial_velocities',[-5.,0.,5.])
    k=rep if split=='train' else seed_for(args.seed,key+'/'+split+'/recovery')+rep
    return errors[k%len(errors)],speeds[(k+k//len(errors))%len(speeds)]


def pilot_recoveries(args):
    return sorted(set([(min(args.initial_errors),min(args.initial_velocities)),(max(args.initial_errors),max(args.initial_velocities))]))


def episode_config(args,key,family,mode,start,mass,split,rep,scale=1.,pilot=False,recovery_override=None):
    motion=key+'_'+split+'_'+str(rep);seed=seed_for(args.seed,motion)
    offset,velocity=recovery_override if recovery_override is not None else recovery_for(args,key,split,rep)
    cfg=dict(format_version=2,episode_id=motion,motion_id=motion,condition=key,split=split,trajectory=family,task='old_task_A' if family==args.old_family and mode=='fixed' else 'complex_task_B' if family!='baseline_smooth' or mode=='moving' else 'baseline_control',mass_kg=mass,profile=make_profile(family,seed,start,mode,pilot=pilot),start_hold_s=1.,end_hold_s=1.,dt_s=args.dt,initial_offset_deg=float(offset),initial_velocity_deg_s=float(velocity),muscle_excitation=.02,force_cap_N=650.,accel_kp=120.,accel_kd=22.,accel_ki=15.,integral_limit_rad_s=.15,integrator_accuracy=1e-5,accept_rmse_deg=args.rmse_limit,accept_max_error_deg=args.max_error_limit,live_viewer=not args.no_live,save_plots=True)
    poses=getattr(args,'moving_shoulder_poses',[0.,5.]) if mode=='moving' else getattr(args,'shoulder_poses',[-5.,0.,15.])
    cfg['profile']['shoulder_start_deg']=poses[seed_for(args.seed,key+'/shoulder_posture')%len(poses)]
    configure(cfg,scale);return cfg


def operational_error(folder,reason='Operational error; stop before collecting more data.'):
    path=Path(folder)/'error.txt'
    detail=path.read_text(encoding='utf-8',errors='replace') if path.exists() else '(Worker error.txt is absent; see console.log and status.json.)'
    raise RuntimeError(reason+'\nWORKER ERROR FILE: '+str(path)+'\n'+detail[-16000:])


def validate_saved_attempt(cfg,folder,result):
    if result.get('export_error'):raise RuntimeError('Export failed: '+str(folder/'status.json'))
    if result['status']=='failed' and any(k in result.get('error','') for k in ['AttributeError','ImportError','ModuleNotFoundError','Viewer','viewer','TypeError','FloatingPointError']):operational_error(folder)
    integrity=folder/'file_integrity.json'
    if integrity.exists():
        for name,value in read(integrity).items():
            if not (folder/name).exists() or sha(folder/name)!=value:raise ValueError('Saved episode file changed: '+str(folder/name))
    if result.get('sample_count',0):
        with np.load(folder/'training_arrays.npz',allow_pickle=False) as z:
            x=z['X_raw'];y=z['y_force_N'];t=z['time_s']
            if list(z['feature_names'])!=FEATURES or x.shape!=(len(t),24) or y.shape!=(len(t),1) or len(t)!=result['sample_count']:raise ValueError('Invalid saved data dimensions: '+str(folder))
            if not np.isfinite(x).all() or not np.isfinite(y).all() or not np.allclose(x[:,21],cfg['strength_scale']) or not np.all(np.diff(t)>0) or y.min()<0 or y.max()>650.0001:raise ValueError('Invalid values/time/strength in saved data: '+str(folder))
            if not np.isclose(np.degrees(x[0,0]-x[0,2]),cfg['initial_offset_deg'],atol=1e-4) or not np.isclose(np.degrees(x[0,1]),cfg['initial_velocity_deg_s'],atol=1e-4):raise ValueError('Recorded initial state differs from the declared recovery state.')
    if result.get('accepted_for_imitation') and (result['status']!='completed' or not result.get('tracking_passed')):raise ValueError('Invalid teacher acceptance flag.')
    if not integrity.exists():
        names=['settings.json','status.json','signals.csv','states.csv','states.sto','training_arrays.npz','legacy22_arrays.npz','muscle_strength_audit.json','playback_model.osim']
        write(integrity,{name:sha(folder/name) for name in names if (folder/name).exists()})
    return result


def execute(cfg,folder,timeout):
    folder.mkdir(parents=True,exist_ok=True)
    if PROGRESS is not None:cfg['progress_label']=PROGRESS.start(cfg,folder,'pilot' if cfg['split']=='pilot' else 'full')
    # Display/export settings do not change the physics identity.
    identity=hashlib.sha256(json.dumps({k:v for k,v in cfg.items() if k not in ['live_viewer','save_plots','progress_label']},sort_keys=True).encode()).hexdigest()
    ip=folder/'episode_identity.json';sp=folder/'status.json'
    if sp.exists() and read(sp)['status'] in ['completed','failed']:
        saved=read(sp)
        retry_operational=bool(saved.get('export_error')) or (saved['status']=='failed' and any(k in saved.get('error','') for k in ['AttributeError','ImportError','ModuleNotFoundError','Viewer','viewer','TypeError','FloatingPointError']))
        if not ip.exists() or read(ip)['sha256']!=identity:raise ValueError('Existing episode configuration changed: '+str(folder))
        if not retry_operational:
            print('REUSING VERIFIED SAVED ATTEMPT:',cfg['episode_id'],flush=True)
            result=validate_saved_attempt(cfg,folder,saved)
            if PROGRESS is not None:PROGRESS.finish(reused=True)
            return result
    if any(folder.iterdir()):
        archive=folder.parent/'interrupted_attempts';archive.mkdir(exist_ok=True);folder.rename(archive/(folder.name+'_'+str(time.time_ns())));folder.mkdir()
    write(folder/'settings.json',cfg);write(ip,dict(sha256=identity))
    print(f"PID {cfg['strength_scale']*100:g}% | {cfg['episode_id']} | {cfg['profile']['shoulder_mode']} shoulder | {cfg['duration_s']:.1f}s",flush=True)
    run_logged([sys.executable,ROOT/'complex_engine.py','--worker',folder],folder/'console.log',allowed=(0,2),timeout=timeout,heartbeat=PROGRESS.refresh if PROGRESS is not None else None)
    result=validate_saved_attempt(cfg,folder,read(sp))
    if result.get('export_error'):raise RuntimeError('Export failed: '+str(folder/'status.json'))
    if result['status']=='failed' and any(k in result.get('error','') for k in ['AttributeError','ImportError','ModuleNotFoundError','Viewer','viewer','TypeError','FloatingPointError']):operational_error(folder,'Operational error; no speed calibration performed.')
    m=result.get('motion_only') or {};print('  '+result['status']+f" | RMSE {m.get('rmse_deg','n/a')} deg | accepted {result['accepted_for_imitation']}",flush=True)
    if PROGRESS is not None:PROGRESS.finish()
    return result


def main():
    global PROGRESS
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--output-root',type=Path,default=Path.home()/'Arm26_Final_PID_Data');p.add_argument('--run-folder',type=Path);p.add_argument('--resume',action='store_true');p.add_argument('--plan-only',action='store_true');p.add_argument('--report-only',action='store_true')
    p.add_argument('--old-family',choices=FAMILIES,default='variable_speed');p.add_argument('--families',choices=FAMILIES,nargs='+',default=FAMILIES);p.add_argument('--shoulder-modes',choices=['fixed','moving'],nargs='+',default=['fixed','moving']);p.add_argument('--initial-angles',type=float,nargs='+',default=[20.,45.,70.]);p.add_argument('--masses',type=float,nargs='+',default=[5.])
    p.add_argument('--strengths',type=int,nargs='+',default=[90,60]);p.add_argument('--initial-errors',type=float,nargs='+',default=[-.5,0.,.5]);p.add_argument('--initial-velocities',type=float,nargs='+',default=[-5.,0.,5.]);p.add_argument('--moving-shoulder-poses',type=float,nargs='+',default=[0.,5.]);p.add_argument('--shoulder-poses',type=float,nargs='+',default=[-5.,0.,15.])
    p.add_argument('--train-reps',type=int,default=3);p.add_argument('--validation-reps',type=int,default=1);p.add_argument('--test-reps',type=int,default=1);p.add_argument('--seed',type=int,default=20261106);p.add_argument('--dt',type=float,default=.005);p.add_argument('--rmse-limit',type=float,default=.1);p.add_argument('--max-error-limit',type=float,default=1.1);p.add_argument('--speed-multiplier',type=float,default=1.);p.add_argument('--no-live',action='store_true',default=True,help='No live windows (default).');p.add_argument('--live',dest='no_live',action='store_false',help='Explicitly enable live windows.');p.add_argument('--episode-timeout',type=float,default=600.)
    p.add_argument('--speed-levels',type=float,nargs='+',default=[1.,1.25],help='Separate paired speed conditions; default 1.0 and 1.25.')
    p.add_argument('--github-repo',default=DEFAULT_GITHUB_REPO,help='Your GitHub repository URL; already configured by default.')
    p.add_argument('--github-branch');p.add_argument('--github-cache',type=Path);p.add_argument('--github-every-pairs',type=int,default=10);p.add_argument('--no-github',action='store_true');p.add_argument('--backup-only',action='store_true')
    a=p.parse_args()
    if a.github_every_pairs<1:p.error('--github-every-pairs must be positive.')
    if len(set(a.speed_levels))!=len(a.speed_levels) or not all(math.isfinite(x) and 0<x<=2 for x in a.speed_levels) or max(a.speed_levels)*a.speed_multiplier>2:p.error('Unique speed levels and combined requested speed must be in (0,2].')
    if not set([90,60])<=set(a.strengths) or any(x<30 or x>100 for x in a.strengths):p.error('Include strengths 90 and60; any additional strengths must lie in30-100 percent.')
    if not all(math.isfinite(x) and abs(x)<=.75 for x in a.initial_errors) or not all(math.isfinite(x) and abs(x)<=15 for x in a.initial_velocities) or not all(math.isfinite(x) and -5<=x<=15 for x in a.shoulder_poses):p.error('Initial errors must be <=0.75 deg, initial speeds <=15 deg/s and fixed shoulder poses -5 to15 deg.')
    if not all(math.isfinite(x) and 0<=x<=5 for x in a.moving_shoulder_poses):p.error('Moving-shoulder centers are restricted to the reviewed 0-5 degree band; fixed poses are -5 to15 deg.')
    if max(abs(x) for x in a.initial_errors)>a.max_error_limit:p.error('The declared initial tracking error exceeds the full-run maximum-error acceptance limit.')
    if not a.report_only and a.old_family not in a.families:p.error('--old-family must be among --families.')
    if min(a.train_reps,a.validation_reps,a.test_reps)<1 or not all(10<=x<=110 for x in a.initial_angles) or not all(math.isfinite(x) and 0<=x<=10 for x in a.masses):p.error('Positive split repetitions, initial angles 10-110 deg and masses 0-10 kg are required.')
    if not .001<=a.dt<=.02 or not math.isfinite(a.speed_multiplier) or not 0<a.speed_multiplier<=2 or not all(math.isfinite(x) and x>0 for x in [a.rmse_limit,a.max_error_limit,a.episode_timeout]):p.error('Invalid timing/quality setting.')
    for values in [a.families,a.shoulder_modes,a.initial_angles,a.masses,a.strengths,a.initial_errors,a.initial_velocities,a.shoulder_poses,a.moving_shoulder_poses]:
        if len(set(values))!=len(values):p.error('Repeated condition entries would duplicate data.')
    pointer=ROOT/'LATEST_COLLECTION.txt'
    if a.backup_only:
        from github_backup import GitBackup
        folder=a.run_folder or (Path(pointer.read_text().strip()) if pointer.exists() else None)
        if folder is None:p.error('Specify --run-folder for backup.')
        repo=a.github_repo or input('GitHub repository URL or existing local clone path: ').strip()
        GitBackup(repo,folder,a.github_branch,a.github_cache).sync(ROOT);return 0
    if a.report_only:
        folder=a.run_folder or (Path(pointer.read_text().strip()) if pointer.exists() else None)
        if folder is None:p.error('Specify --run-folder.')
        from collection_report import build_report
        build_report(folder);return 0
    out=(a.run_folder or (Path(pointer.read_text().strip()) if a.resume and pointer.exists() else a.output_root/('final_pid_'+time.strftime('%Y%m%d_%H%M%S')+'_'+uuid.uuid4().hex[:6]))).resolve();out.mkdir(parents=True,exist_ok=True)
    config={k:v for k,v in vars(a).items() if k not in ['output_root','run_folder','resume','plan_only','report_only','no_live','github_repo','github_branch','github_cache','github_every_pairs','no_github','backup_only']};config['source_hashes']={f.name:sha(f) for f in ROOT.glob('*.py')};config['model_sha256']=sha(ROOT/'arm26_exosuit.osim')
    if (out/'COLLECTION.json').exists():
        if read(out/'COLLECTION.json')['config']!=config:raise ValueError('Saved configuration/source changed; use its original version or start a new collection.')
    else:write(out/'COLLECTION.json',dict(config=config,features=FEATURES,format_version=2,notes='PID-only quality calibration; no NN outcomes used. Prescribed external shoulder motion, elbow cable PID. New 24-input format; legacy22 view separately exported.'))
    pointer.write_text(str(out))
    conditions=[(condition_key(f,m,s,w)+'_speed'+format(level,'.8g').replace('.','p'),f,m,s,w,level) for f,m,s,w,level in itertools.product(a.families,a.shoulder_modes,a.initial_angles,a.masses,a.speed_levels)]
    plan=[]
    for key,family,mode,start,mass,level in conditions:
        for split,reps in [('train',a.train_reps),('validation',a.validation_reps),('test',a.test_reps)]:
            for rep in range(reps):
                cfg=episode_config(a,key,family,mode,start,mass,split,rep,level*a.speed_multiplier);cfg['requested_speed_scale']=level*a.speed_multiplier;plan.append(cfg)
    write(out/'UNSCALED_PLAN.json',plan)
    write(out/'WORKLOAD.json',dict(full_episode_count=len(plan)*len(a.strengths),minimum_pilot_episode_count=len(conditions)*len(a.strengths)*len(pilot_recoveries(a)),maximum_pilot_episode_count=5*len(conditions)*len(a.strengths)*len(pilot_recoveries(a)),requested_speed_levels=a.speed_levels,nominal_full_simulated_minutes=sum(c['duration_s'] for c in plan)*len(a.strengths)/60,note='Pilot slowdown, viewers and CPU compute change wall time; no GPU acceleration is claimed for OpenSim.'))
    from collection_report import preview
    preview(out,plan)
    print('MODE:', 'DATA ONLY (no live windows)' if a.no_live else 'LIVE VIEWER',flush=True)
    print('GITHUB REPOSITORY:',a.github_repo if not a.no_github else 'disabled explicitly',flush=True)
    print('RESULT FOLDER:',out,flush=True);print('FULL EPISODES:',len(a.strengths)*len(plan),'| independent pilot conditions:',len(conditions),'x',len(a.strengths),'strengths x',len(pilot_recoveries(a)),'extreme recovery cases; retries only if PID fails.',flush=True)
    if a.plan_only:return 0
    from collection_progress import Progress
    minimum=len(conditions)*len(a.strengths)*len(pilot_recoveries(a))
    PROGRESS=Progress(out,minimum,5*minimum,len(plan)*len(a.strengths),sum(c['duration_s'] for c in plan)*len(a.strengths))
    backup=None
    if not a.no_github:
        from github_backup import GitBackup
        repo=a.github_repo or input('GitHub repository URL or existing local clone path (required for automatic backup): ').strip()
        if not repo:p.error('Provide --github-repo or explicitly use --no-github.')
        backup=GitBackup(repo,out,a.github_branch,a.github_cache)
        backup.sync(ROOT)
    else:write(out/'GITHUB_STATUS.json',dict(status='disabled_explicitly'))
    import opensim as o
    write(out/'ENVIRONMENT.json',dict(opensim=o.GetVersion(),python=sys.version,features=len(FEATURES),cuda='not used: collection is CPU OpenSim, not NN training'))
    snapshot=out/'source';snapshot.mkdir(exist_ok=True)
    import shutil
    for file in list(ROOT.glob('*.py'))+[ROOT/'arm26_exosuit.osim']:shutil.copy2(file,snapshot/file.name)
    calibration_path=out/'PILOT_CALIBRATION.json';calibration=read(calibration_path) if calibration_path.exists() else {}
    for key,family,mode,start,mass,level in conditions:
        if key in calibration and calibration[key]['selected_speed_scale'] is not None:
            for attempt in calibration[key]['attempts']:
                folder=Path(attempt['folder']);validate_saved_attempt(read(folder/'settings.json'),folder,read(folder/'status.json'))
            PROGRESS.done['pilot']+=len(calibration[key]['attempts']);PROGRESS.extra+=max(0,len(calibration[key]['attempts'])-len(a.strengths)*len(pilot_recoveries(a)));PROGRESS.refresh(force=True)
            continue
        selected=None;attempts=[]
        for factor in [1.,.8,.64,.512,.4096]:
            scale=factor*a.speed_multiplier*level;ok=True
            if factor!=1.:PROGRESS.add_pilot_batch(len(a.strengths)*len(pilot_recoveries(a)))
            for recovery_index,recovery in enumerate(pilot_recoveries(a)):
                for pct in a.strengths:
                    cfg=episode_config(a,key,family,mode,start,mass,'pilot',0,scale,pilot=True,recovery_override=recovery);cfg['requested_speed_scale']=level*a.speed_multiplier;cfg['strength_scale']=pct/100;cfg['episode_id']+='_r'+str(recovery_index)+'_s'+str(pct)
                    folder=out/'pilot'/key/('speed_'+format(scale,'.8g'))/('recovery_'+str(recovery_index))/str(pct);result=execute(cfg,folder,a.episode_timeout);ok &= result['accepted_for_imitation'];attempts.append(dict(speed_scale=scale,strength=pct,recovery=list(recovery),status=result['status'],accepted=result['accepted_for_imitation'],folder=str(folder),motion_only=result.get('motion_only')))
            if ok:selected=scale;break
        calibration[key]=dict(selected_speed_scale=selected,attempts=attempts);write(calibration_path,calibration)
        if backup is not None and sum(PROGRESS.done.values())%(2*a.github_every_pairs)==0:
            PROGRESS.stage('github_backup');backup.sync(ROOT);PROGRESS.stage('pilot')
        if selected is None:
            from collection_report import build_report
            build_report(out);raise RuntimeError('Both-strength PID pilot did not pass for '+key+'. Full collection stopped; all attempts preserved. Adjust the declared collection settings in a NEW run; no NN test was used.')
    if backup is not None:
        PROGRESS.stage('github_backup');backup.sync(ROOT)
    PROGRESS.stage('full')
    final=[]
    for cfg in plan:configure(cfg,calibration[cfg['condition']]['selected_speed_scale']);cfg['speed_statistics']=speed_statistics(cfg);cfg['reference_sha256']=reference_digest(cfg);final.append(cfg)
    PROGRESS.full_seconds=sum(c['duration_s'] for c in final)*len(a.strengths)
    write(out/'FROZEN_PLAN.json',final);records=[]
    for pair_index,base in enumerate(final,1):
        pair=[]
        for pct in a.strengths:
            cfg=dict(base,strength_scale=pct/100,episode_id=base['episode_id']+'_s'+str(pct));folder=out/f'strength_{pct}'/cfg['episode_id'];result=execute(cfg,folder,a.episode_timeout)
            pair.append(dict(uid=f"{pct}/{cfg['motion_id']}",motion_id=cfg['motion_id'],condition=cfg['condition'],episode_id=cfg['episode_id'],folder=str(folder),strength_scale=pct/100,split=cfg['split'],initial_reference_deg=cfg['profile']['start_deg'],initial_offset_deg=cfg['initial_offset_deg'],initial_velocity_deg_s=cfg['initial_velocity_deg_s'],shoulder_mode=cfg['profile']['shoulder_mode'],shoulder_start_deg=cfg['profile']['shoulder_start_deg'],requested_speed_scale=cfg['requested_speed_scale'],selected_speed_scale=cfg['speed_scale'],peak_reference_speed_deg_s=cfg['speed_statistics']['peak_elbow_speed_deg_s'],trajectory=cfg['trajectory'],regime=cfg['task'],reference_sha256=cfg['reference_sha256'],individual_pid_accepted=result['accepted_for_imitation'],status=result['status'],samples=result['sample_count'],motion_rmse_deg=(result.get('motion_only') or {}).get('rmse_deg'),arrays_sha256=sha(folder/'training_arrays.npz') if (folder/'training_arrays.npz').exists() else None))
        accepted=all(r['individual_pid_accepted'] for r in pair)
        for r in pair:r['paired_accepted']=accepted
        records.extend(pair);write(out/'DATASET_MANIFEST.json',dict(format_version=2,features=FEATURES,records=records,complete=False))
        if backup is not None and pair_index%a.github_every_pairs==0:
            PROGRESS.stage('github_backup');backup.sync(ROOT);PROGRESS.stage('full')
    coverage=[]
    for key,*_ in conditions:
        for split in ['train','validation','test']:
            if not any(r['condition']==key and r['split']==split and r['paired_accepted'] for r in records):coverage.append(dict(condition=key,split=split))
    write(out/'DATASET_MANIFEST.json',dict(format_version=2,features=FEATURES,records=records,complete=True,all_condition_split_coverage=not coverage,missing_coverage=coverage))
    roles={'TASK_A_90':lambda r:r['strength_scale']==.9 and r['regime']=='old_task_A','TASK_B_60':lambda r:r['strength_scale']==.6 and r['regime']=='complex_task_B','DIAGNOSTIC_COMPLEX_90':lambda r:r['strength_scale']==.9 and r['regime']=='complex_task_B','CONTROL_A_60':lambda r:r['strength_scale']==.6 and r['regime']=='old_task_A'}
    if 45 in a.strengths:roles['TASK_C_45']=lambda r:r['strength_scale']==.45 and r['regime']=='complex_task_B'
    for pct in a.strengths:roles['ALL_ACCEPTED_'+str(pct)]=lambda r,pct=pct:round(100*r['strength_scale'])==pct
    for name,predicate in roles.items():write(out/(name+'.json'),dict(format_version=2,features=FEATURES,role=name,records=[r for r in records if r['paired_accepted'] and predicate(r)],note='PID-passing paired episodes only. Role separation prevents teaching initial Task A all future complex motions. Pilot episodes are excluded.'))
    write(out/'COLLECTION_STATUS.json',dict(status='complete' if not coverage else 'complete_with_missing_coverage',attempted=len(records),paired_accepted=sum(r['paired_accepted'] for r in records),missing_coverage=coverage))
    from complex_trajectories import SCALES
    write(out/'TRAINING_HANDOFF.json',dict(format_version=2,features=FEATURES,input_scales=SCALES.tolist(),encoding='tracking_error_v1',error_encoding='z[2]=(reference-angle)/0.02 rad; z[3]=(reference_velocity-velocity)/0.2 rad/s',target='y_force_N',target_scale_N=650.,primary_arrays='training_arrays.npz',role_files=list(roles),collection_only=True,notes='Use accepted role manifests; no pilot/diagnostic records. NN90 must be trained on Task A with the same24-input architecture before subsequent adaptation. Future methods and repetitions must share held-out episodes.'))
    from collection_report import build_report
    PROGRESS.stage('report')
    build_report(out)
    final_status='complete' if not coverage else 'complete_with_missing_coverage'
    if backup is not None:
        PROGRESS.stage('github_backup')
        print('SIMULATION AND REPORT COMPLETE; final GitHub backup is now being verified.',flush=True)
        backup.sync(ROOT,final_status=final_status)
    PROGRESS.stage(final_status)
    print('ALL REQUESTED STAGES FINISHED.',flush=True)
    print('DATA MANIFEST:',out/'DATASET_MANIFEST.json',flush=True);print('OVERLEAF:',out/'COLLECTION_OVERLEAF.zip',flush=True)
    return 0 if not coverage else 2

if __name__=='__main__':
    try:raise SystemExit(main())
    except KeyboardInterrupt:
        if PROGRESS is not None:PROGRESS.stage('interrupted')
        print('Interrupted. Resume with the same flags plus --resume.',flush=True);raise SystemExit(130)
    except Exception as exc:
        if PROGRESS is not None:PROGRESS.stage('failed')
        print('COLLECTION STOPPED:',exc,flush=True);raise
