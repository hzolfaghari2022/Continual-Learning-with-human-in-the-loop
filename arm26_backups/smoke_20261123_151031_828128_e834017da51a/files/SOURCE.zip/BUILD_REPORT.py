from pathlib import Path
import sys
from adapter.reporting import build
if __name__=='__main__':build(Path(sys.argv[1]))
