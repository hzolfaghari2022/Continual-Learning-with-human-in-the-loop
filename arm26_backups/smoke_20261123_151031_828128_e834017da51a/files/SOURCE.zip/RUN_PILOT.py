"""Open this file in VS Code and select Run Python File in Terminal."""
from entry import main
if __name__=='__main__':
    try:raise SystemExit(main('pilot'))
    except Exception as error:
        print('ERROR:',error,flush=True)
        print('Existing data and completed outputs remain saved; read the printed log path',flush=True)
        raise SystemExit(1)
