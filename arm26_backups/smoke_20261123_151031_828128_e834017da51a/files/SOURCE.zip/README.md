# Arm26 OpenSim RL — short pilot and separate full experiment

## Start with the pilot
Extract this ZIP into a fresh folder, open its Arm26_CW_Pilot folder in VS Code and run **RUN_ALL.py**. It reuses the installed arm26-cw environment (or installs it if missing), runs real setup checks, runs the brief smoke check, then runs the SHORT PILOT. It does not start full training automatically.

Do not run an old full experiment simultaneously. If switching, stop that experiment first; existing files remain saved, but exact mid-method resume is not supported by the authors' unchanged loop. This is a separate pilot, not a modification of a live run.

| Setting | Pilot | Full |
|---|---:|---:|
| Steps per case per method | 10,000 | 1,000,000 |
| Total training interactions, two methods | 80,000 | 8,000,000 |
| Random exploration steps per case | 1,000 | 10,000 |
| PackNet retraining updates per nonfinal case | 2,000 | 100,000 |
| Periodic stochastic validation episodes per case | 1 | 10 |
| Frozen references per case | 3 validation | 30 reserved test |
| Frozen references per method | 12 | 120 |
| Motion duration / physical timing | Full original trajectories | Full original trajectories |

Batch128, original 4x256 architecture, reward, force mapping, case order, physics and author learning code are unchanged between pilot and full. The pilot does not shorten each motion or use the reserved test split. Buffer capacity remains1M; fewer interaction steps limit actual samples.

At the user's last measured rate, pilot training interactions alone would take about1.3hours; validation, integration checks, PackNet retraining and GitHub uploads add time. No fixed completion time or learned accuracy is guaranteed. A poor short-budget result may be undertraining rather than a CL-method failure.

## Longer experiment after reviewing pilot results
Run **RUN_ALL_FULL.py** explicitly in this package, or use the previous long-version package. Full mode retains the previous long budgets. It is a new long run with separate dated outputs, NOT exact continuation of the pilot's optimizer/replay/physics/RNG state. Do not call pilot-versus-full differences equal-budget comparisons.

Separate entries: CHECK_SETUP.py, RUN_SMOKE.py, RUN_PILOT.py, RUN_FULL_RL.py. Each experiment has distinct LAST_SMOKE/LAST_PILOT/LAST_FULL markers. RUN_LOCAL_TESTS.py runs infrastructure/profile tests without real physics/GPU.

## Source and method
Official repository https://github.com/awarelab/continual_world
Pinned commit73f63bb4fa0b5d00bda973e20dfb783bfcf1b8aa;46original source/text Git blob hashes checked.
Methods: original SAC sequential fine-tuning (no_cl), original PackNet-SAC (packnet). No upstream learning file is patched or subclassed. Only external environment, logging, reporting and runtime-budget configuration are local. This is NOT the historical supervised replay-beta MLP, not CLEAR's implementation and not reproduction of Meta-World scores.

## Source scenarios
Default source600collection:
C:\Users\hzlfghri\A26Final_7e4d7951\runs\collect_20261114_164226_441056
420train/60validation/120reserved scenario settings reused. PID force-label arrays are not read. Shortening the RL budget does not require recollecting these scenarios. Original case profile differences remain; this does not isolate strength alone.

Cases A90%, B60%, C30%, D45%,5kg dumbbell.28encoded features plus4known-case selectors; scalar action[-1,1]→cable force0..650N. Actor shared core sees28features, selector chooses a head. Known strength/case is supplied; unknown-user inference is not established.

Reward: exp(-(angle_error_deg/5)^2)-.01(F/650)^2-.01(deltaF/650)^2-.05 min((velocity_error_rad_s/.5)^2,25). Failure reward-20. dt.02s, integrator maxstep.005s. No PID action during RL. Complete-trajectory accuracy criterion: motion RMSE≤.5deg,peak≤2deg. Failures/truncations remain distinct from successful trajectories.

## Runtime, outputs and backups
Existing lstm-py312 Python runs CPU OpenSim; separate arm26-cw Python3.10/TF2.10 runs CUDA learning. Existing environments/data are preserved. settings.json can override dataset/physics_python/rl_python paths. Long paths relocate to a stable short working folder; use the printed folder.

Dated runs contain source snapshot, scenario settings, traces, progress, saved original actor/critic checkpoints, PackNet ownership state, figures, REPORT.html, OVERLEAF_REPORT.zip and SAVED_MODELS.zip. Pilot report is validation only; full report is reserved tests. No missing metric is invented as zero. One seed only.

GitHub backup remains ON at initialization,10kinteraction intervals, other checkpoints and final reports. Temporary progress locks do not kill learning. Upload errors are deferred and recorded in BACKUP_PENDING.json; later scheduled checkpoints retry. RETRY_GITHUB.py retries the most recently launched pilot/full suite, or accepts an exact saved suite folder. It does not retrain. Only an actual verified commit counts as upload success.

All prior Windows I/O v2 fixes retained, including excluding held .lock/.tmp files from SOURCE.zip and long-path working-copy operations. Duplicate-launch lock applies within one code folder; different extracted copies can still run independently, so do not launch old and new simultaneously.

## Limits
Local source, fault-injection, profile and report tests are not real OpenSim/CUDA validation or learned performance. The user's older installation passed real integration tests; run this package's checks again. No guarantee of tracking accuracy, CL superiority, hardware transfer, exact resume or error-free execution.
