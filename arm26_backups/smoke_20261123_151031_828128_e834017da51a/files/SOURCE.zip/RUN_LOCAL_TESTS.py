"""Stdlib infrastructure tests; these do not test real physics or learning quality."""
from pathlib import Path
import subprocess,sys
if __name__=='__main__':
    root=Path(__file__).resolve().parent
    raise SystemExit(subprocess.call([sys.executable,'-m','unittest','discover','-s',str(root/'tests'),'-v'],cwd=root))
