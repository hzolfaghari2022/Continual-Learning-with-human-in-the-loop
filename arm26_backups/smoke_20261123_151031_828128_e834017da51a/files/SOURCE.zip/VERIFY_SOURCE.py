"""Byte identity and syntax checks only; no physics or learning claims."""
from pathlib import Path
import ast
from adapter.common import verify_upstream,ROOT
if __name__=='__main__':
    print('Original commit:',verify_upstream())
    files=list(ROOT.rglob('*.py'))
    for file in files:
        if not any(k in file.relative_to(ROOT).parts for k in ['runs','github_cache','__pycache__']):ast.parse(file.read_text(encoding='utf-8-sig'),filename=str(file))
    print('PASS: unchanged upstream Git blob hashes and Python source syntax')
    print('Next: RUN_ALL.py (short pilot); RUN_ALL_FULL.py (explicit long run)')
