"""Retry a saved run upload without training. Uses its existing verified cache.
Run directly for the most recently launched pilot/full suite; or pass the exact run folder as an argument.
Do not run concurrently with an active experiment in this code folder.
"""
from pathlib import Path
import os,sys
from adapter.common import ROOT,read
from adapter.run_guard import launcher_guard

def main():
    with launcher_guard():
        suite=Path(sys.argv[1]) if len(sys.argv)>1 else Path(read(max((p for p in (ROOT/'LAST_FULL.json',ROOT/'LAST_PILOT.json') if p.exists()),key=lambda p:p.stat().st_mtime))['folder'])
        os.environ.setdefault('ARM26_VERIFIED_BACKUP_CACHE',str(ROOT/'github_cache'))
        from adapter.resilience import best_effort_backup
        result=best_effort_backup(suite,'manual retry of pending backup',final=(suite/'SUITE_COMPLETE.json').exists())
        if result is None:raise RuntimeError('Upload remains pending. Local files preserved')
        print('GITHUB VERIFIED:',result['commit_url'],flush=True)
if __name__=='__main__':
    try:main()
    except Exception as exc:print('BACKUP RETRY FAILED:',exc,flush=True);raise SystemExit(1)
