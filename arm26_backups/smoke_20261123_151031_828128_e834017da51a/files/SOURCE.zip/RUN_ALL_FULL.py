"""VS Code entry: environment if missing, real checks, smoke, then full RL.
Keep the terminal open. Full budget is 8M interactions plus evaluation.
"""
from pathlib import Path
import os,subprocess,sys
ROOT=Path(__file__).resolve().parent

def main():
    if os.name!='nt':raise RuntimeError('This convenience launcher targets Windows; individual launchers remain available')
    python=Path.home()/'miniconda3/envs/arm26-cw/python.exe'
    if not python.is_file():
        subprocess.run([sys.executable,'-u',str(ROOT/'SETUP_RL_ENV.py')],check=True,cwd=ROOT)
    if not python.is_file():raise FileNotFoundError('RL environment was not created: '+str(python))
    print('Full run: 8M new physics interactions plus evaluation/retraining; can take several days.',flush=True)
    for name in ('CHECK_SETUP.py','RUN_SMOKE.py','RUN_FULL_RL.py'):
        print('\nRUNNING '+name,flush=True)
        subprocess.run([str(python),'-u','-X','utf8',str(ROOT/name)],check=True,cwd=ROOT)
    print('Finished. Check REPORT.html and any BACKUP_PENDING.json in the printed results folder.',flush=True)
if __name__=='__main__':
    try:main()
    except KeyboardInterrupt:print('Interrupted; partial outputs preserved. Interrupted methods restart on relaunch.',flush=True);raise SystemExit(130)
    except Exception as exc:print('RUN STOPPED: '+str(exc),flush=True);raise SystemExit(1)
