"""Persistent isolated OpenSim process. Stdout is a dedicated JSON protocol."""
import os,sys,json,math,traceback,csv
from pathlib import Path
# Keep a clean response stream even when native OpenSim writes to stdout.
protocol=os.fdopen(os.dup(sys.stdout.fileno()),'w',encoding='utf-8',buffering=1)
os.dup2(sys.stderr.fileno(),sys.stdout.fileno())
sys.path[:0]=[str(Path(__file__).resolve().parent/'core')]
import runtime_setup
import numpy as np
import opensim as o
from complex_engine import build
from complex_trajectories import FEATURES,MUSCLES,encode,reference
from four_trajectories import load_force_y
from path_geometry import path_moment_arms
o.Logger.setLevelString('Error')

class InfrastructureError(RuntimeError):pass

class Plant:
    def reset(self,cfg,options,folder):
        self.cfg=cfg;self.options=options;self.folder=Path(folder);self.folder.mkdir(parents=True,exist_ok=True)
        self.model,self.state,self.el,self.sh,self.cable=build(o,cfg)
        if not np.isclose(math.degrees(self.el.getValue(self.state)),cfg['profile']['start_deg']+cfg.get('initial_offset_deg',0),atol=1e-7):raise InfrastructureError('Actual initial elbow angle does not match scenario')
        if not np.isclose(math.degrees(self.el.getSpeedValue(self.state)),cfg.get('initial_velocity_deg_s',0),atol=1e-7):raise InfrastructureError('Actual initial velocity does not match scenario')
        (self.folder/'muscle_strength_audit.json').write_text(json.dumps(cfg['muscle_strength_audit'],indent=2),encoding='utf-8')
        self.mus=self.model.getMuscles();self.yaw=self.model.getCoordinateSet().get('r_shoulder_yaw')
        self.integral=0.;self.previous=0.;self.rows=[];self.finished=False
        self.stream=(self.folder/'signals.partial.csv').open('w',encoding='utf-8',newline='',buffering=1);self.writer=None
        obs,row=self.observe();self.log(row)
        return dict(observation=obs,config_episode_id=cfg['episode_id'])
    def observe(self):
        m,s=self.model,self.state;m.realizeAcceleration(s);t=float(s.getTime())
        if abs(float(self.cable.getActuation(s))-self.previous)>1e-6:raise InfrastructureError('Applied cable force differs from requested force')
        q=float(self.el.getValue(s));v=float(self.el.getSpeedValue(s));qr,vr,ar,moving=reference(t,self.cfg)
        r=dict(angle_rad=q,velocity_rad_s=v,reference_rad=qr,reference_velocity_rad_s=vr,reference_acceleration_rad_s2=ar,mass_kg=self.cfg['mass_kg'],shoulder_angle_rad=float(self.sh.getValue(s)),previous_tension_N=self.previous,error_integral_rad_s=self.integral,strength_scale=self.cfg['strength_scale'],shoulder_velocity_rad_s=float(self.sh.getSpeedValue(s)),shoulder_acceleration_rad_s2=float(self.sh.getAccelerationValue(s)),yaw_rad=float(self.yaw.getValue(s)),yaw_velocity_rad_s=float(self.yaw.getSpeedValue(s)),yaw_acceleration_rad_s2=float(self.yaw.getAccelerationValue(s)),external_load_y_N=load_force_y(t,self.cfg))
        for i,name in enumerate(MUSCLES):
            muscle=self.mus.get(i);r[name+'_activation']=float(muscle.getActivation(s));r[name+'_normalized_fiber_length']=float(muscle.getFiberLength(s)/muscle.getOptimalFiberLength())
        raw=np.array([[r[k] for k in FEATURES]],np.float32)
        if not np.isfinite(raw).all():raise FloatingPointError('Nonfinite physical observation')
        row=dict(time_s=t,angle_deg=math.degrees(q),reference_deg=math.degrees(qr),error_deg=math.degrees(qr-q),velocity_rad_s=v,reference_velocity_rad_s=vr,tension_N=self.previous,moving=int(moving))
        return encode(raw)[0].astype(float).tolist(),row
    def log(self,row):
        if self.writer is None:self.writer=csv.DictWriter(self.stream,fieldnames=list(row));self.writer.writeheader()
        self.writer.writerow(row);self.rows.append(row)
    def finish(self,failed=False,error=None,truncated=False):
        if self.finished:return self.result
        self.finished=True;self.stream.close();os.replace(self.folder/'signals.partial.csv',self.folder/'signals.csv')
        motion=[r for r in self.rows if r['moving']];errors=[r['error_deg'] for r in motion]
        rmse=float(np.sqrt(np.mean(np.square(errors)))) if errors else None;peak=max(map(abs,errors),default=None)
        success=not failed and not truncated and rmse is not None and rmse<=self.options['success_rmse_deg'] and peak<=self.options['success_motion_peak_deg']
        self.result=dict(status='failed' if failed else 'truncated' if truncated else 'completed',success=bool(success),rmse_deg=rmse if not failed and not truncated else None,partial_rmse_deg=rmse if failed or truncated else None,motion_peak_deg=peak,all_peak_deg=max(abs(r['error_deg']) for r in self.rows),samples=len(self.rows),error=error,episode_id=self.cfg['episode_id'],split=self.cfg['split'],case=self.cfg['task_id'])
        (self.folder/'status.json').write_text(json.dumps(self.result,indent=2,allow_nan=False),encoding='utf-8');return self.result
    def step(self,action):
        if self.finished:raise RuntimeError('step after episode termination')
        old=self.rows[-1];last=self.previous
        force=(float(np.clip(action,-1,1))+1.)*.5*self.options['force_cap_N'];self.previous=force
        dt=min(self.options['control_dt_s'],self.cfg['duration_s']-float(self.state.getTime()))
        try:
            arm=path_moment_arms(o,self.model,self.state,self.el,self.cable,self.mus)[0]
            if arm<.005:raise RuntimeError('Insufficient/reversed exosuit moment arm')
            self.integral=float(np.clip(self.integral+math.radians(old['error_deg'])*dt,-self.cfg['integral_limit_rad_s'],self.cfg['integral_limit_rad_s']))
            self.cable.setOverrideActuation(self.state,force)
            self.model.realizeAcceleration(self.state)
            if abs(float(self.cable.getActuation(self.state))-force)>1e-6:raise InfrastructureError('Exosuit force override mismatch')
            manager=o.Manager(self.model);manager.setIntegratorAccuracy(self.cfg['integrator_accuracy']);manager.setIntegratorMaximumStepSize(self.options['physics_max_step_s']);manager.initialize(self.state)
            self.state=o.State(manager.integrate(float(self.state.getTime())+dt))
            obs,row=self.observe();self.log(row)
            if not 3<=row['angle_deg']<=123:raise RuntimeError('Elbow left3..123deg simulation envelope')
            self.model.realizePosition(self.state)
            if not -25<=math.degrees(self.sh.getValue(self.state))<=65:raise RuntimeError('Shoulder left study envelope')
            reward=math.exp(-(row['error_deg']/self.options['reward_angle_scale_deg'])**2)-self.options['reward_force_weight']*(force/self.options['force_cap_N'])**2-self.options['reward_force_change_weight']*((force-last)/self.options['force_cap_N'])**2-self.options['reward_velocity_weight']*min(((row['reference_velocity_rad_s']-row['velocity_rad_s'])/self.options['reward_velocity_scale_rad_s'])**2,25.)
            done=float(self.state.getTime())>=self.cfg['duration_s']-1e-8
            info=dict(physical_failure=False,success=False)
            if done:info.update(self.finish());info['TimeLimit.truncated']=True
            return dict(observation=obs,reward=reward,done=done,info=info)
        except (TypeError,AttributeError,ImportError,OSError,InfrastructureError):raise
        except Exception:
            try:obs,_=self.observe()
            except Exception:obs=self.last_observation
            info=self.finish(failed=True,error=traceback.format_exc());info['physical_failure']=True
            return dict(observation=obs,reward=self.options['failure_reward'],done=True,info=info)

plant=Plant()
for line in sys.stdin:
    try:
        request=json.loads(line);command=request['command']
        if command=='ping':result=dict(opensim_version=o.GetVersion(),python=sys.version.split()[0],ready=True)
        elif command=='reset':
            if hasattr(plant,'finished') and not plant.finished:plant.finish(truncated=True,error='reset before natural episode end')
            result=plant.reset(request['config'],request['options'],request['folder']);plant.last_observation=result['observation']
        elif command=='step':result=plant.step(request['action']);plant.last_observation=result['observation']
        elif command=='truncate':result=plant.finish(truncated=True,error=request.get('reason','external time limit'))
        elif command=='close':
            if hasattr(plant,'finished') and not plant.finished:plant.finish(truncated=True,error='environment closed')
            protocol.write(json.dumps(dict(ok=True,result={}))+'\n');break
        else:raise ValueError('Unknown physics command')
        protocol.write(json.dumps(dict(ok=True,result=result),allow_nan=False)+'\n')
    except Exception:protocol.write(json.dumps(dict(ok=False,error=traceback.format_exc()))+'\n')
