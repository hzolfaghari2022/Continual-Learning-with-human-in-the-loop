"""Run once in Windows VS Code. Creates a SEPARATE env; does not alter lstm-py312."""
from pathlib import Path
import subprocess,sys,os
ROOT=Path(__file__).resolve().parent

def main():
    home=Path.home();conda=home/'miniconda3'/'Scripts'/'conda.exe';prefix=home/'miniconda3'/'envs'/'arm26-cw'
    if os.name!='nt':raise RuntimeError('This setup launcher is for native Windows; use the documented Python3.10/TensorFlow2.10 environment on Linux')
    if not conda.is_file():raise RuntimeError('Conda not found: '+str(conda))
    if not (prefix/'python.exe').is_file():
        print('Creating isolated TensorFlow environment',flush=True)
        subprocess.run([str(conda),'create','--prefix',str(prefix),'-y','-c','conda-forge','python=3.10','cudatoolkit=11.2','cudnn=8.1.0','pip','setuptools=65.5.0'],cwd=home,check=True)
    else:print('Using existing arm26-cw environment; lstm-py312 is untouched',flush=True)
    subprocess.run([str(prefix/'python.exe'),'-m','pip','install','pip==23.3.2','wheel==0.41.3'],cwd=home,check=True)
    subprocess.run([str(prefix/'python.exe'),'-m','pip','install','-r',str(ROOT/'requirements_rl.txt')],cwd=home,check=True)
    print('Setup finished. Next open CHECK_SETUP.py and run it. GPU availability is verified there, not assumed.',flush=True)
if __name__=='__main__':
    try:main()
    except Exception as error:print('SETUP ERROR:',error,flush=True);raise SystemExit(1)
