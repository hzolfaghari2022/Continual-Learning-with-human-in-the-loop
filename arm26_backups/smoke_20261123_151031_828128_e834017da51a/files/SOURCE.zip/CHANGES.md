# Integrated reliability update

Fixes the reported PROGRESS.json write lock, PROGRESS.json monitor read lock, and GitHub backup.lock write-before-lock failure.

Author learning files remain pinned and unchanged. Check VERIFY_SOURCE.py. No change to SAC/PackNet losses, neural architecture, physical model, reward, force limit, case order or full interaction budget.

Backup failures no longer abort training: local checkpoints remain critical, uploads are best effort, pending state is reported, and the next scheduled checkpoint retries. RETRY_GITHUB.py handles pending final uploads. Never treat computation completion as proof of remote verification.

New convenience entry RUN_ALL.py and duplicate-launch safeguards. Tests simulate blocked telemetry, failed uploads, competing backup processes, original hashes and genuine worker failure propagation. Windows sharing failures are injected in local tests; this preparation host does not run OpenSim or TensorFlow CUDA.

Exact mid-method checkpoint resume remains unsupported; do not assume an actor checkpoint preserves optimizer, replay, environment or RNG state. Keep old runs.

Follow-up: SOURCE.zip and long-path copy/verification now exclude runtime .lock/.tmp files, ACTIVE_WORKER.json and repair backups. Added a regression test that rejects any attempted read of a live lock file. This fixes the Windows PermissionError observed before preflight in CWU_482392.

## Separate pilot profile
Default RUN_ALL now ends at pilot; RUN_ALL_FULL explicitly retains the long workflow. Pilot10ksteps/case,1kexploration,2kPackNetretraining,one stochastic periodic validation episode,three complete frozen validation references per case. Reserved tests remain unopened. No full-mode hyperparameters, upstream algorithms, physical durations or rewards changed. Added BUDGET.json and profile regression test. Pilot has no automatic promotion to full and no exact warm-start/resume claim.
