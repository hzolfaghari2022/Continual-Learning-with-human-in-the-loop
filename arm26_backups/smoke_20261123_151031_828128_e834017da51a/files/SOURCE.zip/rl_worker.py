"""Internal entry for the isolated TensorFlow environment."""
import os,sys,traceback
from pathlib import Path
os.environ['MKL_THREADING_LAYER']='SEQUENTIAL'
os.environ['MKL_NUM_THREADS']='1';os.environ['OPENBLAS_NUM_THREADS']='1'
DLLS=[]
if os.name=='nt':
    directory=Path(sys.executable).parent/'Library'/'bin'
    if directory.is_dir():DLLS.append(os.add_dll_directory(str(directory)))
from adapter.common import write
if __name__=='__main__':
    mode=sys.argv[1];suite=Path(sys.argv[2]).resolve();folder=Path(sys.argv[3]).resolve()
    try:
        if mode=='check':
            from adapter.preflight import check
            check(suite)
        else:
            from adapter.experiment import run_method
            run_method(suite,folder,sys.argv[4],mode)
    except BaseException as error:
        if isinstance(error,SystemExit) and error.code==0:raise
        traceback.print_exc();write(folder/'FAILED.json',dict(error=str(error),traceback=traceback.format_exc(),note='No successful method completion is claimed'))
        raise SystemExit(1)
