"""VS Code entry: environment if missing, real checks, smoke, then short pilot RL.
Keep the terminal open. Pilot budget is 80k interactions plus evaluation.
"""
from pathlib import Path
import os,subprocess,sys
ROOT=Path(__file__).resolve().parent

def main():
    if os.name!='nt':raise RuntimeError('This convenience launcher targets Windows; individual launchers remain available')
    python=Path.home()/'miniconda3/envs/arm26-cw/python.exe'
    if not python.is_file():
        subprocess.run([sys.executable,'-u',str(ROOT/'SETUP_RL_ENV.py')],check=True,cwd=ROOT)
    if not python.is_file():raise FileNotFoundError('RL environment was not created: '+str(python))
    print('SHORT PILOT:80,000 total training interactions plus validation. Full training will NOT start automatically.',flush=True)
    for name in ('CHECK_SETUP.py','RUN_SMOKE.py','RUN_PILOT.py'):
        print('\nRUNNING '+name,flush=True)
        subprocess.run([str(python),'-u','-X','utf8',str(ROOT/name)],check=True,cwd=ROOT)
    print('Pilot finished. Inspect REPORT.html. Later run RUN_ALL_FULL.py explicitly for the long experiment. It starts separate training, not an exact extension of pilot state.',flush=True)
if __name__=='__main__':
    try:main()
    except KeyboardInterrupt:print('Interrupted; partial outputs preserved. Interrupted methods restart on relaunch.',flush=True);raise SystemExit(130)
    except Exception as exc:print('RUN STOPPED: '+str(exc),flush=True);raise SystemExit(1)
