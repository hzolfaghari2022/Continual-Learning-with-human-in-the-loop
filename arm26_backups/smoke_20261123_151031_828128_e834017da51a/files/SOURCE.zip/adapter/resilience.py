"""Noncritical monitoring and backup errors must not stop learning."""
from pathlib import Path
import json
import time

def telemetry(path, default):
    try:
        value = json.loads(Path(path).read_text(encoding='utf-8-sig'))
        if not isinstance(value, dict): return default
        if any(key not in value for key in default): return default
        return value
    except (OSError, ValueError):
        return default

def best_effort_backup(suite, reason, final=False):
    from backup import backup_experiment
    from .common import write
    suite = Path(suite)
    try:
        result = backup_experiment(suite, None, reason=reason, final=final)
    except Exception as exc:
        print('GITHUB BACKUP DEFERRED; LOCAL WORK PRESERVED: ' + str(exc), flush=True)
        try:
            write(suite/'BACKUP_PENDING.json', dict(status='pending', reason=reason, error=str(exc), time=time.time(), final=final))
        except Exception as record_error:
            print('Could not write backup-pending marker: '+str(record_error), flush=True)
        return None
    pending = suite/'BACKUP_PENDING.json'
    if pending.exists():
        try: pending.unlink()
        except OSError: pass
    return result
