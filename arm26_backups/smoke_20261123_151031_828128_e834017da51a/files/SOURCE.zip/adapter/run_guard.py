"""One launcher per code folder, plus detection of a surviving child worker."""
import contextlib,json,os
from pathlib import Path
from .common import ROOT

@contextlib.contextmanager
def launcher_guard():
    path=ROOT/'LAUNCHER.lock'
    fd=os.open(path,os.O_RDWR|os.O_CREAT|getattr(os,'O_BINARY',0))
    stream=os.fdopen(fd,'r+b',buffering=0)
    locked=False
    try:
        try:
            if os.name=='nt':
                import msvcrt
                stream.seek(0);msvcrt.locking(stream.fileno(),msvcrt.LK_NBLCK,1)
            else:
                import fcntl
                fcntl.flock(stream.fileno(),fcntl.LOCK_EX|fcntl.LOCK_NB)
            locked=True
        except OSError as exc:
            raise RuntimeError('Another launcher is active in this code folder. Use its terminal; do not start a duplicate run.') from exc
        marker=ROOT/'ACTIVE_WORKER.json'
        if marker.exists():
            try:
                data=json.loads(marker.read_text(encoding='utf-8-sig'));pid=int(data['pid'])
                if os.name=='nt':
                    import ctypes
                    kernel=ctypes.windll.kernel32
                    kernel.OpenProcess.restype=ctypes.c_void_p
                    handle=kernel.OpenProcess(0x1000,False,pid)
                    if handle:
                        code=ctypes.c_ulong();ok=kernel.GetExitCodeProcess(ctypes.c_void_p(handle),ctypes.byref(code));kernel.CloseHandle(ctypes.c_void_p(handle))
                        if not ok:raise RuntimeError('Could not determine recorded worker state')
                        alive=code.value==259
                    else:
                        error=kernel.GetLastError()
                        if error not in (0,87):raise RuntimeError('Could not inspect recorded worker PID '+str(pid))
                        alive=False
                else:
                    try:os.kill(pid,0);alive=True
                    except ProcessLookupError:alive=False
                if alive:raise RuntimeError('Recorded worker PID '+str(pid)+' is still alive. Do not restart; inspect '+str(marker))
            except (ValueError,KeyError,OSError) as exc:
                raise RuntimeError('Cannot safely inspect ACTIVE_WORKER.json; preserve it and request help') from exc
            marker.unlink()
        yield
    finally:
        if locked:
            stream.seek(0)
            if os.name=='nt':msvcrt.locking(stream.fileno(),msvcrt.LK_UNLCK,1)
            else:fcntl.flock(stream.fileno(),fcntl.LOCK_UN)
        stream.close()
