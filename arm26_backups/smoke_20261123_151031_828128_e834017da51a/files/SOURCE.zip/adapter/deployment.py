"""Reload original actor and PackNet masks for later force inference.
Run in arm26-cw. Input is the28-feature ENCODED vector, not raw simulator values.
"""
from pathlib import Path
import numpy as np
from .binding import bind
from .common import read,verify_upstream

def load_policy(folder):
    import tensorflow as tf
    import gym
    bind();verify_upstream();tf.keras.backend.clear_session()
    from continualworld.utils.run_utils import get_sac_class
    from continualworld.sac.models import MlpActor
    from continualworld.utils.enums import BufferType
    folder=Path(folder);metadata=read(folder/'DEPLOYMENT.json');method=metadata['method']
    class Interface:
        num_envs=4
        action_space=gym.spaces.Box(-1.,1.,shape=(1,),dtype=np.float32)
        observation_space=gym.spaces.Box(-np.inf,np.inf,shape=(32,),dtype=np.float32)
    class Log:
        def store(self,*args,**kwargs):pass
    model=dict(hidden_sizes=[256]*4,activation=tf.nn.leaky_relu,use_layer_norm=True,num_heads=4,hide_task_id=True)
    kwargs=dict(env=Interface(),test_envs=[],logger=Log(),actor_cl=MlpActor,actor_kwargs=model.copy(),critic_kwargs=model.copy(),replay_size=16,batch_size=2,buffer_type=BufferType.FIFO)
    if method=='packnet':kwargs.update(regularize_critic=False,retrain_steps=0)
    elif method=='ewc':kwargs.update(regularize_critic=False,cl_reg_coef=10000.)
    agent=get_sac_class(None if method=='no_cl' else method)(**kwargs)
    agent.actor.load_weights(str(folder/metadata['actor_prefix']))
    if method=='packnet':
        with np.load(folder/'algorithm_state.npz',allow_pickle=False) as arrays:
            for i,(ref,owner) in enumerate(agent.owner.items()):
                owner.assign(arrays[f'owner_{i}']);agent.saved_variables[ref].assign(arrays[f'saved_{i}'])
            agent.freeze_biases_and_normalization.assign(arrays['freeze_biases_and_normalization']);agent.current_view.assign(arrays['current_view'])
    def predict_force(encoded_features,case_index):
        x=np.asarray(encoded_features,np.float32)
        if x.shape!=(28,) or not np.isfinite(x).all() or case_index not in range(4):raise ValueError('Expected finite28 encoded features and case index0..3')
        obs=np.concatenate([x,np.eye(4,dtype=np.float32)[case_index]])
        agent.on_test_start(case_index)
        try:action=float(agent.get_action_test(tf.constant(obs),tf.constant(True)).numpy()[0])
        finally:agent.on_test_end(case_index)
        return float(325*(np.clip(action,-1,1)+1))
    return predict_force
