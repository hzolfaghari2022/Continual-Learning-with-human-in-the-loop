"""Read scenario definitions only; never use PID labels for SAC training."""
from pathlib import Path
from .common import CASES,read,sha,ROOT,write

def build_catalog(folder,out):
    folder=Path(folder).expanduser().resolve();m=read(folder/'COLLECTION_COMPLETE.json');p=read(folder/'PROTOCOL.json')
    if sha(folder/'PROTOCOL.json')!=m['protocol_sha256']:raise ValueError('Dataset protocol checksum mismatch')
    if len(m['episodes'])!=600:raise ValueError('Expected completed600-episode source collection')
    original=p['source_hashes'];key=next(k for k in original if k.replace('\\','/')=='core/arm26_exosuit.osim')
    if sha(ROOT/'physics/core/arm26_exosuit.osim')!=original[key]:raise ValueError('Source OpenSim model differs')
    pools={case:{split:[] for split in ['train','validation','test']} for case in CASES};seen=set()
    for r in m['episodes']:
        relative=Path(r['folder'].replace('\\','/'));sub=(folder/relative).resolve()
        if not sub.is_relative_to(folder):raise ValueError('Unsafe source path')
        if sha(sub/'settings.json')!=r['hashes']['settings.json']:raise ValueError('Scenario checksum changed')
        c=read(sub/'settings.json')
        if c['episode_id'] in seen:raise ValueError('Duplicate scenario ID')
        seen.add(c['episode_id'])
        if c['episode_id']!=r['episode_id']:raise ValueError('Scenario identifier mismatch')
        if c['split']!=r['split'] or c['task_id']!=r['task']:raise ValueError('Scenario split mismatch')
        c.pop('muscle_strength_audit',None);c.pop('neural_checkpoint',None)
        pools[r['task']][r['split']].append(c)
    for case in CASES:
        for split,count in [('train',105),('validation',15),('test',30)]:
            if len(pools[case][split])!=count:raise ValueError('Unexpected case/split counts')
            pools[case][split].sort(key=lambda c:c['episode_id'])
    result=dict(source_folder=str(folder),source_manifest_sha256=sha(folder/'COLLECTION_COMPLETE.json'),pools=pools,note='Original600 configurations and splits reused; PID training arrays not read; SAC generates new transitions.')
    write(out/'SCENARIOS.json',result);return result
