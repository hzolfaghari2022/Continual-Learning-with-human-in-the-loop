"""Real GPU optimizer + original SAC/PackNet unit update + OpenSim RPC check."""
from pathlib import Path
import numpy as np
from .common import ROOT,CASES,write
from .envs import ArmEnv
from .experiment import configure_tensorflow
from .binding import bind

def check(suite):
    from .common import read
    suite=Path(suite);options=read(suite/'CONFIG.json');catalog=read(suite/'SCENARIOS.json')
    tf,details=configure_tensorflow();bind()
    from continualworld.sac.sac import SAC
    from continualworld.methods.packnet import PackNet_SAC
    from continualworld.sac.models import MlpActor
    from continualworld.utils.enums import BufferType
    env=ArmEnv(catalog,CASES[0],'train',options,suite/'preflight_physics',seed=options['seed'],max_steps=5)
    try:
        obs=env.reset();details['opensim_worker']=env.client.ask('ping');action=np.array([-.5],np.float32);next_obs,reward,done,info=env.step(action)
        if obs.shape!=(32,) or not np.isfinite(next_obs).all():raise RuntimeError('Invalid physical interface')
        if info.get('physical_failure'):raise RuntimeError('Preflight action caused physical failure: '+str(info))
        class NoLog:
            def store(self,*args,**kwargs):pass
        env.num_envs=4
        for cls in [SAC,PackNet_SAC]:
            tf.keras.backend.clear_session()
            kwargs=dict(env=env,test_envs=[],logger=NoLog(),seed=options['seed'],replay_size=16,batch_size=2,actor_cl=MlpActor,actor_kwargs=dict(hidden_sizes=[256]*4,activation=tf.nn.leaky_relu,use_layer_norm=True,num_heads=4,hide_task_id=True),critic_kwargs=dict(hidden_sizes=[256]*4,activation=tf.nn.leaky_relu,use_layer_norm=True,num_heads=4,hide_task_id=True),buffer_type=BufferType.FIFO)
            if cls is PackNet_SAC:kwargs.update(regularize_critic=False,retrain_steps=1)
            agent=cls(**kwargs)
            if 'GPU' not in agent.actor.trainable_variables[0].device:raise RuntimeError('Original SAC actor is not on GPU')
            for _ in range(2):agent.replay_buffer.store(obs,action,reward,next_obs,False)
            agent.learn_on_batch=agent.get_learn_on_batch(0)
            output=agent.learn_on_batch(tf.constant(0),agent.replay_buffer.sample_batch(2))
            for key,value in output.items():
                if not np.isfinite(np.asarray(value)).all():raise RuntimeError('Nonfinite original learner output '+key)
            if cls is PackNet_SAC:
                agent.on_task_end(0)
                protected={ref:ref.deref().numpy().copy() for ref in agent.owner}
                masks={ref:owner.numpy()==0 for ref,owner in agent.owner.items()}
                batch=agent.replay_buffer.sample_batch(2)
                changed=batch['obs'].numpy();changed[:,-4:]=[0,1,0,0];batch['obs']=tf.constant(changed)
                changed=batch['next_obs'].numpy();changed[:,-4:]=[0,1,0,0];batch['next_obs']=tf.constant(changed)
                agent.get_learn_on_batch(1)(tf.constant(1),batch)
                for ref in protected:np.testing.assert_array_equal(ref.deref().numpy()[masks[ref]],protected[ref][masks[ref]])
                agent.on_test_start(0);agent.get_action_test(tf.constant(obs),tf.constant(True));agent.on_test_end(0)
        details.update(opensim_reset_step_passed=True,original_sac_update_passed=True,original_packnet_update_and_protected_weights_passed=True,observation_dim=32,action_dim=1,note='Integration check only; discarded synthetic update models are not research results')
        write(suite/'PREFLIGHT_PASS.json',details)
    finally:env.close()
    return details
