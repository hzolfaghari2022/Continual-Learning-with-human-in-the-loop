"""OpenSim integration; learning implementations are imported unchanged from upstream/."""
