"""Declared experiment budgets. No upstream learning algorithm is modified."""
def profile(mode):
    if mode=='smoke':
        return dict(steps_per_case=100,log_every=100,episode_limit=10,replay_size=10000,batch_size=16,start_steps=20,update_after=20,update_every=10,retrain_steps=20,test_stochastic=1,frozen_split='validation',frozen_per_case=1)
    if mode=='pilot':
        return dict(steps_per_case=10000,log_every=10000,episode_limit=None,replay_size=1000000,batch_size=128,start_steps=1000,update_after=1000,update_every=50,retrain_steps=2000,test_stochastic=1,frozen_split='validation',frozen_per_case=3)
    if mode=='full':
        return dict(steps_per_case=1000000,log_every=20000,episode_limit=None,replay_size=1000000,batch_size=128,start_steps=10000,update_after=1000,update_every=50,retrain_steps=100000,test_stochastic=10,frozen_split='test',frozen_per_case=30)
    raise ValueError('Unknown experiment mode: '+str(mode))
