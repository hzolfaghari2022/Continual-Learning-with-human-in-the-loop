"""Replace ONLY the benchmark environment module, not its learning code.
The authors' models import two environment dimension constants. OpenSim exposes
28 physical features and1 force action rather than Meta-World's12 and4.
"""
import sys,types,importlib.machinery
from .common import ROOT,verify_upstream

def bind():
    verify_upstream();sys.path.insert(0,str(ROOT/'upstream'))
    if 'continualworld.sac.models' in sys.modules:
        existing=sys.modules.get('continualworld.envs')
        if getattr(existing,'ARM26_ENVIRONMENT_BINDING',False):return
        raise RuntimeError('Bind OpenSim before importing authors models')
    module=types.ModuleType('continualworld.envs');module.__spec__=importlib.machinery.ModuleSpec(module.__name__,loader=None)
    module.MW_OBS_LEN=28;module.MW_ACT_LEN=1;module.ARM26_ENVIRONMENT_BINDING=True
    # Environment factories are constructed explicitly by adapter/experiment.py.
    # No fake MuJoCo environment or monkey patch of any learning class is used.
    sys.modules['continualworld.envs']=module
