@echo off
setlocal
set "ARM26_PY=%USERPROFILE%\miniconda3\envs\lstm-py312\python.exe"
if not exist "%ARM26_PY%" (
 echo ERROR: lstm-py312 Python executable was not found.
 pause
 exit /b 1
)
cd /d "%USERPROFILE%"
"%ARM26_PY%" -X utf8 "%~dp0collect_data.py" --episodes 600 --workers 4 %*
pause
