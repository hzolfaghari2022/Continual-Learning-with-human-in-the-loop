"""A visible heartbeat plus durable phase progress; percentages are phase counts, not ETA."""
import contextlib,threading,time
from pathlib import Path
from atomic_io import atomic_json

class Progress:
    def __init__(self,total,stream,out=None):
        self.stream=stream;self.out=Path(out) if out else None;self.lock=threading.RLock();self.stop=threading.Event();self.thread=None
        self.stage('Preparing',total)
        if self.out:
            self.thread=threading.Thread(target=self._heartbeat,daemon=True);self.thread.start()
    def _save(self):
        if self.out:atomic_json(self.out/'PROGRESS.json',dict(stage=self.label,done=self.done,total=self.total,percent=round(100*self.done/self.total,1) if self.total else None))
    def stage(self,label,total=0,done=0):
        with self.lock:
            self.label=label;self.total=int(total);self.done=int(done);self.started=time.monotonic();self._save()
    def advance(self,n=1):
        with self.lock:
            self.done+=n
            if self.total and self.done>self.total:raise ValueError('Phase progress exceeds budget: '+self.label)
            self._save()
    def _heartbeat(self):
        while not self.stop.is_set():
            with self.lock:
                line=self.label
                if self.total:line+=f' | {self.done}/{self.total} | {100*self.done/self.total:.1f}%'
                else:line+=f' | {int(time.monotonic()-self.started)}s'
            print('\r'+line[:76].ljust(76),file=self.stream,end='',flush=True)
            self.stop.wait(2)
    @contextlib.contextmanager
    def waiting(self,label):
        with self.lock:old=(self.label,self.total,self.done)
        self.stage(label)
        try:yield
        finally:self.stage(*old)
    def close(self):
        self.stop.set()
        if self.thread:self.thread.join(timeout=3)
        with self.lock:
            line=self.label+(f' | {self.done}/{self.total} | {100*self.done/self.total:.1f}%' if self.total else '')
        print('\r'+line[:76].ljust(76),file=self.stream,flush=True)
