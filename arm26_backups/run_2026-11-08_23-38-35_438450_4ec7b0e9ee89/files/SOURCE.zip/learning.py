"""CUDA MLP: reproducible initial fit, recovery refinement, matched sequential/replay training."""
import io,math,time,shutil
from pathlib import Path
import numpy as np
import torch
from torch import nn
from complex_trajectories import FEATURES,SCALES
from atomic_io import atomic_bytes
from complex_engine import read,write,sha
from storage_guard import require_space

class DirectMLP(nn.Module):
    def __init__(self):
        super().__init__();self.layers=nn.Sequential(nn.Linear(28,64),nn.Tanh(),nn.Linear(64,64),nn.Tanh(),nn.Linear(64,1))
        nn.init.zeros_(self.layers[-1].weight);nn.init.constant_(self.layers[-1].bias,.15)
    def forward(self,x):return self.layers(x)

def device_for(request):
    if request!='cuda' or not torch.cuda.is_available():raise RuntimeError('CUDA is required; CPU NN training is not enabled.')
    return torch.device('cuda:0')
def save_torch(path,obj):
    b=io.BytesIO();torch.save(obj,b);atomic_bytes(path,b.getvalue())
def load_model(path,device):
    z=torch.load(path,map_location='cpu',weights_only=True)
    if z['architecture']!='direct_force_replay_v1':raise ValueError('Wrong checkpoint architecture')
    m=DirectMLP().to(device);m.load_state_dict(z['state_dict']);return m

def export_model(model,folder,metadata):
    folder=Path(folder);folder.mkdir(parents=True,exist_ok=True)
    state={k:v.detach().cpu().clone() for k,v in model.state_dict().items()}
    save_torch(folder/'policy.pt',dict(architecture='direct_force_replay_v1',state_dict=state));arrays={}
    for i,l in enumerate(x for x in model.layers if isinstance(x,nn.Linear)):
        arrays['W'+str(i)]=l.weight.detach().cpu().numpy();arrays['b'+str(i)]=l.bias.detach().cpu().numpy()
    b=io.BytesIO();np.savez_compressed(b,**arrays);atomic_bytes(folder/'policy_inference.npz',b.getvalue())
    write(folder/'policy_inference.json',dict(encoding='direct_force_replay_v1',features=FEATURES,scales=SCALES.tolist(),force_cap_N=650,parameter_count=sum(p.numel() for p in model.parameters()),topology='28 -> 64 tanh -> 64 tanh -> 1 linear normalized cable force',metadata=metadata))
    from policy_numpy import NumpyPolicy
    x=np.random.default_rng(291).normal(0,.3,(73,28)).astype(np.float32)
    with torch.no_grad():expected=model(torch.from_numpy(x).to(next(model.parameters()).device)).cpu().numpy()[:,0]
    if not np.allclose(expected,NumpyPolicy(folder/'policy_inference.npz').normalized(x),rtol=3e-5,atol=3e-6):raise ValueError('Torch/NumPy export mismatch')

def evaluate(model,dataset,device):
    x,y=dataset;total=clipped=0.;model.eval()
    with torch.no_grad():
        for i in range(0,len(x),8192):
            xx=x[i:i+8192];yy=y[i:i+8192]
            xx=xx.to(device) if torch.is_tensor(xx) else torch.from_numpy(xx).to(device)
            yy=yy.to(device) if torch.is_tensor(yy) else torch.from_numpy(yy).to(device)
            p=model(xx);total+=float((p-yy).square().sum());clipped+=float((p.clamp(0,1)-yy).square().sum())
    return dict(raw_rmse_N=650*math.sqrt(total/len(x)),rmse_N=650*math.sqrt(clipped/len(x)),samples=len(x))

def response_penalty(model,x):
    x=x[:128];eps=.05;slopes=[]
    for col,err,scale in [(0,2,.02),(1,3,.1)]:
        up=x.clone();down=x.clone();up[:,err]+=eps;up[:,col]-=eps*scale;down[:,err]-=eps;down[:,col]+=eps*scale
        slopes.append((model(up)-model(down))/(2*eps))
    return sum(torch.relu(.02-s).square().mean() for s in slopes)/2

def fit(folder,train,validation,initial,memory,args,stage):
    folder=Path(folder);folder.mkdir(parents=True,exist_ok=True);device=device_for(args.device)
    repair=bool(getattr(args,'repair_mode',False));weighted=bool(getattr(args,'weighted_mode',False))
    epochs=args.epochs_initial if initial is None else args.epochs_adapt
    weights=getattr(args,'current_weights',np.ones(len(train[0]),np.float32)) if weighted else np.ones(len(train[0]),np.float32)
    identity=dict(stage=stage,seed=args.seed,epochs=epochs,lr=args.lr,batch=args.batch_size,replay_weight=args.replay_weight if memory else 0.,anneal=args.anneal,memory_hashes=[sha(p) for p in memory],parent_sha256=sha(initial) if initial else None,protocol_sha256=sha(args.out/'PROTOCOL.json'),collection_sha256=sha(args.out/'COLLECTION_COMPLETE.json'),weighted=weighted,repair=repair,weights_sha256=__import__('hashlib').sha256(weights.tobytes()).hexdigest())
    label=('Initial recovery' if repair else 'Initial NN' if initial is None else folder.parent.name+' '+folder.name.removeprefix('after_'))
    args.progress.stage(label+' epochs',epochs)
    done=folder/'COMPLETE.json'
    if done.exists():
        old=read(done)
        if old['identity']!=identity or any(sha(folder/n)!=h for n,h in old['hashes'].items()):raise ValueError('Completed training changed: '+str(folder))
        args.progress.advance(old.get('actual_epochs',epochs));return folder/'policy.pt'
    torch.manual_seed(args.seed+stage*1009);np.random.seed(args.seed+stage*1009);torch.cuda.manual_seed_all(args.seed+stage*1009)
    torch.use_deterministic_algorithms(True);torch.set_num_threads(2)
    model=load_model(initial,device) if initial else DirectMLP().to(device);opt=torch.optim.Adam(model.parameters(),lr=args.lr)
    order_rng=torch.Generator().manual_seed(8801 if repair else args.seed+stage*109+17)
    replay_rng=torch.Generator().manual_seed(args.seed+stage*109+41)
    tx=torch.from_numpy(train[0]);ty=torch.from_numpy(train[1]);tw=torch.from_numpy(weights);resident=False;validation_cache=validation
    need=tx.numel()*tx.element_size()+ty.numel()*ty.element_size()+tw.numel()*tw.element_size()+sum(x.nbytes+y.nbytes for x,y in validation.values())
    free,_=torch.cuda.mem_get_info(device)
    if need<.35*free:
        tx=tx.to(device);ty=ty.to(device);tw=tw.to(device);resident=True
        validation_cache={t:(torch.from_numpy(x).to(device),torch.from_numpy(y).to(device)) for t,(x,y) in validation.items()}
    mx=my=mw=None
    if memory:
        xs=[];ys=[];ws=[]
        for path in memory:
            with np.load(path,allow_pickle=False) as z:xs.append(z['X']);ys.append(z['y']);ws.append(z['weights'])
        mx=torch.from_numpy(np.concatenate(xs)).to(device);my=torch.from_numpy(np.concatenate(ys)).to(device);mw=torch.from_numpy(np.concatenate(ws)).to(device)
    history=[];start_epoch=1;statefile=folder/'RESUME.pt'
    if statefile.exists():
        z=torch.load(statefile,map_location='cpu',weights_only=True)
        if z['identity']!=identity:raise ValueError('Partial training settings changed; use the same command or a new output')
        model.load_state_dict(z['model']);opt.load_state_dict(z['optimizer']);order_rng.set_state(z['order_rng']);replay_rng.set_state(z['replay_rng']);history=z['history'];start_epoch=z['epoch']+1
    args.progress.advance(start_epoch-1);started=time.monotonic();last_candidate=None;stop=False
    milestones=sorted(set([min(50,epochs),min(100,epochs),epochs]))
    def metadata(epoch,metrics):
        return dict(identity=identity,actual_epochs=epoch,checkpoint_rule='First recovery milestone passing ALL initial validation references' if repair else 'FINAL fixed-budget epoch in BOTH branches',validation=metrics,device=str(device),cuda_data_resident=resident,current_training_rows=len(tx),optimizer_updates=epoch*math.ceil(len(tx)/args.batch_size),maximum_replay_rows_per_update=0 if mx is None else min(512,len(mx)),runtime_seconds_this_invocation=time.monotonic()-started,loss='weighted force MSE + 0.1 corrective-response penalty' if weighted else 'ordinary force MSE')
    def review(epoch,metrics):
        nonlocal last_candidate
        last_candidate=args.out/'models'/'repair_candidates'/('A_90_epoch_'+str(epoch))
        if not (last_candidate/'policy.pt').exists():export_model(model,last_candidate,metadata(epoch,metrics))
        return args.repair_review(last_candidate/'policy.pt',epoch)
    if repair and start_epoch>1 and start_epoch-1 in milestones:
        stop=review(start_epoch-1,{t:evaluate(model,d,device) for t,d in validation_cache.items()})
    for epoch in range(start_epoch,epochs+1):
        if stop:break
        args.progress.stage(label+' epochs',epochs,epoch-1)
        if epoch==start_epoch or epoch%10==0:require_space(folder)
        if args.anneal:
            rate=args.lr*(.05+.95*.5*(1+math.cos(math.pi*(epoch-1)/max(1,epochs-1))))
            for group in opt.param_groups:group['lr']=rate
        model.train();order=torch.randperm(len(tx),generator=order_rng);sse=weighted_sum=pen_sum=rsse=0.;seen=0
        for offset in range(0,len(order),args.batch_size):
            ids=order[offset:offset+args.batch_size].to(tx.device);x=tx[ids].to(device);y=ty[ids].to(device);w=tw[ids].to(device)
            opt.zero_grad(set_to_none=True);errors=(model(x)-y).square().ravel();base=(errors*w).sum()/w.sum() if weighted else errors.mean()
            correction=response_penalty(model,x) if weighted else base*0.;replay_loss=base*0.
            if mx is not None:
                ri=torch.randint(len(mx),(min(512,len(mx)),),generator=replay_rng).to(device);e=(model(mx[ri])-my[ri]).square().ravel();replay_loss=(e*mw[ri]).sum()/mw[ri].sum()
                if weighted:replay_loss=replay_loss+.1*response_penalty(model,mx[ri])
            objective=base+.1*correction+args.replay_weight*replay_loss
            if not torch.isfinite(objective):raise FloatingPointError('Nonfinite training loss')
            objective.backward();torch.nn.utils.clip_grad_norm_(model.parameters(),5.);opt.step()
            sse+=float(errors.detach().sum());weighted_sum+=float(base.detach())*len(ids);pen_sum+=float(correction.detach())*len(ids);rsse+=float(replay_loss.detach())*len(ids);seen+=len(ids)
        metrics={t:evaluate(model,d,device) for t,d in validation_cache.items()}
        history.append(dict(epoch=epoch,current_train_rmse_N=650*math.sqrt(sse/seen),weighted_train_loss=weighted_sum/seen,response_penalty=pen_sum/seen,replay_loss_normalized=rsse/seen,validation=metrics))
        save_torch(statefile,dict(identity=identity,epoch=epoch,model={k:v.detach().cpu() for k,v in model.state_dict().items()},optimizer=opt.state_dict(),order_rng=order_rng.get_state(),replay_rng=replay_rng.get_state(),history=history));write(folder/'HISTORY.json',history)
        args.progress.advance(1)
        print(f'Epoch {epoch}/{epochs} | train {history[-1]["current_train_rmse_N"]:.3f} N | '+str(metrics),flush=True)
        if repair and epoch in milestones:stop=review(epoch,metrics)
        if epoch%getattr(args,'github_epochs',50)==0:
            callback=getattr(args,'checkpoint_backup',None)
            if callback is not None:callback('training '+label+' epoch '+str(epoch))
    actual=len(history)
    if not actual:raise ValueError('No training history')
    if repair and last_candidate is not None:
        for name in ['policy.pt','policy_inference.npz','policy_inference.json']:atomic_bytes(folder/name,(last_candidate/name).read_bytes())
    else:export_model(model,folder,metadata(actual,{t:evaluate(model,d,device) for t,d in validation_cache.items()}))
    write(done,dict(identity=identity,actual_epochs=actual,hashes={n:sha(folder/n) for n in ['policy.pt','policy_inference.npz','policy_inference.json','HISTORY.json']}))
    callback=getattr(args,'checkpoint_backup',None)
    if callback is not None:callback('training '+label+' complete')
    return folder/'policy.pt'

def make_memory(path,dataset,groups,seed,limit=1024,weights=None):
    """Training-only bounded memory, preserving startup states plus episode diversity."""
    path=Path(path);x,y=dataset;weights=np.ones(len(x),np.float32) if weights is None else weights;rng=np.random.default_rng(seed);labels=sorted(set(groups.tolist()));selected=[];priority_pools=[];all_ids=[]
    for g in labels:
        ids=np.flatnonzero(groups==g);all_ids.append(ids)
        positions=[0,10,20,50,100,200] if g.endswith('/trajectory') else [0,1,2,3]
        priority_pools.append([int(ids[i]) for i in positions if i<len(ids)])
    # Reserve about half the fixed memory for startup, allocating round-robin.
    # Remaining slots cover the full time span; no later-sorted episode is starved.
    priority_limit=min(limit,max(min(len(labels),limit),limit//2))
    while len(selected)<priority_limit:
        changed=False
        for pool in priority_pools:
            if pool and len(selected)<priority_limit:selected.append(pool.pop(0));changed=True
        if not changed:break
    pools=[rng.permutation(np.setdiff1d(ids,selected)).tolist() for ids in all_ids]
    while len(selected)<min(limit,len(x)):
        for pool in pools:
            if pool and len(selected)<limit:selected.append(pool.pop())
        if not any(pools):break
    indices=np.array(sorted(selected),dtype=np.int64)
    if path.exists():
        with np.load(path,allow_pickle=False) as z:
            if not np.array_equal(z['indices'],indices) or not np.array_equal(z['X'],x[indices]) or not np.array_equal(z['y'],y[indices]) or not np.array_equal(z['weights'],weights[indices]):raise ValueError('Replay memory changed')
    else:
        b=io.BytesIO();np.savez_compressed(b,X=x[indices],y=y[indices],weights=weights[indices],indices=indices,episode_id=groups[indices]);atomic_bytes(path,b.getvalue())
    write(path.with_suffix('.json'),dict(rows=len(indices),feature_target_weight_bytes=int(x[indices].nbytes+y[indices].nbytes+weights[indices].nbytes),source='TRAIN ONLY; round-robin startup priority, then time-span diversity across episode/query groups',total_groups=len(labels),covered_groups=len(set(groups[indices].tolist())),startup_priority_slots=priority_limit,stores_old_parameters=False))
    return path
