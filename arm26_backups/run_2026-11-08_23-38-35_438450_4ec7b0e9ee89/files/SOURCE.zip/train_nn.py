from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parent
sys.path[:0]=[str(ROOT),str(ROOT/"core")]
import runtime_setup
from flow import main

if __name__=="__main__":
    main("compare")
