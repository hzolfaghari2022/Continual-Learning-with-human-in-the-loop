# Required verified GitHub backup

Default repository:
https://github.com/hzolfaghari2022/Continual-Learning-with-human-in-the-loop.git

Automatic backups remain enabled in both packages. The helper creates a dedicated
local repository and per-run remote branch with git init; it NEVER clones the
repository's default-branch history. Only the current run branch is fetched when
recovering an existing cache. Push is verified against the remote commit and
committed manifest. No force push, remote history rewrite, user-file deletion,
embedded password, or embedded token is used.

Backups include source/launchers, immutable completed episode data, model and
optimizer checkpoints, logs, validation/test results, and reports. They run at
initialization, every10 completed episodes, every50 epochs, after every training
stage/validation group, and after final reports. Failed verification stops the
workflow with local work preserved. GITHUB_STATUS.json states verified/failed,
commit URL, reason, and whether the snapshot is final.

Files are stored as content-addressed <=40MiB chunks with LATEST_MANIFEST.json.
The supplied backup.py can restore a locally checked-out backup folder using
--restore and --destination; it checks chunk/file hashes and does not overwrite
different files. The incremental local cache is separate from each dated output:
the code package github_cache/ directory (unless ARM26_VERIFIED_BACKUP_CACHE is configured). It also consumes disk space. Never delete
unverified work or assume that a model-result backup includes an external dataset;
the collector backs up its own full dataset.

If an upload fails, repair network/Git credentials, then run the SAME package's
Python launcher with --backup-only --resume-latest. This retries upload without
OpenSim or training. To continue the interrupted computation, run the same
launcher with --resume-latest. The code and run options must match the saved source.
Explicit --no-github disables uploads only when deliberately requested.

Version2 also verifies Git-staged payload bytes and publishes run folders on main.
files/ exposes original names; objects/ and the manifest remain the full archive.
Legacy LF-to-CRLF repair is accepted only when SHA256 exactly matches the original.
