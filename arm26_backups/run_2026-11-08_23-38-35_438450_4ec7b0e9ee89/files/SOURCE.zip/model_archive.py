"""Save a verified index and convenient archive of reusable deployment checkpoints."""
from pathlib import Path
import zipfile
from complex_engine import read,write,sha

def archive_models(out,source):
    out=Path(out);source=Path(source);policies=[]
    for p in sorted((out/'models').rglob('policy.pt')):
        folder=p.parent
        if all((folder/n).exists() for n in ['policy_inference.npz','policy_inference.json']):
            policies.append(dict(folder=folder.relative_to(out).as_posix(),hashes={n:sha(folder/n) for n in ['policy.pt','policy_inference.npz','policy_inference.json']},resume_file=(folder/'RESUME.pt').relative_to(out).as_posix() if (folder/'RESUME.pt').exists() else None))
    selection=read(out/'SELECTION.json') if (out/'SELECTION.json').exists() else {};named={}
    for name,rel in [('shared_initial_A','models/shared/after_A_90/policy.pt'),('ordinary_after_D',selection.get('baseline_checkpoint')) ,('CL_after_D',(selection.get('selected') or {}).get('checkpoint'))]:
        if rel and (out/rel).exists():named[name]=rel
    write(out/'MODEL_INDEX.json',dict(state=read(out/'STATE.json') if (out/'STATE.json').exists() else {},deployment_models=named,all_saved_checkpoints=policies,note='Full model, inference exports and optimizer resume checkpoints stay in models/. Do not infer scientific success from checkpoint existence.'))
    with zipfile.ZipFile(out/'SAVED_MODELS.zip','w',zipfile.ZIP_DEFLATED) as z:
        z.write(out/'MODEL_INDEX.json','MODEL_INDEX.json')
        for name,rel in named.items():
            folder=(out/rel).parent
            for n in ['policy.pt','policy_inference.npz','policy_inference.json']:z.write(folder/n,name+'/'+n)
        for n in ['policy_numpy.py','complex_trajectories.py']:z.write(source/'core'/n,'inference/'+n)
        z.writestr('README.txt','Named checkpoints are frozen copies from this run. All other training checkpoints remain under models/.\nPyTorch policy.pt contains architecture and state_dict; learning.py in SOURCE.zip defines DirectMLP.\nNumPy deployment: add the inference/ folder to sys.path, import NumpyPolicy from policy_numpy, load a named policy_inference.npz, then pass a raw 28-feature vector in the order listed in policy_inference.json.\nNumpyPolicy performs the recorded feature encoding and returns requested force in N. Apply the same 0..650 N clipping and simulator state/control timing used by core/complex_engine.py.\nThese simulation inputs include muscle states and known task parameters; physical sensor deployment is not established.\n')
    context=out/'CONTEXT.zip'
    if context.exists():
        with zipfile.ZipFile(context,'a',zipfile.ZIP_DEFLATED) as z:
            existing=set(z.namelist())
            for n in ['MODEL_INDEX.json','SAVED_MODELS.zip']:
                if n not in existing:z.write(out/n,n)
