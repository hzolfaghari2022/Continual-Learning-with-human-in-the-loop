"""Four logical report figures total: architecture/cost, learning, tracking, aggregate outcomes."""
import html
from pathlib import Path
import numpy as np
from complex_engine import read

COST_HTML='''<div style="padding:16px;background:#f3f5f7;font-size:19px;line-height:1.8">
ℓ<sub>w</sub>(D) = Σ<sub>i∈D</sub> w<sub>i</sub>[f<sub>θ</sub>(x<sub>i</sub>) − F<sub>i</sub>/650]² / Σ<sub>i∈D</sub>w<sub>i</sub><br>
L<sub>ordinary</sub> = ℓ<sub>w</sub>(D<sub>t</sub>) + 0.1 R(D<sub>t</sub>)<br>
L<sub>CL</sub> = L<sub>ordinary</sub> + β [ℓ<sub>w</sub>(M<sub>A</sub>) + 0.1 R(M<sub>A</sub>)]<br>
R(D) = (1/2K) Σ<sub>i=1…K</sub> Σ<sub>k∈{q,v}</sub> max(0, 0.02 − d̂<sub>ik</sub>)²<br>
d̂<sub>ik</sub> = [f<sub>θ</sub>(x<sub>i</sub> + εv<sub>k</sub>) − f<sub>θ</sub>(x<sub>i</sub> − εv<sub>k</sub>)]/(2ε)
</div><p>D<sub>t</sub>: current-task minibatch. M<sub>A</sub>: at most512 samples per update from the fixed1024-example Task A training buffer. f<sub>θ</sub> predicts normalized force; F is the teacher cable-force label in N. β∈{1,4,16} is selected using validation only. K≤128 and ε=0.05. The encoded directions v<sub>q</sub>,v<sub>v</sub> slightly decrease actual angle/velocity at fixed reference. The same corrective-response regularizer is used in both branches; only replay uses previous-task data. It encourages corrective feedback but is not a stability proof.</p>'''

def briefing(groups,target,phase):
    g={r['label']:r for r in groups if r['task']==target};items=[]
    items.append('Research question: after learning A, does training B→C→D degrade frozen return-to-A tracking, and does a small replay memory reduce that degradation?')
    for label,title in [('initial_target','Shared A model before later tasks'),('noCL_final','Ordinary NN after B/C/D'),('CL_final','Selected replay CL after B/C/D')]:
        r=g.get(label)
        if not r:items.append(title+': not evaluated in this report phase.');continue
        metric='no completed-trial RMSE' if r['rmse_deg'] is None else f"completed-trial mean motion RMSE {r['rmse_deg']:.4f} deg"
        items.append(f"{title}: {metric}; {r['failed']}/{r['attempts']} physical failures; {r['high_accuracy']}/{r['attempts']} references meet both accuracy criteria.")
    items.append('The primary retention endpoint is A. Final D tests disclose new-task learning separately. Good retention alone does not establish good adaptation.')
    items.append('This report phase is '+phase+'. Validation-guided selection and one random seed do not establish statistical significance or universal necessity of CL. More data may change the outcome; all trials remain in the tables/CSV.')
    return items

def generate_figures(out,protocol,rows,groups,phase):
    import matplotlib.pyplot as plt
    from matplotlib.patches import FancyBboxPatch
    out=Path(out);target=protocol['return_task']
    fig=plt.figure(figsize=(13,8));ax=fig.add_axes([.03,.57,.94,.36]);ax.set(xlim=(0,1),ylim=(0,1));ax.axis('off')
    ax.text(.5,1.03,'Direct-force neural network: 6,081 trainable parameters',ha='center',fontsize=19,weight='bold')
    boxes=[(.02,'28 encoded\ninputs','State, reference,\nmuscles and task'),(.27,'64 tanh','1,856 parameters'),(.52,'64 tanh','4,160 parameters'),(.77,'1 linear output','65 parameters\nCable force / 650')]
    for x,title,detail in boxes:
        ax.add_patch(FancyBboxPatch((x,.35),.19,.4,boxstyle='round,pad=.015',facecolor='#e7eff6',edgecolor='#225777',linewidth=1.4))
        ax.text(x+.095,.61,title,ha='center',va='center',fontsize=17);ax.text(x+.095,.44,detail,ha='center',va='center',fontsize=11)
    for x in [.22,.47,.72]:ax.annotate('',xy=(x+.035,.55),xytext=(x,.55),arrowprops=dict(arrowstyle='->',linewidth=1.7))
    ax.text(.5,.14,'Requested tension is clipped to 0–650 N. The NN supplies learned feedback; the PID teacher labels training data.',ha='center',fontsize=12)
    cost=fig.add_axes([.05,.05,.9,.49]);cost.axis('off')
    equations=[r'$\ell_w(D)=\frac{\sum_{i\in D} w_i\,[f_\theta(x_i)-F_i/650]^2}{\sum_{i\in D}w_i}$',r'$L_{\rm ordinary}=\ell_w(D_t)+0.1R(D_t)$',r'$L_{\rm CL}=L_{\rm ordinary}+\beta[\ell_w(\mathcal{M}_A)+0.1R(\mathcal{M}_A)]$',r'$R(D)=\frac{1}{2K}\sum_{i=1}^{K}\sum_{k\in\{q,v\}}\max(0,\,0.02-\widehat d_{ik})^2$']
    for y,text in zip([.89,.64,.40,.15],equations):cost.text(.03,y,text,fontsize=19,va='center')
    cost.text(.98,.90,'Current-task data: $D_t$\nOld A examples: $\\mathcal{M}_A$\nFixed memory: 1,024 examples\nReplay: at most512/update\n$\\beta$: 1,4,16 (validation)\n$K\\leq128$, $\\epsilon=0.05$',ha='right',va='top',fontsize=11)
    for ext in ['png','pdf']:fig.savefig(out/('architecture_cost.'+ext),dpi=165)
    plt.close(fig)
    fig,axs=plt.subplots(2,2,figsize=(13,9));g={r['label']:r for r in groups if r['task']==target};rng=np.random.default_rng(291)
    def boxes(ax,labels,title,task):
        for i,(label,caption,color) in enumerate(labels,1):
            rr=[r for r in rows if r['task']==task and r['label']==label];values=[r['rmse_deg'] for r in rr if r['completed'] and r['rmse_deg'] is not None]
            if values:
                bp=ax.boxplot([values],positions=[i],widths=.45,patch_artist=True,showfliers=False)
                bp['boxes'][0].set_facecolor(color);bp['boxes'][0].set_alpha(.35);ax.scatter(i+rng.uniform(-.13,.13,len(values)),values,s=15,alpha=.6,color=color)
            failures=sum(not r['completed'] for r in rr)
            ax.text(i,.97,f'{failures}/{len(rr)} failed',ha='center',va='top',transform=ax.get_xaxis_transform(),fontsize=10)
        ax.set_xticks(range(1,len(labels)+1),[x[1] for x in labels]);ax.set(xlim=(.5,len(labels)+.5),ylabel='Motion RMSE (deg)',title=title);ax.grid(axis='y',alpha=.2)
        if not any(r['task']==task and r['label'] in {z[0] for z in labels} for r in rows):ax.text(.5,.5,'Not evaluated in this report phase',transform=ax.transAxes,ha='center')
    boxes(axs[0,0],[('initial_target','Shared A','#777777'),('noCL_final','Ordinary NN','#D55E00'),('CL_final','Replay CL','#0072B2')],'A: every completed reference; failures disclosed',target)
    labels=['initial_target','noCL_final','CL_final'];maps={label:{r['episode_id']:r for r in rows if r['task']==target and r['label']==label} for label in labels}
    pairs=[(r['rmse_deg'],maps['CL_final'][eid]['rmse_deg']) for eid,r in maps['noCL_final'].items() if r['completed'] and eid in maps['CL_final'] and maps['CL_final'][eid]['completed']]
    ax=axs[0,1]
    if pairs:
        xx,yy=np.array(pairs).T;limit=max(float(np.max(xx)),float(np.max(yy)),1e-3)*1.1;ax.scatter(xx,yy,s=26,alpha=.75,color='#0072B2');ax.plot([0,limit],[0,limit],'k--',lw=1);ax.set(xlim=(0,limit),ylim=(0,limit))
    else:ax.text(.5,.5,'No paired completed trials',ha='center',transform=ax.transAxes)
    ax.set(xlabel='Ordinary NN motion RMSE (deg)',ylabel='Replay CL motion RMSE (deg)',title=f'A: paired completed trials (n={len(pairs)})');ax.grid(alpha=.2)
    ax=axs[1,0];ids=sorted(set().union(*[set(d) for d in maps.values()]))
    for label,caption,color in [('noCL_final','Ordinary minus shared A','#D55E00'),('CL_final','Replay minus shared A','#0072B2')]:
        x=[];y=[]
        for i,eid in enumerate(ids,1):
            first=maps['initial_target'].get(eid);last=maps[label].get(eid)
            if first and last and first['completed'] and last['completed']:x.append(i);y.append(last['rmse_deg']-first['rmse_deg'])
        if x:ax.scatter(x,y,s=20,label=caption,color=color,alpha=.75)
    ax.axhline(0,color='k',ls='--',lw=1);ax.set(xlabel='Reference index (sorted ID)',ylabel='Change in motion RMSE (deg)',title='A: paired forgetting; positive means worse')
    if ax.collections:ax.legend(fontsize=9)
    ax.grid(alpha=.2)
    boxes(axs[1,1],[('noCL_new_task','Ordinary NN','#D55E00'),('CL_new_task','Replay CL','#0072B2')],'D: new-task learning diagnostic',protocol['order'][-1])
    fig.suptitle(phase+' — all trials retained; failed trials have no invented final RMSE',fontsize=16);fig.tight_layout()
    for ext in ['png','pdf']:fig.savefig(out/('comparison_summary.'+ext),dpi=165)
    plt.close(fig)
    return ['architecture_cost','comparison_summary']
