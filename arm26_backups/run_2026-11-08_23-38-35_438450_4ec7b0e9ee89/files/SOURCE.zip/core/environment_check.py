"""Check real model initialization and optimizer/export before expensive work."""
import runtime_setup
import sys,tempfile,argparse
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import opensim as o
p=argparse.ArgumentParser();p.add_argument('--device',default='cuda');p.add_argument('--physics-only',action='store_true');p.add_argument('--report',type=Path);a=p.parse_args()
from atomic_io import atomic_json
o.Logger.setLevelString('Error');root=Path(__file__).resolve().parent
o.ModelVisualizer.addDirToGeometrySearchPaths(str(root/'Geometry'))
m=o.Model(str(root/'arm26_exosuit.osim'));m.setUseVisualizer(False);m.initSystem()
if a.physics_only:
    if a.report:atomic_json(a.report,dict(python=sys.version.split()[0],opensim=o.GetVersion(),physics='CPU',viewer=False))
    print('OpenSim model initialization passed. Physics engine: CPU; no viewer and no CUDA dynamics.')
    raise SystemExit(0)
import torch
from learning import DirectMLP,device_for,export_model,load_model
device=device_for(a.device);policy=DirectMLP().to(device);opt=torch.optim.Adam(policy.parameters(),lr=.001)
if a.report:atomic_json(a.report,dict(python=sys.version.split()[0],opensim=o.GetVersion(),pytorch=torch.__version__,cuda_runtime=torch.version.cuda,device=str(device),gpu_name=torch.cuda.get_device_name(device) if device.type=='cuda' else None,physics='CPU',viewer=False))
x=torch.linspace(-.2,.2,8*28,device=device).reshape(8,28)
loss=(policy(x)-.2).square().mean()+(policy(-x)-.3).square().mean();loss.backward()
if not all(p.grad is not None and torch.isfinite(p.grad).all() for p in policy.parameters()):raise FloatingPointError('Invalid gradients')
opt.step()
with tempfile.TemporaryDirectory(prefix='return_task_check_') as td:
    export_model(policy,Path(td),dict(environment_smoke_check=True));restored=load_model(Path(td)/'policy.pt',device)
    with torch.no_grad():
        if not torch.equal(policy(x),restored(x)):raise ValueError('Torch save/load mismatch')
print('Environment, model, optimizer and Torch/NumPy parity checks passed. Device:',device)
