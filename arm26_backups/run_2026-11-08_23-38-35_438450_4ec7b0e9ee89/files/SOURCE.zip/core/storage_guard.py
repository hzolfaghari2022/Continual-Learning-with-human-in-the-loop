"""Stop before exports when disk reserve is exhausted; never delete user files."""
import os,shutil,math
from pathlib import Path
def require_space(path):
 reserve=float(os.environ.get('ARM26_MIN_FREE_GB','5'))
 if not math.isfinite(reserve) or reserve<0:raise ValueError('Invalid disk reserve.')
 path=Path(path)
 while not path.exists():path=path.parent
 free=shutil.disk_usage(path).free/2**30
 if free<reserve:raise OSError(f'Low disk space: {free:.2f} GiB free, reserve {reserve:g}. Completed files preserved. Free/move unrelated files and resume the SAME run.')
 return free
