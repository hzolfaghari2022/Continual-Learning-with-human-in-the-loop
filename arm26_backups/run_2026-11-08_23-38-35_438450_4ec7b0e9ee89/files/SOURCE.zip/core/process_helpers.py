"""Stream subprocess output to the terminal and a durable stage log."""
import subprocess,time,os
from pathlib import Path

def run_logged(command, log, allowed=(0,), timeout=None, heartbeat=None):
    log=Path(log);log.parent.mkdir(parents=True,exist_ok=True)
    print('RUN:',subprocess.list2cmdline([str(v) for v in command]),flush=True)
    with log.open('w',encoding='utf-8') as stream:
        env=os.environ.copy();env['PYTHONUTF8']='1';env['PYTHONUNBUFFERED']='1'
        proc=subprocess.Popen([str(v) for v in command],stdout=stream,stderr=subprocess.STDOUT,env=env)
        offset=0;start=time.monotonic()
        try:
            while proc.poll() is None:
                if timeout is not None and time.monotonic()-start>timeout:raise subprocess.TimeoutExpired(proc.args,timeout)
                if heartbeat is not None:heartbeat()
                time.sleep(.2)
                with log.open(encoding='utf-8',errors='replace') as reader:
                    reader.seek(offset);chunk=reader.read();offset=reader.tell()
                if chunk:print(chunk,end='',flush=True)
            with log.open(encoding='utf-8',errors='replace') as reader:
                reader.seek(offset);chunk=reader.read()
            if chunk:print(chunk,end='',flush=True)
        except (KeyboardInterrupt,subprocess.TimeoutExpired):
            proc.terminate()
            try:proc.wait(timeout=10)
            except subprocess.TimeoutExpired:proc.kill();proc.wait()
            raise
    if proc.returncode not in allowed:
        with log.open('rb') as f:
            f.seek(0,2);f.seek(max(0,f.tell()-12000));tail=f.read().decode('utf-8',errors='replace')
        raise RuntimeError('Worker exit '+str(proc.returncode)+'. Log: '+str(log)+'\n'+tail)
    return proc.returncode
