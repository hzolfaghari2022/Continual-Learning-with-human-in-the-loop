"""Direct force MLP. No separate nominal head, gains, PID or EWC at deployment."""
from pathlib import Path
import json
import numpy as np
from complex_trajectories import FEATURES, SCALES, encode

class NumpyPolicy:
    def __init__(self,path):
        path=Path(path)
        self.meta=json.loads(path.with_suffix('.json').read_text(encoding='utf-8'))
        if self.meta['encoding']!='direct_force_replay_v1' or self.meta['features']!=FEATURES or not np.array_equal(self.meta['scales'],SCALES.tolist()):
            raise ValueError('Need a NEW direct-force checkpoint, not an old three-head checkpoint.')
        with np.load(path,allow_pickle=False) as z:self.w={k:z[k].copy() for k in z.files}
        if self.w['W2'].shape!=(1,64):raise ValueError('Wrong direct-force output shape')
    def normalized(self,x):
        h=np.asarray(x,dtype=np.float32)
        for i in range(3):
            h=h@self.w['W'+str(i)].T+self.w['b'+str(i)]
            if i<2:h=np.tanh(h)
        return h[...,0]
    def __call__(self,raw):return float(650*self.normalized(encode(raw)))
    def predict(self,x):return np.concatenate([650*self.normalized(x[i:i+8192]) for i in range(0,len(x),8192)])
