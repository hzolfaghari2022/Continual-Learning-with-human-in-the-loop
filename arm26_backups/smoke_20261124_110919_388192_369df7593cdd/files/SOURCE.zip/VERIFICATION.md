# Preparation checks

Passed locally:
-46 original upstream source/text file Git blob hashes, pinned to73f63bb4fa0b5d00bda973e20dfb783bfcf1b8aa
-Python AST parsing for every executable source file
-JSON subprocess request/response protocol with a labeled test stand-in
-Gym adapter32-observation/1-action contract,4 one-hot selectors, truncation and case switching with test stand-ins
-600 scenario fixtures yield420 train/60 validation/120 test and105/15/30 per case without reading any force-label arrays
-Smoke gating, completed-method checksum reuse and independent new full-suite scheduling using mocked worker outcomes
-HTML/CSV/PDF/PNG/Overleaf archive generation from explicitly labeled synthetic reporting fixtures; missing RMSE remains missing and truncated/failed counts remain separate
-Visual inspection of generated QA figure layouts

No synthetic test fixtures, learned policies or test results are shipped as scientific output. The included authors' original source has not been altered to pass tests.

Not executable in the preparation environment: OpenSim import/native dynamics, TensorFlow/CUDA optimization, original full SAC/PackNet learning, native Windows dependency installation, real GPU-driver compatibility, authenticated user GitHub pushes, or local LaTeX compilation. CHECK_SETUP and RUN_SMOKE are provided to perform the actual integration checks on the user's machine; the full run refuses to start without the matching successful smoke result.
