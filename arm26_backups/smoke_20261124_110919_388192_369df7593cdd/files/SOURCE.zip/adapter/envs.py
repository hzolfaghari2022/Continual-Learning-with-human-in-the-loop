"""Gym0.x environment contract. No learning updates occur in this module."""
from pathlib import Path
import subprocess,threading,queue,json,math
import numpy as np
import gym
from .common import CASES,ROOT,write

class PhysicsClient:
    def __init__(self,python,folder,timeout):
        folder=Path(folder);folder.mkdir(parents=True,exist_ok=True);self.timeout=timeout
        self.log=(folder/'physics_console.log').open('a',encoding='utf-8')
        self.proc=subprocess.Popen([python,'-u','-X','utf8',str(ROOT/'physics/server.py')],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=self.log,text=True,encoding='utf-8',bufsize=1)
        self.responses=queue.Queue()
        def reader():
            try:
                for line in self.proc.stdout:self.responses.put(line)
            finally:self.responses.put(None)
        threading.Thread(target=reader,daemon=True).start();self.ask('ping')
    def ask(self,command,**payload):
        if self.proc.poll() is not None:raise RuntimeError('OpenSim worker exited; inspect physics_console.log')
        self.proc.stdin.write(json.dumps(dict(command=command,**payload),allow_nan=False)+'\n');self.proc.stdin.flush()
        try:line=self.responses.get(timeout=self.timeout)
        except queue.Empty:
            self.proc.kill();raise RuntimeError('OpenSim worker timed out; no fabricated transition returned')
        if line is None:raise RuntimeError('OpenSim worker closed unexpectedly')
        response=json.loads(line)
        if not response['ok']:raise RuntimeError(response['error'])
        return response['result']
    def close(self):
        if self.proc.poll() is None:
            try:self.ask('close');self.proc.wait(timeout=10)
            except Exception:self.proc.kill()
        self.log.close()

class ArmEnv(gym.Env):
    metadata={'render.modes':[]}
    def __init__(self,catalog,case,split,options,folder,seed=42,max_steps=None):
        self.configs=catalog['pools'][case][split];self.case=case;self.case_index=CASES.index(case);self.split=split;self.options=options;self.folder=Path(folder);self.rng=np.random.default_rng(seed);self.max_steps=max_steps
        self.action_space=gym.spaces.Box(-1.,1.,shape=(1,),dtype=np.float32)
        self.observation_space=gym.spaces.Box(np.array([-np.inf]*28+[0.]*4,np.float32),np.array([np.inf]*28+[1.]*4,np.float32),dtype=np.float32)
        self.name=case;self.num_envs=1;self.client=None;self.counter=0;self.successes=[];self.completed_results=[];self.done=True;self.next_config=None;self.phase='validation' if split=='validation' else 'train' if split=='train' else 'reserved_test'
    def _obs(self,value):
        x=np.asarray(value,np.float32)
        if x.shape!=(28,) or not np.isfinite(x).all():raise ValueError('Invalid OpenSim28-feature response')
        hot=np.zeros(4,np.float32);hot[self.case_index]=1.
        return np.concatenate([x,hot])
    def reset(self):
        if self.client is None:self.client=PhysicsClient(self.options['physics_python'],self.folder,self.options['worker_timeout_s'])
        if not self.done:self.truncate('upstream reset')
        cfg=dict(self.next_config or self.configs[int(self.rng.integers(len(self.configs)))]);self.next_config=None
        self.counter+=1;self.step_count=0;self.done=False
        self.current=self.folder/f'episode_{self.counter:06d}'
        write(self.current/'settings.json',cfg)
        result=self.client.ask('reset',config=cfg,options=self.options,folder=str(self.current))
        return self._obs(result['observation'])
    def step(self,action):
        if self.done:raise RuntimeError('step requires reset')
        action=np.asarray(action,dtype=np.float64).reshape(-1)
        if action.shape!=(1,) or not np.isfinite(action).all():raise ValueError('Invalid exosuit action')
        result=self.client.ask('step',action=float(np.clip(action[0],-1,1)));self.step_count+=1
        obs=self._obs(result['observation']);reward=float(result['reward']);done=bool(result['done']);info=result['info']
        if not done and self.max_steps is not None and self.step_count>=self.max_steps:
            info.update(self.client.ask('truncate',reason='integration-check horizon'));info['TimeLimit.truncated']=True;done=True
        if done:self._finish(info)
        return obs,reward,done,info
    def _finish(self,info):
        self.done=True;self.successes.append(bool(info.get('success',False)));self.completed_results.append(dict(info,folder=str(self.current)))
    def truncate(self,reason):
        if self.done:return {}
        info=self.client.ask('truncate',reason=reason);self._finish(info);return info
    def pop_successes(self):result=self.successes;self.successes=[];return result
    def close(self):
        if self.client is not None:self.client.close();self.client=None

class SequenceEnv(gym.Env):
    def __init__(self,envs,steps_per_case,out,backup_hook=None):
        self.envs=envs;self.steps_per_env=steps_per_case;self.num_envs=len(envs);self.name='ContinualLearningEnv'
        self.action_space=envs[0].action_space;self.observation_space=envs[0].observation_space;self.cur_seq_idx=0;self.cur_step=0;self.out=Path(out);self.backup_hook=backup_hook
    def reset(self):
        if self.cur_seq_idx>=self.num_envs:raise RuntimeError('Sequence exhausted')
        return self.envs[self.cur_seq_idx].reset()
    def step(self,action):
        active=self.cur_seq_idx;obs,reward,done,info=self.envs[active].step(action);info['seq_idx']=active;self.cur_step+=1
        boundary=self.cur_step%self.steps_per_env==0
        if boundary:
            if not done:info.update(self.envs[active].truncate('predeclared case boundary'));info['TimeLimit.truncated']=True
            done=True;self.cur_seq_idx+=1
        if self.cur_step%25==0 or boundary:write(self.out/'PROGRESS.json',dict(phase='training' if not boundary else 'case boundary: pruning/retraining or evaluation may follow',step=self.cur_step,total=self.num_envs*self.steps_per_env,percent=100*self.cur_step/(self.num_envs*self.steps_per_env),case=CASES[active]))
        if self.backup_hook is not None:self.backup_hook(self.cur_step,active)
        return obs,reward,done,info
    def pop_successes(self):return [value for env in getattr(self,'parallel_envs',self.envs) for value in env.pop_successes()]
    def close(self):
        for env in self.envs:env.close()
