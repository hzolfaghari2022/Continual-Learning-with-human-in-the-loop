"""External synchronous collectors; authors' learning/PackNet methods are unchanged.
Workers share a current case, never a training stream across cases.
"""
from concurrent.futures import ThreadPoolExecutor
import time
import numpy as np
from .common import CASES, write


def chunks_remaining(step, budget, workers, log_every):
    # Never gather across a log/evaluation boundary or a case boundary
    return min(workers, budget-step, log_every-step % log_every)


def parallel_run(agent, catalog, options, folder, limit):
    import tensorflow as tf
    from .envs import ArmEnv
    workers = int(options.get('parallel_workers', 2))
    if not 1 <= workers <= 8:
        raise ValueError('parallel_workers must be between 1 and 8')
    agent.start_time = time.time()
    sequence = agent.env
    budget = sequence.steps_per_env
    global_step = 0
    timings = dict(physics_wall_s=0., policy_wall_s=0., updates_wall_s=0.,
                   evaluation_wall_s=0., transitions=0, workers=workers)
    agent.learn_on_batch = agent.get_learn_on_batch(-1)
    with ThreadPoolExecutor(max_workers=workers) as executor:
        for case_index, case in enumerate(CASES):
            sequence.cur_seq_idx = case_index
            agent._handle_task_change(case_index)
            environments = [ArmEnv(catalog, case, 'train', options,
                folder/'parallel_training'/case/('worker_%02d'%i),
                seed=options['seed']+case_index+10000*i, max_steps=limit)
                for i in range(workers)]
            sequence.parallel_envs = environments
            observations = [None]*workers
            returns = [0.]*workers
            lengths = [0]*workers
            case_step = 0
            try:
                while case_step < budget:
                    n = chunks_remaining(case_step, budget, workers, agent.log_every)
                    # Each environment has its own persistent OpenSim process.
                    pending = [(i, executor.submit(environments[i].reset))
                               for i in range(n) if observations[i] is None]
                    for i, job in pending:
                        observations[i] = job.result()
                    started = time.perf_counter()
                    actions = []
                    for i in range(n):
                        t = case_step+i
                        if t > agent.start_steps or (agent.agent_policy_exploration and case_index > 0):
                            action = agent.get_action(tf.convert_to_tensor(observations[i]))
                        else:
                            action = sequence.action_space.sample()
                        actions.append(np.asarray(action))
                    timings['policy_wall_s'] += time.perf_counter()-started
                    started = time.perf_counter()
                    jobs = [executor.submit(environments[i].step, actions[i]) for i in range(n)]
                    results = [job.result() for job in jobs]
                    timings['physics_wall_s'] += time.perf_counter()-started
                    # Stable worker order for replay insertion and update accounting.
                    for i, (next_obs, reward, done, info) in enumerate(results):
                        t = case_step
                        returns[i] += reward
                        lengths[i] += 1
                        timeout = lengths[i] == agent.max_episode_len
                        stored_done = False if timeout or info.get('TimeLimit.truncated') else done
                        agent.replay_buffer.store(observations[i], actions[i], reward, next_obs, stored_done)
                        observations[i] = next_obs
                        if done or timeout:
                            agent.logger.store({'train/return':returns[i], 'train/ep_length':lengths[i]})
                            if timeout and not done:
                                environments[i].truncate('learner episode horizon')
                            returns[i], lengths[i], observations[i] = 0., 0, None
                        started = time.perf_counter()
                        if t >= agent.update_after and t % agent.update_every == 0:
                            for _ in range(agent.update_every):
                                batch = agent.replay_buffer.sample_batch(agent.batch_size)
                                episodic = agent.get_episodic_batch(case_index)
                                metrics = agent.learn_on_batch(tf.convert_to_tensor(case_index), batch, episodic)
                                agent._log_after_update(metrics)
                        timings['updates_wall_s'] += time.perf_counter()-started
                        case_step += 1
                        global_step += 1
                        sequence.cur_step = global_step
                        timings['transitions'] = global_step
                        if case_step == budget:
                            started = time.perf_counter()
                            agent.on_task_end(case_index) # original pruning and retraining
                            timings['updates_wall_s'] += time.perf_counter()-started
                        if global_step % 25 == 0 or case_step == budget:
                            write(folder/'PROGRESS.json', dict(phase='parallel training',
                                step=global_step,total=agent.steps,percent=100*global_step/agent.steps,case=case))
                        if sequence.backup_hook:
                            sequence.backup_hook(global_step,case_index)
                        if global_step % agent.log_every == 0 or global_step == agent.steps:
                            started = time.perf_counter()
                            epoch = (global_step+agent.log_every-1)//agent.log_every
                            if epoch % agent.save_freq_epochs == 0 or global_step == agent.steps:
                                agent.save_model(case_index)
                            agent.test_agent(deterministic=False,num_episodes=agent.num_test_eps_stochastic)
                            agent.test_agent(deterministic=True,num_episodes=agent.num_test_eps_deterministic)
                            agent._log_after_epoch(epoch,t,global_step-1,dict(info,seq_idx=case_index))
                            timings['evaluation_wall_s'] += time.perf_counter()-started
                            timings['elapsed_s'] = time.time()-agent.start_time
                            timings['training_transitions_per_elapsed_s'] = global_step/max(timings['elapsed_s'],1e-9)
                            write(folder/'PARALLEL_TIMING.json',timings)
            finally:
                # Close every child even when a worker, GPU or backup raises.
                for env in environments:
                    try:
                        if not env.done:env.truncate('predeclared case boundary or interrupted collection')
                    finally:env.close()
    sequence.cur_seq_idx = len(CASES)
