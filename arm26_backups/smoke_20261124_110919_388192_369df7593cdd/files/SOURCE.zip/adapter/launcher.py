"""Experiment orchestration only. Original learner classes and updates are unchanged."""
from pathlib import Path
import sys,os,json,time,subprocess,shutil,zipfile,hashlib
from datetime import datetime
from .common import ROOT,read,write,verify_upstream,settings,sha

def configuration_signature(config,catalog):
    return hashlib.sha256(json.dumps(dict(settings=config,source_manifest=catalog['source_manifest_sha256'],upstream=verify_upstream(),adapter_sources={p.relative_to(ROOT).as_posix():sha(p) for p in ROOT.rglob('*.py') if not any(k in p.relative_to(ROOT).parts for k in ['runs','github_cache','__pycache__','.git'])}),sort_keys=True).encode()).hexdigest()

def launch(mode):
    import argparse
    p=argparse.ArgumentParser();p.add_argument('--new-run',action='store_true');p.add_argument('--resume',action='store_true');a=p.parse_args()
    if a.new_run and a.resume:p.error('Choose either new run or resume')
    config=settings();verify_upstream()
    python=Path(config['rl_python']);physics=Path(config['physics_python'])
    if not python.is_file():raise RuntimeError('RL Python not found. Run SETUP_RL_ENV.py first: '+str(python))
    if not physics.is_file():raise RuntimeError('Original OpenSim Python not found: '+str(physics))
    if not config['methods'] or len(set(config['methods']))!=len(config['methods']):raise ValueError('Provide unique methods including no_cl and packnet')
    if not 0<config['physics_max_step_s']<=config['control_dt_s']<=.1 or config['force_cap_N']!=650 or config['backup_every_steps']<1:raise ValueError('Invalid integration timing, force envelope or backup interval')
    if min(config['reward_angle_scale_deg'],config['reward_velocity_scale_rad_s'])<=0:raise ValueError('Reward scales must be positive')
    if config['methods'][0]!='no_cl' or 'packnet' not in config['methods'] or any(m not in ['no_cl','packnet','ewc'] for m in config['methods']):raise ValueError('Methods must start with no_cl and include packnet; optional ewc')
    if config['control_dt_s']<=0 or config['physics_max_step_s']<=0 or config['force_cap_N']!=650:raise ValueError('Invalid integration timing or changed force envelope')
    marker=ROOT/('LAST_'+mode.upper()+'.json')
    if marker.exists() and not a.new_run and mode!='check':suite=Path(read(marker)['folder']);catalog=read(suite/'SCENARIOS.json');old=read(suite/'CONFIG.json')
    else:
        if a.resume:raise RuntimeError('No previous run recorded for '+mode)
        suite=ROOT/'runs'/(mode+'_'+datetime.now().strftime('%Y%m%d_%H%M%S_%f'));suite.mkdir(parents=True,exist_ok=True)
        from .catalog import build_catalog
        catalog=build_catalog(config['dataset'],suite);write(suite/'CONFIG.json',config)
        write(marker,dict(folder=str(suite)));old=config
        with zipfile.ZipFile(suite/'SOURCE.zip','w',zipfile.ZIP_DEFLATED) as z:
            for f in ROOT.rglob('*'):
                rel=f.relative_to(ROOT)
                if f.is_file() and f.suffix not in ['.lock','.tmp'] and not any(k in rel.parts for k in ['runs','github_cache','__pycache__','.git']):z.write(f,rel)
    if old!=config:raise RuntimeError('Settings changed for recorded run; use --new-run or restore its original settings')
    signature=configuration_signature(config,catalog)
    frozen=suite/'RUN_SIGNATURE.json'
    if frozen.exists() and read(frozen)['signature']!=signature:raise RuntimeError('Source/scenario settings changed; use a new run')
    write(frozen,dict(signature=signature,mode=mode))
    print('OUTPUT:',suite,flush=True)
    if mode=='full':
        gate=ROOT/'SMOKE_PASS.json'
        if not gate.exists() or read(gate)['signature']!=signature:raise RuntimeError('First run CHECK_SETUP.py and RUN_SMOKE.py successfully with these same settings. Full RL has not started.')
        print('Parallel full budget:1,000,000 new simulator steps per case,4 cases per method, plus PackNet retraining/evaluation. This may take a long time in OpenSim.',flush=True)
    def backup(reason,final=False):
        if not config['github']:return
        print('GitHub backup: '+reason,flush=True)
        from backup import backup_experiment
        os.environ.setdefault('ARM26_VERIFIED_BACKUP_CACHE',str(ROOT/'github_cache'))
        try:
            result=backup_experiment(suite,None,reason=reason,final=final)
            print('GITHUB VERIFIED:',result['commit_url'],flush=True)
        except Exception as exc:
            write(suite/'BACKUP_PENDING.json',dict(reason=reason,error=str(exc)))
            print('GitHub backup deferred:',exc,flush=True)
    if mode!='check':backup('RL run initialized')
    # Real OpenSim reset and original GPU update/mask tests must precede either suite.
    if not (suite/'PREFLIGHT_PASS.json').exists():
        run_child(python,['check',str(suite),str(suite)],suite/'PREFLIGHT.log',suite,config)
    if mode=='check':
        print('PASS: CUDA update, original SAC/PackNet updates and masks, OpenSim reset/step',flush=True);return
    attempts={};baseline_hash=None
    state=suite/'METHODS.json';records=read(state) if state.exists() else {}
    for method in config['methods']:
        previous=records.get(method);completed=False
        if previous:
            old_folder=suite/previous['folder'];done=old_folder/'METHOD_COMPLETE.json'
            if done.exists():
                proof=read(done)
                if any(sha(old_folder/n)!=h for n,h in proof['hashes'].items()):raise RuntimeError('Completed checkpoint changed: '+method)
                completed=True;folder=old_folder
        if not completed:
            folder=suite/'methods'/method/('attempt_'+datetime.now().strftime('%Y%m%d_%H%M%S_%f'));folder.mkdir(parents=True,exist_ok=True)
            records[method]=dict(folder=folder.relative_to(suite).as_posix(),status='running');write(state,records)
            try:run_child(python,[mode,str(suite),str(folder),method],folder/'RUN.log',folder,config)
            except Exception:
                records[method]['status']='failed';write(state,records)
                try:report(python,suite);backup('interrupted method; local results preserved')
                except Exception:pass
                raise
        proof=read(folder/'METHOD_COMPLETE.json')
        if method=='no_cl':baseline_hash=proof['initial_actor_sha256']
        elif proof['initial_actor_sha256']!=baseline_hash:raise RuntimeError('Methods did not start from identical seeded actor weights')
        records[method]=dict(folder=folder.relative_to(suite).as_posix(),status='completed');write(state,records)
        report(python,suite);backup(method+' report and models completed')
    if mode=='smoke':write(ROOT/'SMOKE_PASS.json',dict(signature=signature,folder=str(suite),note='Software integration only; not proof of tracking quality'))
    write(suite/'SUITE_COMPLETE.json',dict(mode=mode,signature=signature,methods=list(records),note='Integration check' if mode=='smoke' else 'One-seed adapted OpenSim RL experiment; no paper-result reproduction claim'))
    report(python,suite);backup('final RL results, HTML/Overleaf and models',final=True)
    print('REPORT:',suite/'REPORT.html',flush=True)

def run_child(python,args,log_path,progress_folder,config):
    env=os.environ.copy();env['MKL_THREADING_LAYER']='SEQUENTIAL';env['OPENBLAS_NUM_THREADS']='1'
    if os.name=='nt':
        prefix=Path(python).parent;env['PATH']=str(prefix/'Library/bin')+os.pathsep+str(prefix/'Scripts')+os.pathsep+str(prefix)+os.pathsep+env.get('PATH','')
    with Path(log_path).open('a',encoding='utf-8') as log:
        proc=subprocess.Popen([str(python),'-u','-X','utf8',str(ROOT/'rl_worker.py'),*args],stdout=log,stderr=subprocess.STDOUT,env=env,cwd=ROOT)
        start=time.monotonic()
        try:
            while proc.poll() is None:
                text='Checking integration'
                file=Path(progress_folder)/'PROGRESS.json'
                if file.exists():
                    try:
                        data=read(file);text=f"{data['case']} | {data['step']}/{data['total']} | {data['percent']:.1f}% | {data['phase']}"
                    except (OSError,ValueError):pass
                status_path=Path(args[1])/'STATUS.json'
                if status_path.exists():
                    try:status=read(status_path)
                    except (OSError,ValueError):status={}
                    if status.get('phase') in ['GitHub backup','frozen evaluation starting']:text=status['phase']+' | '+str(status.get('method',''))
                evaluation=Path(progress_folder)/'EVALUATION_PROGRESS.json'
                if evaluation.exists():
                    try:
                        v=read(evaluation);text=f"Frozen evaluation | {v['completed']}/{v['total']} | {100*v['completed']/v['total']:.1f}%"
                    except (OSError,ValueError,KeyError):pass
                print('\r'+text[:110].ljust(110)+f' elapsed {int(time.monotonic()-start)}s',end='',flush=True)
                time.sleep(2)
        except KeyboardInterrupt:proc.terminate();proc.wait();raise
    print(flush=True)
    if proc.returncode:
        lines=Path(log_path).read_text(encoding='utf-8',errors='replace').splitlines();print('\n'.join(lines[-30:]),flush=True)
        raise RuntimeError('Worker stopped; completed work remains saved. Log: '+str(log_path))

def report(python,suite):
    subprocess.run([str(python),'-u',str(ROOT/'BUILD_REPORT.py'),str(suite)],check=True,cwd=ROOT)
