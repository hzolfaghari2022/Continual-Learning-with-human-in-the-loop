from pathlib import Path
import sys, types, unittest, tempfile, json, importlib, ast, hashlib
import numpy as np
root=Path(__file__).resolve().parents[1];sys.path.insert(0,str(root))
from adapter import parallel
class FakeEnv:
 instances=[]
 def __init__(self,catalog,case,split,options,folder,seed,max_steps):
  self.case=case;self.done=True;self.closed=False;self.count=0;FakeEnv.instances.append(self)
 def reset(self):self.done=False;self.count=0;return np.zeros(32)
 def step(self,action):
  self.count+=1;self.done=self.count==3
  return np.ones(32),1.,self.done,{}
 def truncate(self,reason):self.done=True
 def close(self):self.closed=True
class Agent:
 def __init__(self):
  self.stores=[];self.updates=0;self.ends=[];self.starts=[];self.logs=[]
  self.env=types.SimpleNamespace(steps_per_env=7,action_space=types.SimpleNamespace(sample=lambda:np.zeros(1)),backup_hook=None)
  self.start_steps=1;self.agent_policy_exploration=False;self.max_episode_len=4;self.update_after=2;self.update_every=2;self.batch_size=1;self.log_every=7;self.steps=28;self.save_freq_epochs=1;self.num_test_eps_stochastic=1;self.num_test_eps_deterministic=1
  self.logger=types.SimpleNamespace(store=lambda x:None)
  self.replay_buffer=types.SimpleNamespace(store=lambda *x:self.stores.append(x),sample_batch=lambda n:{})
 def get_learn_on_batch(self,i):return self.learn
 def learn(self,*args):self.updates+=1;return {}
 def get_action(self,obs):return np.zeros(1)
 def _handle_task_change(self,i):self.starts.append(i)
 def get_episodic_batch(self,i):return None
 def _log_after_update(self,x):pass
 def on_task_end(self,i):self.ends.append(i)
 def save_model(self,i):pass
 def test_agent(self,**kwargs):pass
 def _log_after_epoch(self,epoch,t,g,info):self.logs.append((epoch,t,g))
class Tests(unittest.TestCase):
 def test_budget_boundaries(self):
  for workers in [1,2,4,8]:
   for budget in [1,7,100]:
    t=0
    while t<budget:
     n=parallel.chunks_remaining(t,budget,workers,5)
     self.assertTrue(1<=n<=workers);self.assertLessEqual(n,budget-t);self.assertLessEqual(n,5-t%5);t+=n
    self.assertEqual(t,budget)
 def test_entire_loop(self):
  sys.modules['tensorflow']=types.SimpleNamespace(convert_to_tensor=lambda x:x)
  sys.modules['adapter.envs']=types.SimpleNamespace(ArmEnv=FakeEnv)
  for workers in [1,2,4]:
   FakeEnv.instances=[];a=Agent()
   with tempfile.TemporaryDirectory() as d:
    parallel.parallel_run(a,{},dict(parallel_workers=workers,seed=42),Path(d),None)
    timing=json.loads((Path(d)/'PARALLEL_TIMING.json').read_text());self.assertEqual(timing['transitions'],28)
   self.assertEqual(len(a.stores),28);self.assertEqual(a.updates,24)
   self.assertEqual(a.starts,[0,1,2,3]);self.assertEqual(a.ends,[0,1,2,3]);self.assertEqual(len(a.logs),4)
   self.assertTrue(all(e.closed for e in FakeEnv.instances))
 def test_upstream_unchanged(self):
  from adapter.common import verify_upstream
  self.assertTrue(verify_upstream())
 def test_syntax(self):
  for p in root.rglob('*.py'):ast.parse(p.read_text(encoding='utf-8-sig'))
 def test_invalid_workers(self):
  with self.assertRaises(ValueError):parallel.parallel_run(Agent(),{},dict(parallel_workers=0),root,None)
if __name__=='__main__':unittest.main()
