"""Run checks and a short integration gate before full parallel training."""
from pathlib import Path
import os, subprocess, sys
root=Path(__file__).resolve().parent
if __name__=='__main__':
    if len(str(root))>75:
        raise SystemExit('Extract into a short path under your Windows user folder')
    python=Path.home()/'miniconda3/envs/arm26-cw/python.exe'
    if not python.is_file():raise SystemExit('Run SETUP_RL_ENV.py first; existing RL environment was not found')
    for script in ['CHECK_SETUP.py','RUN_SMOKE.py','RUN_FULL_RL.py']:
        print('RUNNING',script,flush=True)
        result=subprocess.run([str(python),'-u','-X','utf8',str(root/script)],cwd=root)
        if result.returncode:raise SystemExit(result.returncode)
