# Parallel OpenSim collection for the long experiment

This is a new experiment package based on your uploaded long version, not a patch to the currently running diagnostic pilot. Extract into a fresh short folder. Do not overwrite or run concurrently with your current experiment.

## Run in VS Code
Open the extracted package folder. In PowerShell:

    & "$env:USERPROFILE\miniconda3\envs\lstm-py312\python.exe" -u -X utf8 .\RUN_PARALLEL.py

This uses the existing arm26-cw environment. It checks CUDA/OpenSim, runs the short integration check, then launches the full experiment. Stop if the integration check fails. Existing source dataset path remains the same as your uploaded package; edit settings.json if your dataset moved.

Default settings.json: parallel_workers = 2. Set to 1 for a serial baseline or 4 for a four-worker timing comparison, in SEPARATE extracted copies. Run RUN_SMOKE.py first in each copy. Smoke is an integration check, not a representative speed benchmark; compare PARALLEL_TIMING.json after a full training log interval. Do not launch benchmark copies simultaneously. Higher worker counts can be slower or exhaust RAM.

## What runs in parallel
Each worker owns a separate persistent OpenSim CPU process and independent episodes. Threads only dispatch requests to those processes. One shared learner runs original SAC/PackNet GPU updates. No CL and PackNet run consecutively, not simultaneously. Only the active muscle case is collected: A90 -> B60 -> C30 -> D45. This is multiple simulation workers, not multi-agent reinforcement learning.

One million TOTAL new simulator transitions per case per method, shared across workers, not one million per worker. Four million per method; eight million across both. PackNet retains its original additional 100000-update pruning/retraining schedule. Original replay, losses, optimizer methods and task-boundary methods remain unchanged. Original 46 upstream files are unchanged and source-verified.

The external collection loop gathers a synchronous batch, then inserts transitions in worker order. Gradient-update counts and warmup thresholds match the serial budget. Actions in a collection batch use the policy before that batch's updates, so this is a documented collection-schedule adaptation, not an identical reproduction of the original single-environment run. Numerical results will change; CL superiority is not guaranteed.

## GPU and runtime
GPU is mandatory for learning; OpenSim dynamics remain CPU. Only collection is parallelized. Policy calls, learning, pruning/retraining, evaluation and GitHub work are serial. Physics scaling depends on CPU cores, RAM and solver cost; no fixed speedup is promised. PARALLEL_TIMING.json separates physics stepping, policy, learning/pruning and evaluation/logging wall times. Resets, file exports and backups also add elapsed time.

## Outputs and limitations
Existing HTML, Overleaf reports, figures, frozen evaluations, checkpoints and GitHub backups remain. Failed uploads are recorded in BACKUP_PENDING.json and do not abort training; no false verified upload is printed. Windows-safe backup locking and retrying atomic JSON writes are included. A failed method restarts on relaunch; exact mid-method resume is NOT implemented. Completed methods retain the original checksum-based reuse.

Physical failure guards are unchanged. A No CL trajectory may still stop when the arm leaves the allowed simulation envelope; parallelism does not remove that guard or invent missing results. This package does not incorporate the separate diagnostic pilot's stage-by-stage retention audit.

## Validation
Local fake-environment integration tested 1, 2 and 4 workers, all four case boundaries, exact transition/update budgets and cleanup. Also tested scheduler boundaries, syntax and byte-identical upstream files. No Windows/OpenSim/TensorFlow/CUDA runtime or hardware speed test was possible on the preparation host. First run the included real integration gate on your PC.
